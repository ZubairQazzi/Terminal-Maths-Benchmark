# Scoped originality audit

PASS within the inspected scope: 97 pinned main/lite instructions plus existing Task 1 and completed Task 2, 99 total references; maximum actual upstream TF-IDF cosine 0.566311 (threshold 0.80), closest completed-task-2.

The math is classical, as described in the cited research. The polynomial generator, joint valuation/census contract, singular digit-lifting oracle and functional finite-difference checker are newly authored. The science reference tasks use imagery and atomistic models. Task 1 uses polynomial matrix pencils and Task 2 uses convex optimization with rational polygons; no distinctive mathematical implementation, input structure or hidden test is reused. Generic process isolation and packaging tooling are reused openly. Generic isolation conventions are shared infrastructure. Source-token comparisons are in the JSON report.

This is a scoped investigation, not proof of global originality or an external plagiarism-service verdict.
