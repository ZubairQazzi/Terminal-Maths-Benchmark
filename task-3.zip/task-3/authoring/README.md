# Task 3 authoring record

The delivered standalone root is F:/rl/task-3. Canonical QC staging is under authoring/package/tasks/mathematical-sciences/formal-mathematics/certified-padic-census; hashes prove the staged runtime files match the standalone root. The user requested the standalone layout. Source snapshots and corpus copies are research material outside both image contexts.

Task2_gate_before_task3.json proves Task2's available non-Gemini gate completed before this design began. This task independently implements a number-theoretic valuation census. Its algorithms, inputs and hidden mathematical tests differ from Task2 optimization. Only generic Docker, restricted subprocess, packaging and static-check infrastructure is reused and locally copied; no runtime dependency remains on another task.

Original user instructions, full governing QC checklist and prior feedback are preserved in inputs. The output-contract lessons discovered in Task2 are applied from the start: exact types are checked only on mathematical fields, ignored metadata may contain ordinary JSON decimals, integer spellings are not over-canonicalized, source restrictions are public, and professional/synthetic context is explicit. All easy controls are disclosed in coverage/discrimination reports.

No Gemini or paid provider API call, model trial, upload, commit or publication is authorized or performed. External QC panel approval and empirical agent calibration are distinct from local and independent evidence.
