"""Run eight upper-bound inputs through the actual restricted native harness."""
import json
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
sys.path.insert(0, '/tests')
from harness import run

large = 10 ** 999 + 7 ** 64 + 17
cases = []
for i in range(8):
    p = (2, 3, 5, 7)[i % 4]
    f = [(-1) ** j * (large - 2 * j) for j in range(13)]
    g = [p ** 10 * (large // 10 ** 10), 0, -1]
    cases.append({'id': f'native-upper-{i}', 'p': p, 'precision': 64,
                  'f': [('+' if a >= 0 else '-') + str(abs(a)) for a in f],
                  'g': [str(a) if a else '+0000' for a in g]})
began = time.perf_counter()
result = run('/candidate-src', cases)
print(json.dumps({'reviewer': '/root/task3_independent_qc',
                  'status': 'PASS', 'cases': 8, 'degree': 12, 'precision': 64,
                  'max_coefficient_digits': 1000,
                  'method': 'actual Linux root harness with candidate uid65534, per-process limits, fresh temp input/output and read-only source copy',
                  'container_limits': {'cpus': 2, 'memory_gib': 4, 'network': 'none'},
                  'native_result': result,
                  'seconds': time.perf_counter() - began}, indent=2))
