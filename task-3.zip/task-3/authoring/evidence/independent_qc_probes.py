"""Fresh review probes; never imported by the task or its verifier."""
from collections import Counter
from copy import deepcopy
import importlib.util
import itertools
import json
from pathlib import Path
import random
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.dont_write_bytecode = True


def module(name, file):
    spec = importlib.util.spec_from_file_location(name, ROOT / file)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


checker = module('independent_checker', 'tests/certificates.py')
reference = module('independent_reference', 'solution/solve.py')


def eval_plain(poly, x):
    y = 0
    for a in reversed(poly):
        y = y * x + int(a)
    return y


def val(n, p, N):
    if n == 0:
        return N
    return next((v for v in range(N) if n % p ** (v + 1)), N)


def labels(case):
    p, N = case['p'], case['precision']
    return [(val(eval_plain(case['f'], x), p, N),
             val(eval_plain(case['g'], x), p, N)) for x in range(p ** N)]


def independent_result(case):
    p, N = case['p'], case['precision']
    data = labels(case)
    leaves = []

    def descend(r, k):
        pairs = set(data[r::p ** k])
        if len(pairs) == 1:
            a, b = next(iter(pairs))
            leaves.append([r, k, a, b])
        else:
            assert k < N
            for digit in range(p):
                descend(r + digit * p ** k, k + 1)

    descend(0, 0)
    hist = Counter(data)
    counts = []
    for s in range(1, N + 1):
        counts.append(sum(eval_plain(case['f'], x) % p ** s == 0
                          and eval_plain(case['g'], x) % p ** s == 0
                          for x in range(p ** s)))
    return {'id': case['id'], 'leaves': list(reversed(leaves)),
            'histogram': [[a, b, n] for (a, b), n in sorted(hist.items())],
            'root_counts': counts}


def main():
    began = time.perf_counter()
    report = {'reviewer': '/root/task3_independent_qc',
              'method': 'plain integer evaluation/enumeration; no reference recursion used to establish expected labels',
              'certificate_comparisons': 0, 'polynomial_enumeration_cases': 0,
              'independent_partition_cases': 0, 'oracle_crosschecks': 0}
    rng = random.Random(724037)

    # Exhaust all binary quadratic/cubic coefficient vectors and selected rings;
    # compare every possible label against the actual finite cylinder population.
    cases = []
    for coeff in itertools.product(range(-2, 3), repeat=4):
        f = list(coeff)
        while len(f) > 1 and f[-1] == 0:
            f.pop()
        for N in (1, 2, 3, 4):
            cases.append({'id': f'enumerated-{len(cases)}', 'p': 2,
                          'precision': N, 'f': f, 'g': [0]})
    for i in range(160):
        p = (2, 3, 5, 7)[i % 4]
        N = 1 + i % 3
        f = [rng.randint(-100, 100) for _ in range(1 + i % 13)]
        g = [rng.randint(-100, 100) for _ in range(1 + (i * 7) % 13)]
        while len(f) > 1 and f[-1] == 0:
            f.pop()
        while len(g) > 1 and g[-1] == 0:
            g.pop()
        cases.append({'id': f'random-{i}', 'p': p, 'precision': N, 'f': f, 'g': g})

    for index, case in enumerate(cases):
        p, N = case['p'], case['precision']
        for poly in (case['f'], case['g']):
            values = [val(eval_plain(poly, x), p, N) for x in range(p ** N)]
            for k in range(N + 1):
                # All cylinders for exhaustive binary inputs; a bounded random
                # selection still includes k=N where the proof grid wraps.
                residues = range(p ** k) if index < 2500 else sorted({0, p ** k - 1, rng.randrange(p ** k)})
                for r in residues:
                    actual = set(values[r::p ** k])
                    for v in range(N + 1):
                        expected = actual == {v}
                        try:
                            checker.certify(poly, r, k, v, p, N)
                            accepted = True
                        except AssertionError:
                            accepted = False
                        assert accepted == expected, (case, r, k, v, actual)
                        report['certificate_comparisons'] += 1
        report['polynomial_enumeration_cases'] += 1
        if index % 20 == 0 or index >= 2500:
            expected = independent_result(case)
            checker.verify(case, expected)
            answer = reference.solve(case)
            assert answer['histogram'] == expected['histogram']
            assert answer['root_counts'] == expected['root_counts']
            checker.verify(case, answer)
            report['independent_partition_cases'] += 1
            report['oracle_crosschecks'] += 1

    # A coarse functional cylinder that any coefficient-content-only validator
    # would reject: x^4-2x^3+x^2+2 is always 2 modulo 4.
    coarse = {'id': 'independent-functional', 'p': 2, 'precision': 64,
              'f': [2, 0, 1, -2, 1], 'g': [0]}
    result = {'id': coarse['id'], 'leaves': [[0, 0, 1, 64]],
              'histogram': [[1, 64, 2 ** 64]],
              'root_counts': [2] + [0] * 63}
    checker.verify(coarse, result)
    report['naive_coefficient_counterexample_accepted'] = True
    # T must exceed degree. binomial(t,2) changes mod2 between t=0 and t=2.
    assert (0 * -1 // 2) % 2 != (2 * 1 // 2) % 2
    try:
        checker.certify([0, -1, 1], 0, 0, 1, 2, 8)
    except AssertionError:
        report['insufficient_period_trap_rejected'] = True
    else:
        raise AssertionError('accepted variable-valued integer-valued quotient')

    # Exact promised coefficient and invocation bounds. All coefficients have
    # <=1000 digits, including deliberate signed and zero-padded encodings.
    large = 10 ** 999 + 7 ** 64 + 17
    upper = []
    for i in range(8):
        p = (2, 3, 5, 7)[i % 4]
        f = [(-1) ** j * (large - j * 2) for j in range(13)]
        g = [p ** 10 * (large // 10 ** 10), 0, -1]
        # Last coefficient remains nonzero, and degree12 is preserved.
        f = [('+' if a >= 0 else '-') + str(abs(a)) for a in f]
        g = [str(a) if a else '+0000' for a in g]
        upper.append({'id': f'edge-{i}', 'p': p, 'precision': 64, 'f': f, 'g': g})
    started = time.perf_counter()
    answers = [reference.solve(c) for c in upper]
    for c, a in zip(upper, answers):
        checker.verify(c, a)
    report['upper_bound_batch'] = {'cases': len(upper), 'max_coefficient_digits': max(len(str(abs(int(a)))) for c in upper for n in ('f', 'g') for a in c[n]),
                                   'seconds': time.perf_counter() - started,
                                   'maximum_leaves': max(len(a['leaves']) for a in answers),
                                   'output_bytes': len(json.dumps({'cases': answers}).encode())}

    # Converting every mathematical scalar to an explicit-plus, zero-padded
    # signed decimal string must be accepted. Order and extra fields are free.
    encoded = deepcopy(result)
    def encode(value):
        return ('+' if value >= 0 else '-') + '000' + str(abs(value))
    encoded['leaves'] = [[encode(v) for v in row] for row in encoded['leaves']]
    encoded['histogram'] = [[encode(v) for v in row] for row in encoded['histogram']]
    encoded['root_counts'] = [encode(v) for v in encoded['root_counts']]
    encoded['extra'] = 'ignored'
    checker.verify(coarse, encoded)
    report['signed_zero_padded_output_accepted'] = True
    report['runtime_seconds'] = time.perf_counter() - began
    report['status'] = 'PASS'
    target = ROOT / 'authoring/reports/independent_qc_probes.json'
    target.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
