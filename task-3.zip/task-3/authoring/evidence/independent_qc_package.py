"""Independent byte, dependency, schema and evidence consistency checks."""
import hashlib
import json
from pathlib import Path
import re
import sys
import tomllib

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
CANONICAL = ROOT / 'authoring/package/tasks/mathematical-sciences/formal-mathematics/certified-padic-census'
names = ('task.toml', 'instruction.md', 'README.md', 'environment', 'solution', 'tests')


def files(root):
    answer = {}
    for name in names:
        path = root / name
        for item in path.rglob('*') if path.is_dir() else [path]:
            if item.is_file():
                assert not item.is_symlink()
                assert '__pycache__' not in item.parts and item.suffix != '.pyc'
                answer[item.relative_to(root).as_posix()] = hashlib.sha256(item.read_bytes()).hexdigest()
    return answer


current, staged = files(ROOT), files(CANONICAL)
assert current == staged, 'runtime and canonical staging mismatch'
manifest = json.loads((ROOT / 'authoring/reports/package_manifest.json').read_text())
assert current == manifest['files'], 'package manifest stale'
required = ['instruction.md', 'task.toml', 'environment/Dockerfile', 'solution/solve.sh', 'tests/test.sh']
assert all((ROOT / p).is_file() for p in required)
data = tomllib.loads((ROOT / 'task.toml').read_text())
allowed = {
    'task': {'name', 'version', 'description', 'authors', 'keywords'},
    'metadata': {'domain', 'field', 'subfield', 'author_name', 'author_email', 'author_profile', 'author_organization',
                 'relevant_experience', 'conflicts_of_interest', 'expert_time_estimate_hours', 'tags'},
    'agent': {'timeout_sec', 'user'},
    'verifier': {'timeout_sec', 'environment_mode', 'user', 'environment'},
    'environment': {'build_timeout_sec', 'network_mode', 'cpus', 'memory_mb', 'storage_mb', 'gpus'},
}
assert set(data) == set(allowed) | {'schema_version', 'artifacts'}
assert all(set(data[k]) <= v for k, v in allowed.items())
assert set(data['verifier']['environment']) == {'network_mode', 'cpus', 'memory_mb', 'storage_mb', 'gpus'}
assert data['task']['name'] == 'terminal-bench-science/certified-padic-census'
assert data['agent']['timeout_sec'] == 28800 and data['verifier']['environment_mode'] == 'separate'
assert data['verifier']['environment']['network_mode'] == 'no-network'
dependencies = {}
for folder in ('environment', 'tests'):
    hashes = {}
    for line in (ROOT / folder / 'requirements.txt').read_text().splitlines():
        if line.startswith('#') or not line.strip():
            continue
        package, digest = line.split(' --hash=sha256:')
        name, version = package.split('==')
        wheels = [p for p in (ROOT / folder / 'wheels').glob('*.whl')
                  if p.name.lower().replace('_', '-').startswith(name.lower().replace('_', '-') + '-' + version)]
        assert len(wheels) == 1 and hashlib.sha256(wheels[0].read_bytes()).hexdigest() == digest
        hashes[package] = digest
    dependencies[folder] = hashes
assert all(dependencies['tests'][p] == digest for p, digest in dependencies['environment'].items())
rules = json.loads((ROOT / 'authoring/reports/upstream_static.json').read_text())
assert len(rules) == len({r['check'] for r in rules}) == 26
assert all(r['exit_code'] == 0 for r in rules)
spec = (ROOT / 'environment/spec.md').read_text()
assert '128 open file descriptors' in spec and '64 MiB' in spec
assert '300-second wall-clock' in spec and '300 CPU seconds per process' in spec
assert '2 GiB address space per process' in spec
report = {'reviewer': '/root/task3_independent_qc', 'status': 'PASS',
          'runtime_and_canonical_byte_match': True, 'manifest_current': True,
          'runtime_file_count': len(current), 'version': data['task']['version'],
          'entry_files': required, 'supported_manifest_field_check': 'PASS',
          'all_bundled_dependency_hashes_match': True,
          'shared_dependency_bytes_match': True, 'recorded_upstream_static_exit_zero': 26,
          'F1_contract_disclosure_recheck': 'PASS', 'runtime_hashes': current}
(ROOT / 'authoring/reports/independent_qc_package.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in report.items() if k != 'runtime_hashes'}, indent=2))
