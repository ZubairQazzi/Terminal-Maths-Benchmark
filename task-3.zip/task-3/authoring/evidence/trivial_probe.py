"""Measure all-root guess per input and retain explicit control acceptance."""
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tests'))
from cases import FAMILIES
from harness import run
rows=[]
for family,cases in FAMILIES:
    for c in cases:
        try:run(ROOT/'authoring/evidence/baselines/constant',[c],portable=True);ok=True;reason='disclosed non-discriminating control'
        except Exception as e:ok=False;reason=str(e)
        rows.append({'case':c['id'],'family':family,'all_roots_guess_accepted':ok,'reason':reason})
assert {r['case'] for r in rows if r['all_roots_guess_accepted']}=={'all-zero-control','null-three-bound','degree-twelve-bound'}
(ROOT/'authoring/reports/trivial_guess_per_case.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print('Only three explicitly disclosed all-residue controls accepted;19 other cases rejected')
