import json,sys
from collections import Counter
from reference import solve
d=json.load(open(sys.argv[1]));out=[]
for c in d['cases']:
 a=solve(c);left=Counter();right=Counter();M=c['p']**c['precision']
 for u,v,n in a['histogram']:left[u]+=n;right[v]+=n
 a['histogram']=[[u,v,x*y//M] for u,x in left.items() for v,y in right.items() if x*y//M];out.append(a)
json.dump({'cases':out},open(sys.argv[2],'w'))
