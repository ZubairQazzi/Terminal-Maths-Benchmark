import json,sys
from reference import solve,summarize
d=json.load(open(sys.argv[1]));out=[]
for c in d['cases']:
 cut=min(c['precision'],3);a=solve(dict(c,precision=cut));leaves=[[r,k,c['precision'] if u==cut else u,c['precision'] if v==cut else v] for r,k,u,v in a['leaves']];out.append(summarize(c,leaves))
json.dump({'cases':out},open(sys.argv[2],'w'))
