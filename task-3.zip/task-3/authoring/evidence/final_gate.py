"""Close Task3 only after final independent criterion-level approval."""
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];R=ROOT/'authoring/reports'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
review=read(R/'independent_qc_findings.json')
text=(R/'independent_qc_review.md').read_text(encoding='utf-8')
assert 'PASS' in text and 'interim' not in text.splitlines()[0].lower()
assert review['verdict'].startswith('PASS') and review['version']=='0.1.1'
assert len(review['static_criteria'])==29 and len(review['rubric_criteria'])==38
for x in review.get('findings',[]):
    assert x.get('final_status')=='CLOSED',x
assert all(x['exit_code']==0 for x in read(R/'upstream_static.json'))
assert read(R/'local_validation.json')['success'] and read(R/'security_probe.json')['success'] and read(R/'native_summary.json')['success']
package=read(R/'package_manifest.json')
for p,h in package['files'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
standalone=[read(p) for p in (R/'harbor-jobs/standalone-v011').glob('*/result.json')]
assert len(standalone)==1 and standalone[0]['exception_info'] is None and standalone[0]['verifier_result']['rewards']['reward']==1
assert (R/'harbor_standalone_lint_v011.log').read_text().strip().endswith('[]')
task1=read(R/'task1_readonly_snapshot.json')
assert all(hashlib.sha256(Path(x['Path']).read_bytes()).hexdigest().upper()==x['Hash'] for x in task1)
assert 'NON-GEMINI VALIDATION COMPLETE' in read(R/'task2_gate_before_task3.json')['verdict']
result={'task':'Task 3','version':'0.1.1','verdict':'TASK 3 - NON-GEMINI VALIDATION COMPLETE','static':{'pass':29,'total':29},'rubric':{'pass':37,'not_applicable':1,'total':38},'independent_qc':'PASS','oracle':'PASS','negative_baselines':'PASS','docker_harbor':'PASS','originality':'PASS_SCOPED','external_qc_panel':'NOT RUN','gemini_permission':'NOT REQUESTED','gemini_trials':'NOT RUN','success_rate':'NOT MEASURED','task1_unchanged':True,'limitations':['External QC panel not run','Empirical agent difficulty and timed human completion unmeasured','Scoped originality, not global uniqueness'],'runtime_hashes':package['files']}
(R/'final_gate.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
(R/'final_validation.md').write_text('# TASK 3 - NON-GEMINI VALIDATION COMPLETE\n\nTask: Task 3\n\nTask Name: Certified Joint p-adic Valuation Census\n\nDomain: Mathematical Sciences / Formal Mathematics (computational number theory)\n\nOriginality: PASS within inspected scope\n\nTask Implementation: PASS\n\nOracle: PASS (two fresh canonical native repeats and direct standalone run)\n\nNegative Baselines: PASS; six reject the full task, with easy-case successes disclosed per case\n\nHidden-Test Discrimination: PASS; eight basic boundary controls, simple/parity diagnostics and the coarse-functional case explicitly identified\n\nDocker/Harbor: PASS; actual no-cache offline builds, resets, isolated verifier, source transfer, binary rewards and direct standalone execution\n\nStatic QC: 29/29 passed locally on hash-matched canonical staging; standalone all-rule Harbor lint []\n\nRubric QC: 37/38 passed locally; optional hint criterion not applicable\n\nIndependent QC: PASS; distinct fresh reviewer, reproduced findings and independent rechecks\n\nExternal QC: NOT RUN\n\nGemini Permission: NOT REQUESTED\n\nGemini Trials: NOT RUN\n\nObserved Success Rate: NOT MEASURED\n\nRemaining Issues: No unresolved available mandatory local defect. External panel approval, model calibration and timed human completion study remain unperformed.\n\nFinal Non-Gemini Verdict: VALIDATED\n\nOverall QC Approval: NOT RUN (external panel); local and independent non-Gemini gates pass.\n\nTask2 gate was completed before Task3 began; Task1 hashes remain unchanged. Raw reports distinguish local evidence from external approval.\n',encoding='utf-8')
(ROOT/'authoring/trajectories/status.json').write_text(json.dumps({'status':'NOT RUN','permission':'NOT REQUESTED','valid_agent_trials':0}),encoding='utf-8')
print(result['verdict'])
