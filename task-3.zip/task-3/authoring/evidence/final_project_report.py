"""Create the consolidated report only when both independent gates are closed."""
import json
from pathlib import Path
BASE=Path(r'F:\rl')
tasks=[json.loads((BASE/f'task-{i}/authoring/reports/final_gate.json').read_text(encoding='utf-8')) for i in (2,3)]
assert all('NON-GEMINI VALIDATION COMPLETE' in t['verdict'] for t in tasks)
target=BASE/'math-benchmark/TWO_TASKS_FINAL_REPORT.md'
assert not target.exists(),'Refusing to overwrite a prior report'
lines=['# Two original Mathematics tasks — final local validation report','',
       'Active standalone deliverables: F:/rl/task-2 and F:/rl/task-3. Both contain their own complete Harbor runtime, oracle, private evaluator, offline dependencies and author-only research/review evidence. Task1 is unchanged. No Gemini API call, provider calibration, GitHub push or publication occurred.','',
       'Task2 passed its final non-Gemini gate before Task3 was selected, designed or implemented. Task3 preserves the sequencing evidence. The older partial task-2 copy under math-benchmark is inactive history, not a third task. Descriptive canonical copies under each authoring/package directory exist only for repository-path QC and are hash-matched to the standalone files.','',
       '| Dimension | Task 2 | Task 3 |','|---|---|---|',
       '| Name | Certified Parametric Quadratic Optimizer Atlas | Certified Joint p-adic Valuation Census |',
       '| Field | Applied Mathematics | Formal Mathematics / computational number theory |',
       '| Scientific objective | Complete optimizer/value map over a parameter continuum | Complete joint local valuation distribution and all-precision simultaneous-root census |',
       '| Formulation | Strictly convex rational QP with affine two-parameter data | Two integer polynomials over Z/(p^N) |',
       '| Main concepts | KKT optimality, degeneracy, exact convex geometry | Singular local arithmetic, integer-valued polynomial periods, residue-prefix counting |',
       '| Input | Rational matrices, affine coefficients, parameter rectangle | Integer coefficient arrays, small prime and high precision |',
       '| Oracle | Exact active-set systems, half-plane clipping and subtraction | Coefficient-content digit recursion and sibling compression |',
       '| Independent verifier | Polynomial KKT identities, vertex inequalities and exact polygon coverage | Finite differences, functional period certificates, prefix-free full cover and exact population projection |',
       '| Invariants | Primal/dual feasibility, complementary slackness and optimal value | Capped local valuations, cylinder populations and lower-modulus fibers |',
       '| Failure modes | Missing thin regions, wrong multipliers, coverage gaps | Lost singular branches, function/content confusion, wrong correlations and population weights |',
       '| Positive alternatives | Triangulated/reordered atlas; independently checked split dual/collinear vertices | Refined/reordered partition; independently derived functional coarsening |',
       '| Hidden suite | 10 families,12 cases, with easy controls disclosed | 10 families,22 cases, including8 disclosed boundary controls |',
       '| Oracle / negative / native Harbor | PASS / PASS / PASS | PASS / PASS / PASS |',
       '| Static local QC | 29/29 PASS | 29/29 PASS |',
       '| Rubric local QC | 37/38 PASS; optional hint N/A | 37/38 PASS; optional hint N/A |',
       '| Independent QC | Distinct fresh-context agent; findings fixed/rechecked | Different fresh-context agent; findings fixed/rechecked |',
       '| External QC panel | NOT RUN | NOT RUN |',
       '| Gemini / observed model success | NOT RUN / NOT MEASURED | NOT RUN / NOT MEASURED |','']
for i,name,field in [(2,'Certified Parametric Quadratic Optimizer Atlas','Applied Mathematics'),(3,'Certified Joint p-adic Valuation Census','Formal Mathematics / computational number theory')]:
    lines += [f'## Task {i}','',f'**Task:** Task {i}',f'\n**Task Name:** {name}',f'\n**Domain:** Mathematical Sciences / {field}',
              '\n**Originality:** PASS within the inspected pinned/source/semantic scope; global uniqueness is not proved.',
              '\n**Task Implementation:** PASS','\n**Oracle:** PASS','\n**Negative Baselines:** PASS','\n**Hidden-Test Discrimination:** PASS; intentionally easy cases explicitly identified.',
              '\n**Docker/Harbor:** PASS; actual clean builds, native oracle repeats, controls, alternatives, isolation and standalone execution.',
              '\n**Static QC:** 29/29 passed locally; canonical layout staging is hash-matched to user-requested standalone root.',
              '\n**Rubric QC:** 37/38 passed locally; optional hint criterion is justified NOT APPLICABLE.',
              '\n**Independent QC:** PASS; distinct agent with original requirements/checklist access, independently reproduced findings and independent closure.',
              '\n**External QC:** NOT RUN','\n**Gemini Permission:** PENDING; awaiting explicit user approval.','\n**Gemini Trials:** NOT RUN','\n**Observed Success Rate:** NOT MEASURED',
              '\n**Remaining Issues:** No unresolved available mandatory local defect. External panel approval, empirical AI success rate and timed human completion study remain unavailable/deferred. Originality is scoped; independent QC is by an agent, not a human journal review.',
              '\n**Final Non-Gemini Verdict:** VALIDATED','\n**Overall QC Approval:** NOT RUN',
              f'\nEvidence: [final gate](F:/rl/task-{i}/authoring/reports/final_validation.md), [native Harbor](F:/rl/task-{i}/authoring/reports/harbor_validation.md), [static](F:/rl/task-{i}/authoring/reports/static_qc_audit.md), [rubric](F:/rl/task-{i}/authoring/reports/rubric_qc_audit.md), [independent review](F:/rl/task-{i}/authoring/reports/independent_qc_review.md), [originality](F:/rl/task-{i}/authoring/plagiarism/reports/plagiarism_report.md).','']
lines += ['## Limits and next approval','',
          'Actual evidence is separated into portable mathematics checks, native Docker/Harbor runs, source/static checks, independent review and external approval. Historical failed attempts and remediations are retained; documentation-only checksum changes are disclosed. The scope does not include a successful external model-based QC panel. The active local checklist has29static and38rubric checks; the pinned upstream rubric has2 additional empirical difficulty/time criteria that remain unmeasured.','',
          'Both expert16-hour and junior80-hour estimates are unmeasured judgments. Expert/very-high difficulty is a design assessment, not an observed model success rate. Easy controls, normal diagnostics and metamorphic duplicates are not counted as independent hard instances. No aggregate cross-task success rate is invented.','',
          'Optional calibration requires explicit user approval. Proposed scaffold: Terminus-2, gemini/gemini-3.8-flash (high reasoning, backend-default temperature, native web tools disabled), subject to explicit approval and verified free-tier account eligibility, one fresh connectivity/terminal/grading smoke test per task, then8 independent valid trials per task with fixed model/settings/task version/resources and separate trajectories. Provider/rate-limit failures are excluded from mathematical outcomes and retained separately. No paid fallback or model switch is authorized. The exact available model identifier and free-tier conditions must be verified before any approved API execution.','',
          'Reproduction instructions are in each task’s authoring/REPRODUCING.md. Bundled hash-pinned wheels avoid trial/build dependency downloads. The pinned base image must be cached or reachable. Both standalone roots can be passed directly to Harbor.','']
target.write_text('\n'.join(lines),encoding='utf-8')
print(target)
