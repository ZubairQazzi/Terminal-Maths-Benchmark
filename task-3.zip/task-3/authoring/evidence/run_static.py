"""Run actual vendored upstream shell checks offline in the verifier image."""
import json
from pathlib import Path
import subprocess
ROOT=Path('/work')
TASK='tasks/mathematical-sciences/formal-mathematics/certified-padic-census'
rules=['task-fields','task-path','task-structure','task-slug','task-readme','canary',
       'task-absolute-path','instruction-suffix','test-file-references','dockerfile-references',
       'dockerfile-sanity','dockerfile-platform','allow-internet','separate-verifier','compose-host-binds',
       'task-timeout','gpu-types','task-resources','verifier-resources','nproc','verifier-tooling-baked',
       'trial-network-fetch','pip-pinning','pytest-version','test-sh-sanity','binary-reward']
rows=[]
for name in rules:
    script=Path('ci_checks')/('check-'+name+'.sh')
    p=subprocess.run(['bash',str(script),TASK],capture_output=True,text=True,timeout=60)
    rows.append({'check':name,'exit_code':p.returncode,'output':p.stdout+p.stderr})
    print(name,p.returncode,flush=True)
(ROOT/'authoring/reports/upstream_static.json').write_text(json.dumps(rows,indent=2))
