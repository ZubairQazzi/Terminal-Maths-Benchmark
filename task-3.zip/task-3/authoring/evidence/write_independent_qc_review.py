"""Record the independent reviewer's criterion-by-criterion judgments."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
REPORT = ROOT / 'authoring/reports'


def cite(file, text):
    lines = (ROOT / file).read_text(encoding='utf-8-sig').splitlines()
    return f'{file}:{next(i for i, line in enumerate(lines, 1) if text in line)}'


def row(id, behavior, evidence, citations, status='PASS', correction='None required', recheck='Independent source/evidence assessment complete'):
    return {'id': id, 'required_behavior': behavior, 'status': status,
            'actual_evidence': evidence, 'citations': citations,
            'required_correction': correction, 'verification_after_correction': recheck}


package = json.loads((REPORT / 'independent_qc_package.json').read_text())
current = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
           for name in package['runtime_hashes']}
assert current == package['runtime_hashes'], 'Package changed after independent hash check'
native = json.loads((REPORT / 'native_summary.json').read_text())
assert native['success'] and native['suffix'] == 'v011' and len(native['trials']) == 9
raw_trials = []
for t in native['trials']:
    raw = json.loads((ROOT / t['path']).read_text())
    assert raw['task_checksum'] == t['checksum']
    assert raw['verifier_result']['rewards']['reward'] == t['reward']
    ctrf = json.loads((ROOT / t['path']).parent.joinpath('verifier/ctrf.json').read_text())
    assert ctrf['results']['summary'] == t['ctrf']
    assert len(ctrf['results']['tests']) == 10
    reward = (ROOT / t['path']).parent.joinpath('verifier/reward.txt').read_text().strip()
    assert reward in ('0', '1') and int(reward) == t['reward']
    raw_trials.append({'path': t['path'], 'reward': reward, 'ctrf_summary': t['ctrf']})
standalone = list((REPORT / 'harbor-jobs/standalone-v011').glob('*/result.json'))
assert len(standalone) == 1
standalone_raw = json.loads(standalone[0].read_text())
assert standalone_raw['verifier_result']['rewards']['reward'] == 1
assert Path(standalone_raw['config']['task']['path']).resolve() == ROOT.resolve()
standalone_ctrf = json.loads(standalone[0].parent.joinpath('verifier/ctrf.json').read_text())
assert standalone_ctrf['results']['summary']['passed'] == 10

static = []
rule_records = json.loads((REPORT / 'upstream_static.json').read_text())
static_behaviors = {
    'entry-files': 'Required Harbor entry files exist.',
    'config-fields': 'Manifest fields and structure are supported by installed Harbor.',
    'task-fields': 'Publication metadata and required task fields are present.',
    'task-path': 'Canonical repository path matches manifest domain and field.',
    'task-structure': 'Runtime, grading and authoring contents occupy their proper directories.',
    'task-slug': 'Canonical task slug is concise valid kebab case.',
    'task-readme': 'Managed README header and required authored sections are current.',
    'canary': 'Eligible sources carry the active profile marker.',
    'task-absolute-path': 'Solver-facing input and deliverable paths are absolute.',
    'instruction-suffix': 'Canonical closing paragraph agrees with agent timeout.',
    'instruction-similarity': 'Pinned-corpus comparison is below the investigation threshold.',
    'test-file-references': 'Submission paths consumed by grading are public.',
    'dockerfile-references': 'Docker COPY and ADD sources exist in their build contexts.',
    'dockerfile-sanity': 'Dockerfiles avoid prohibited build patterns.',
    'dockerfile-platform': 'No hardcoded processor platform is requested.',
    'allow-internet': 'Declared solver and verifier network policies comply with profile.',
    'separate-verifier': 'Separate verifier and artifact transfer are declared.',
    'compose-host-binds': 'Task supplies no prohibited host directory mounts.',
    'task-timeout': 'Manifest timeouts conform to the active rules.',
    'gpu-types': 'GPU declaration is valid.',
    'task-resources': 'Solver resources are explicitly declared within supported limits.',
    'verifier-resources': 'Separate verifier resources and network policy are explicit.',
    'nproc': 'Scripts do not use bare host processor counts.',
    'verifier-tooling-baked': 'Verifier tools are available before grading begins.',
    'trial-network-fetch': 'Grading performs no live dependency fetch.',
    'pip-pinning': 'Python requirements are pinned.',
    'pytest-version': 'Required pytest and CTRF versions are used.',
    'test-sh-sanity': 'Verifier entry script follows grading conventions.',
    'binary-reward': 'Reward output is exactly binary.'}
runtime_citations = {
    'task-fields': ('task.toml', '[task]'), 'task-path': ('task.toml', 'domain ='),
    'task-structure': ('authoring/README.md', 'standalone root'),
    'task-slug': ('task.toml', 'name = "terminal-bench'),
    'task-readme': ('README.md', 'Managed header'),
    'canary': ('instruction.md', 'harbor-canary'),
    'task-absolute-path': ('instruction.md', '/app/submission/solve.py'),
    'instruction-suffix': ('instruction.md', 'You have 28800'),
    'test-file-references': ('environment/spec.md', 'Place the entry point'),
    'dockerfile-references': ('environment/Dockerfile', 'COPY requirements'),
    'dockerfile-sanity': ('tests/Dockerfile', 'FROM python'),
    'dockerfile-platform': ('environment/Dockerfile', 'FROM python'),
    'allow-internet': ('task.toml', 'network_mode = "no-network"'),
    'separate-verifier': ('task.toml', 'environment_mode ='),
    'compose-host-binds': ('environment/Dockerfile', 'WORKDIR'),
    'task-timeout': ('task.toml', 'timeout_sec = 28800'),
    'gpu-types': ('task.toml', 'gpus = 0'),
    'task-resources': ('task.toml', 'cpus = 2'),
    'verifier-resources': ('task.toml', '[verifier.environment]'),
    'nproc': ('tests/harness.py', "'OMP_NUM_THREADS':'1'"),
    'verifier-tooling-baked': ('tests/Dockerfile', '--no-index'),
    'trial-network-fetch': ('tests/test.sh', 'python3 -I -m pytest'),
    'pip-pinning': ('tests/requirements.txt', 'sympy==1.14.0'),
    'pytest-version': ('tests/requirements.txt', 'pytest==8.4.1'),
    'test-sh-sanity': ('tests/test.sh', 'set -u'),
    'binary-reward': ('tests/test.sh', "printf '0")}
for id, behavior in static_behaviors.items():
    if id == 'entry-files':
        ev = 'Independent check found all five required entries and 27 purposeful runtime files.'
        refs = [cite('authoring/reports/independent_qc_package.json', 'entry_files')]
    elif id == 'config-fields':
        ev = 'Independent allowed-field audit passes; actual standalone Harbor ALL lint returns []; schema 1.4 executes successfully.'
        refs = [cite('authoring/reports/independent_qc_package.json', 'supported_manifest_field_check'),
                cite('authoring/reports/harbor_standalone_lint_v011.log', '[]')]
    elif id == 'instruction-similarity':
        ev = 'Actual upstream TF-IDF comparison against 99 pinned references has maximum cosine 0.5663107729740071 < 0.80; semantic/source review finds generic execution-contract overlap, not shared distinctive mathematics.'
        refs = [cite('authoring/plagiarism/reports/plagiarism_report.json', 'tfidf_max_cosine')]
    else:
        assert next(r for r in rule_records if r['check'] == id)['exit_code'] == 0
        ev = 'Pinned upstream implementation recorded exit 0; independently inspected the cited source and byte-matched canonical packaging.'
        if id in ('task-path', 'task-slug', 'task-structure'):
            ev += ' Path rules apply to descriptive canonical staging; the task-3 wrapper is the user-requested standalone delivery path.'
        refs = [cite('authoring/reports/upstream_static.json', f'"check": "{id}"'), cite(*runtime_citations[id])]
    static.append(row(id, behavior, ev, refs))

R = lambda f, text: cite(f, text)
rubric_data = [
 ('well_specified', 'A domain expert can determine the exact mathematical and execution contract.',
  'Complete cylinder, histogram, projection, encoding and execution specification. F1 corrected the potentially binding file-size/descriptor omission; implementation and public contract now agree.',
  [R('environment/spec.md','Each invocation'), R('tests/harness.py',"('CPU',300)")]),
 ('test_instruction_alignment', 'Each scored assertion maps to a public requirement.',
  'Leaf bounds, exact functional labels, disjoint coverage, all nonzero histogram cells, all precision counts, id set, output size, source portability and execution limits all map to the public specification. F1 closed.',
  [R('environment/spec.md','leaves`:'), R('tests/certificates.py','def verify'), R('tests/harness.py','assert out.stat')]),
 ('instruction_clarity', 'Instructions state outcomes concisely without a prescribed mathematical method or reward narration.',
  'The requested reusable program, full census, exactness and absolute paths are clear; the detailed specification gives load-bearing requirements. No hidden-grader/reward bookkeeping is exposed. Added F1 limits are concise deliverable constraints.',
  [R('instruction.md','Create a reusable'), R('environment/spec.md','Each invocation')]),
 ('structured_data_schema', 'Structured input/output fields, types and layouts are explicit.',
  'Schemas match what the checker reads. Integer scalars reject bool/float and accept signed zero-padded decimal strings; independent alternative string encoding passed.',
  [R('environment/spec.md','All output mathematical'), R('tests/certificates.py','def integer'), R('authoring/reports/independent_qc_probes.json','signed_zero_padded_output')]),
 ('typos', 'Critical identifiers, paths and commands refer to the intended objects.',
  'Source inspection, actual restricted native invocation and standalone Harbor execution found no broken identifiers. Compact prose spacing in author reports does not alter identifiers or mathematics.',
  [R('tests/harness.py','subprocess.Popen'), R('solution/solve.sh','cp /solution/solve.py')]),
 ('hint_discoverability', 'Optional hints contain only discoverable nonprivileged information.',
  'No authoring/hint.md is supplied; the governing rubric explicitly permits N/A.', [R('instruction.md','Construct an exact')]),
 ('scientifically_grounded', 'The actual work is a research-relevant mathematical computation.',
  'Local polynomial root counting and valuation strata relate to p-adic integration and singular congruence fibers. Primary research corroborates the root-counting/Igusa connection; the benchmark uses synthetic arithmetic inputs and requires a genuine local-arithmetic algorithm.',
  [R('README.md','Computational number theorists'), R('authoring/research/task_proposal.md','Primary research')]),
 ('scope', 'The subject belongs to its declared scientific domain/field.',
  'Exact, independently checked finite mathematical certificates are computational number theory in mathematical sciences/formal mathematics. The package does not imply it is a Lean formalization.',
  [R('task.toml','field ='), R('authoring/research/mathematical_justification.md','without claiming a Lean')]),
 ('essential_difficulty', 'Difficulty comes from mathematics rather than arbitrary formatting or a narrow numerical tolerance.',
  'Singular lifting, dead branches, correlated valuations and exact projection supply the substantive work. Exact integers and compression are mathematically necessary. The expert/very-high label remains an uncalibrated design judgment.',
  [R('README.md','Singular Hensel branches'), R('environment/spec.md','There is no numerical tolerance')]),
 ('novel', 'Memorized public answers do not replace the required new computation.',
  'Scoped 99-instruction and code comparisons, semantic comparison to captured Task1/Task2 materials, and direct source inspection found no shared distinctive formulation or scientific implementation. Classical identities and generic isolation are openly reused. No global uniqueness claim is made.',
  [R('authoring/plagiarism/reports/plagiarism_report.json','instruction_count'), R('authoring/plagiarism/reports/plagiarism_report.md','Generic process isolation')]),
 ('agentic', 'The problem calls for implementation, exploration and computational validation.',
  'A reusable exact solver must be developed and tested against exponentially large residue rings, cancellation and singular edge behavior. The task naturally requires terminal computation/debugging; inability of every possible model to solve it in one generation is not empirically established.',
  [R('instruction.md','Create a reusable'), R('README.md','Singular Hensel branches')]),
 ('verifiable', 'Concrete scientific outputs can be checked reliably and efficiently.',
  'Independently proved the finite-difference/prime-power-period certificate. 309096 certificate decisions matched actual finite-cylinder valuations; 285 independently generated partitions passed; exact prefix/count invariants complete the proof.',
  [R('tests/certificates.py','def certify'), R('authoring/reports/independent_qc_probes.json','certificate_comparisons')]),
 ('solvable', 'A genuine working solution passes within available resources.',
  'All nine final native trials inspected directly; both oracle repeats and the valid alternative score 1. Standalone root also scores 1. Independent maximum-bound eight-case native stress passes in about 1.01 seconds; degree-mass argument bounds reference leaves by 9217.',
  [R('solution/solve.py','def solve'), R('authoring/reports/independent_qc_native_v011.json','native_result'), R('authoring/research/mathematical_justification.md','An a priori reference leaf bound')]),
 ('outcome_verified', 'Any mathematically valid method/representation can earn full credit.',
  'Checker uses original-polynomial functional values and exact counts, never reference leaf choices. Refined/reordered output passes natively. Independent whole-ring coarse cancellation certificate and independently enumerated partitions also pass.',
  [R('tests/certificates.py','def certify'), R('authoring/reports/independent_qc_probes.json','naive_coefficient_counterexample')]),
 ('functional_verification', 'The evaluator checks actual behavior and scientific output.',
  'Candidate runs as a subprocess; the result is parsed and every mathematical certificate/count is checked. Source-keyword matching is absent.',
  [R('tests/harness.py','subprocess.Popen'), R('tests/harness.py','detail={')]),
 ('ground_truth_provenance', 'The origin of scientific truth is auditable and independent of oracle output.',
  'No expected histogram or answer file is used. Deterministic polynomial inputs are generated in cases.py; finite-difference proof checks original coefficients. Independent plain-integer enumeration crosschecks provide additional truth.',
  [R('tests/cases.py','def batches'), R('tests/certificates.py','polys='), R('authoring/reports/independent_qc_probes.json','method')]),
 ('graded_instances_discriminate', 'Trivial guesses fail substantive cases; easy members are disclosed individually.',
  'All-root guess reaches exactly three disclosed all-residue controls. Eight boundary controls, simple lifting, coarse-functional, dead-two parity and nonmonic diagnostics are explicit. Independent per-case results disclose which incomplete methods pass individual members; singular/cluster/content/large/correlation cases defeat them and all six negative full trials score 0.',
  [R('authoring/reports/test_coverage.md','dead-two'), R('authoring/reports/test_discrimination_audit.md','all-singular shortcut'), R('authoring/reports/independent_qc_per_case.json','accepted')]),
 ('solution_quality', 'The reference derives its answers by genuine computation.',
  'Coefficient-content recursion, digit substitution, sibling coalescing and exact histogram projection derive results from arbitrary inputs. The shell merely installs this source; no fixed expected answer is emitted.',
  [R('solution/solve.py','def classify'), R('solution/solve.py','def solve'), R('solution/solve.sh','cp /solution')]),
 ('do_not_modify_enforced', 'Protected artifact/source constraints cannot be bypassed for advantage.',
  'Read-only source portability is enforced by a root-owned copied source tree, permissions 0755 and uid65534 child. Pristine input/test sources reside in separate verifier state; changed agent files cannot redefine the mathematics.',
  [R('environment/spec.md','read-only source-directory'), R('tests/harness.py','for p in program.rglob'), R('tests/harness.py','os.setgroups')]),
 ('deterministic_reproducible', 'Pinned builds and repeat runs give the same scientific result.',
  'Pinned base digest, hash-checked offline wheel installs and fixed generator seed; both final fresh oracle repeats have the same checksum/reward. Independent wheel-byte audit passes. No stochastic acceptance threshold or live scientific service exists.',
  [R('environment/Dockerfile','FROM python'), R('tests/cases.py','random.Random'), R('authoring/reports/independent_qc_package.json','all_bundled_dependency_hashes_match')]),
 ('separate_verifier_configured', 'Verifier receives every required artifact and has its tools preinstalled.',
  'Only /app/submission transfers. Inputs/checker/harness are baked under /tests; installed libraries/base digests match. All native and standalone executions use separate mode with complete artifacts.',
  [R('task.toml','artifacts ='), R('task.toml','environment_mode'), R('tests/Dockerfile','COPY . /tests/')]),
 ('verifier_execution_isolation', 'Candidate code is unprivileged and cannot reach grading state.',
  'Actual native probe records uid/gid65534, empty groups, denied private tests and reward access, CPU/AS/descriptor limits and no credential variables. Root never imports candidate code. Logs are files and the process group is killed after execution.',
  [R('tests/harness.py','def restrict'), R('tests/harness.py','os.killpg'), R('authoring/reports/security_probe.json','private_tests')]),
 ('anti_cheat_robustness', 'Shortcuts cannot forge scientific success or access private answers.',
  'Fresh unique input/output paths, copied read-only sources, private exact checker and root-only score; hardcoded public lookup and all five other flawed strategies score 0. No secret expected answer is present in the agent image.',
  [R('tests/harness.py','TemporaryDirectory'), R('tests/test.sh','chmod -R'), R('authoring/reports/security_probe.json','agent_files')]),
 ('task_security', 'Runtime files perform only legitimate task setup/execution and avoid secrets/host access.',
  'No credential-store reads, exfiltration, hostile startup hooks, host mounts or external task-time downloads occur. The child receives an explicit small environment and verifier networking is disabled. Author validation uses local Docker, not a task-provided host mount.',
  [R('tests/harness.py',"env={'PATH'"), R('task.toml','network_mode = "no-network"'), R('environment/Dockerfile','COPY spec.md')]),
 ('resource_configuration', 'Resources permit valid approaches and do not manufacture difficulty.',
  '2 CPUs/4GiB container budgets, 300-second/2GiB per-process contract, no GPU. Independent eight-case degree12/N64/1000-digit native run takes 1.01s, far below caps; the 3600s verifier accommodates ten potentially timed-out invocations.',
  [R('task.toml','timeout_sec = 3600'), R('environment/spec.md','Each invocation'), R('authoring/reports/independent_qc_native_v011.json','seconds')]),
 ('task_toml_schema', 'Only supported manifest fields appear.',
  'Independently checked every section/key against the governing supported-field list; real Harbor0.27 schema1.4 ALL lint is empty and final standalone execution succeeds. Missing human contributor credentials are disclosed, not invented.',
  [R('authoring/reports/independent_qc_package.json','supported_manifest_field_check'), R('task.toml','author_email')]),
 ('environment_hygiene', 'Agent image has necessary tools/data and no private solution/grading files.',
  'Docker copies only spec/example/pinned runtime libraries into agent image. Actual leakage probe enumerates only spec/example under /app and confirms private solution/tests absent. Grader tools are baked only in the separate verifier, consistent with the newer separate-verifier rule.',
  [R('environment/Dockerfile','COPY spec.md'), R('authoring/reports/security_probe.json','agent_files')]),
 ('artifact_efficiency', 'Only necessary candidate-produced artifacts transfer and failures cannot reuse stale output.',
  'Only self-contained submission sources transfer; no dependencies, datasets or fixed image tree. Each invocation creates a fresh output path, requires it to exist and validates size/type. No fragile collect/apply hook is involved.',
  [R('task.toml','artifacts ='), R('tests/harness.py','out=work/'), R('tests/harness.py',"'missing output'")]),
 ('ctrf_reporting', 'Every applicable discrete family reports a CTRF result.',
  'Every final native trial has ten named CTRF test records consistent with reward/pass counts. Raw CTRF, reward and result.json were independently crosschecked, including the standalone root trial.',
  [R('tests/test.sh','--ctrf'), R('tests/test_outputs.py',"globals()['test_'"), R('authoring/reports/native_summary.json','"tests": 10')]),
 ('task_authoring_dir', 'Review-only code/data live outside executable runtime contexts.',
  'Research, package staging, captured public corpus, baseline drivers and this independent review live under authoring. Every runtime Python file is executed/imported by the reference or tests; no trial depends on authoring.',
  [R('authoring/README.md','outside both image contexts'), R('tests/test_outputs.py','from cases'), R('solution/solve.sh','cp /solution')]),
 ('no_extraneous_files', 'Runtime package contains only purposeful scaffold, code/data or permitted documentation.',
  'Independent inventory finds 27 runtime files: required scaffold/README, actual modules, one input example, requirement locks and wheel bundles consumed during offline builds. No runtime pycache, backup, unused corroborator or author-only code is staged.',
  [R('authoring/reports/independent_qc_package.json','runtime_file_count'), R('environment/Dockerfile','COPY wheels/')]),
 ('reviewable', 'A reviewer can trace assumptions and calculations to correct results.',
  'Specification, distinct oracle/checker, primary sources, proof derivation, leaf bound, generated cases and raw native evidence permit a complete trace. Independent finite-ring labels were calculated without the reference recursion.',
  [R('authoring/research/mathematical_justification.md','Newton'), R('authoring/evidence/independent_qc_probes.py','def independent_result')]),
 ('difficulty_explanation_quality', 'README identifies concrete scientific challenges and the realistic workflow.',
  'README names computational number theorists, synthetic local-arithmetic examples, singular lifting, correlations and projection multiplicities. It explicitly disclaims measured expert time and calibrated model success.',
  [R('README.md','Computational number theorists'), R('README.md','unmeasured expert estimate')]),
 ('solution_explanation_quality', 'README accurately explains the reference strategy and key insights.',
  'The coefficient-content criterion, unresolved digit recursion, sibling merging and projection explanation matches actual solve.py. It neither claims a different algorithm nor hides a hardcoded answer.',
  [R('README.md','The reference recursively'), R('solution/solve.py','def classify')]),
 ('verification_explanation_quality', 'README explains what checks suffice and accounts for valid/invalid alternatives.',
  'Functional finite-difference period proof, prefix cover and exact population projection match the checker. Refined/reordered and independent coarse certificates pass; actual flawed methods fail and their partial successes are disclosed. No empirical tolerance calibration is required for these exact identities.',
  [R('README.md','The independent checker'), R('authoring/reports/test_discrimination_audit.md','coarse-functional'), R('authoring/reports/independent_qc_probes.json','independent_partition_cases')]),
 ('category_and_tags', 'Classification accurately identifies the science and methods.',
  'Mathematical sciences/formal mathematics with computational number theory subfield; p-adic, singular-lifting and exact-certificates tags are specific to the work.',
  [R('task.toml','domain ='), R('task.toml','tags =')]),
 ('task_name', 'Published canonical name is specific, concise and compliant.',
  'certified-padic-census describes the certified local distribution in three valid tokens. The generic task-3 outer path is the user-required standalone wrapper, not the published slug.',
  [R('task.toml','name = "terminal-bench'), R('authoring/README.md','standalone root')]),
 ('task_readme', 'README provides accurate additional reviewer context.',
  'Current generated header plus scientific difficulty, actual reference and independent verification explanations match the implementation. It discloses easy controls, isolation and empirical limitations.',
  [R('README.md','Managed header'), R('README.md','## Verification')]),
]
rubric = [row(id, behavior, evidence, citations,
              status='NOT APPLICABLE' if id == 'hint_discoverability' else 'PASS',
              correction='F1: disclose file-size/descriptor limits' if id in ('well_specified', 'test_instruction_alignment') else
                         'F2/I2: disclose and measure easy individual diagnostics' if id == 'graded_instances_discriminate' else 'None required',
              recheck='Closed after independent source, byte-match and native v0.1.1 recheck' if id in ('well_specified', 'test_instruction_alignment', 'graded_instances_discriminate') else 'Independent source/evidence assessment complete')
          for id, behavior, evidence, citations in rubric_data]
assert len(static) == 29 and len(rubric) == 38
assert len({r['id'] for r in static + rubric}) == 67
checklist = (ROOT / 'authoring/inputs/QC-CHECKLIST.md').read_text()
assert all('`' + r['id'] + '`' in checklist for r in static + rubric)
findings = [
    {'id': 'F1', 'initial_status': 'FAIL', 'final_status': 'CLOSED',
     'criteria': ['well_specified', 'test_instruction_alignment'],
     'finding': 'The harness imposed potentially binding 64MiB per-file and 128-descriptor limits absent from the otherwise detailed execution contract.',
     'initial_evidence': [R('tests/harness.py',"('CPU',300)")],
     'fix': 'Creator added concise public deliverable constraints in environment/spec.md, preserving the checker and safety limits.',
     'independent_recheck': [R('environment/spec.md','Each invocation'), R('authoring/reports/independent_qc_package.json','F1_contract_disclosure_recheck'), R('authoring/reports/independent_qc_native_v011.json','native_result')]},
    {'id': 'I2', 'initial_status': 'ADVISORY', 'final_status': 'CLOSED',
     'criteria': ['test_instruction_alignment', 'solvable', 'graded_instances_discriminate'],
     'finding': 'Initial shipped cases did not exercise signed/zero-padded inputs, N1, max8case batching or exact1000-digit coefficients; no actual unsupported-input defect was established.',
     'fix': 'Creator expanded controls from2 to8 explicit non-discriminating boundary diagnostics. Reviewer independently stressed8 degree12/N64/1000-digit cases and compared small rings.',
     'independent_recheck': [R('tests/cases.py','big=10**999'), R('authoring/reports/independent_qc_native_v011.json','cases'), R('authoring/reports/independent_qc_probes.json','upper_bound_batch')]},
    {'id': 'F2', 'initial_status': 'DOCUMENTATION CORRECTION', 'final_status': 'CLOSED',
     'criteria': ['graded_instances_discriminate', 'difficulty_explanation_quality'],
     'finding': 'Family-level reporting hid that dead-two is solved by a shallow parity partition; the simple-only baseline also retains full recursion when nonsingular roots are present.',
     'fix': 'Creator identifies dead-two and nonmonic-seven as basic diagnostics and precisely describes the all-singular shortcut. Independent per-case baseline outcomes are linked, rather than treating every family member as an expert challenge.',
     'independent_recheck': [R('authoring/reports/test_coverage.md','dead-two'), R('authoring/reports/test_discrimination_audit.md','all-singular shortcut'), R('authoring/reports/independent_qc_per_case.json','accepted')]},
]
limitations = [
    'External QC dashboard/panel NOT RUN; this is one distinct local independent reviewer plus measured evidence, not fabricated two-vote external approval.',
    'Gemini, paid APIs and model calibration NOT RUN. Target40-60% success is NOT MEASURED.',
    'Upstream rubric additionally contains difficult and expert_time_estimate beyond the user38. The 16-hour estimate and expert/very-high design judgment have not been validated by timed human studies; empirical aspects remain NOT TESTED.',
    'Originality is scoped to captured public research,97 pinned public instructions plus Task1/Task2 and selected source comparisons; no proof of global uniqueness or exhaustive private-corpus search.',
    'Exhaustive probes cover2660 small-ring polynomial inputs and309096 certificate decisions, not every allowed huge instance. Universal checker soundness and the reference leaf bound are supported by mathematical arguments, with native upper-bound stress as corroboration.',
    'Path/slug static checks apply to byte-matched canonical staging inside authoring; the standalone task-3 root is separately validated by real Harbor as explicitly requested by the user.',
]
document = {'reviewer': {'identity': '/root/task3_independent_qc', 'role': 'Distinct independent QC subagent, not task creator',
                         'context': 'Fresh delegated context; inspected original user request, checklist, prior feedback and runtime sources before creator explanations. Initial record preserved separately.',
                         'authorized_tools': 'Local source inspection, Python, offline Docker, inspection of raw Harbor evidence, primary-source web reading; no Gemini/paid model/API or publication.'},
            'task': 'Task3 / certified-padic-census', 'version': '0.1.1',
            'checklist': {'path': 'authoring/inputs/QC-CHECKLIST.md', 'sha256': hashlib.sha256((ROOT/'authoring/inputs/QC-CHECKLIST.md').read_bytes()).hexdigest(),
                          'static_count': 29, 'rubric_count': 38,
                          'actual_upstream_rubric': 'authoring/research/upstream/rubrics/task-implementation.toml; read in addition to supplied checklist'},
            'verdict': 'PASS — locally executable non-Gemini independent review',
            'static_summary': dict(Counter(r['status'] for r in static)),
            'rubric_summary': dict(Counter(r['status'] for r in rubric)),
            'initial_findings_record': 'authoring/reports/independent_initial_findings.json',
            'findings': findings, 'static_criteria': static, 'rubric_criteria': rubric,
            'raw_native_trials_independently_crosschecked': raw_trials,
            'standalone_trial': {'path': str(standalone[0].relative_to(ROOT)), 'reward': 1, 'ctrf_passed': 10},
            'runtime_hashes': current, 'limitations': limitations,
            'primary_sources_checked': [
                {'url': 'https://kconrad.math.uconn.edu/blurbs/gradnumthy/mahlerexpansions.pdf', 'assessment': 'Theorem2.1 and finite-difference formulas support the binomial-basis foundation. The finite-degree period specialization was proved independently here.'},
                {'url': 'https://people.math.harvard.edu/~elkies/Misc/mahler.pdf', 'assessment': 'Independent primary exposition of binomial expansions for p-adic maps; consistent with the finite-polynomial specialization.'},
                {'url': 'https://msp.org/obs/2019/2-1/obs-v2-n1-p12-p.pdf', 'assessment': 'Published Cheng/Gao/Rojas/Wan paper supports root-counting and Igusa-zeta research relevance; not a claim that this task implements its general algorithm.'}],
            'non_changes': 'Reviewer edited only author-only evidence/reports inside Task3; no runtime/oracle/tests, Task1 or Task2 files were edited.'}
(REPORT/'independent_qc_findings.json').write_text(json.dumps(document, indent=2)+'\n', encoding='utf-8')
out = ['# Independent Task3 QC review', '',
       'Final local verdict: **PASS** for Task3 v0.1.1. **29/29 static PASS;37/38 rubric PASS;1 justified NOT APPLICABLE (optional hints).** All67 requested criteria were assessed. External QC approval and empirical model difficulty remain unmeasured.', '',
       'Reviewer: `/root/task3_independent_qc`, a distinct fresh-context subagent, not the creator. I read the original request, complete governing checklist and prior feedback directly. I inspected instruction/spec/manifest/oracle/checker/cases/harness/Docker before reading creator explanations; `independent_initial_findings.json` preserves that stage. No Gemini or paid API, model trial or publishing was used. Runtime, Task1 and Task2 files were not edited by this reviewer.', '',
       '## Mathematical conclusions', '',
       'For a cylinder polynomial H(t)=f(r+p^k t), its first d+1 samples determine the Newton coefficients. Divisibility of those coefficients by p^v makes H/p^v integer-valued. For T=p^e>d, every binomial(T,j),1<=j<=d, is divisible by p; Vandermonde therefore makes H/p^v periodic modulo p with period T. Testing one entire period for nonzero values proves exact valuation v. Saturation v=N needs divisibility alone. Computing samples modulo p^N preserves these divisibility statements and, when v<N, preserves the normalized sample modulo p. Sampling beyond the finite cylinder representatives is safe because integer polynomials respect congruences modulo p^N. This independently validates the checker, including functional coarsenings that coefficient content misses.', '',
       'The prefix tree proves disjointness, and disjoint cylinder weights summing to p^N prove complete coverage. Projection to modulus p^s has constant fiber size p^(N-s), so the reported root-count formula is exact. The reference independently uses coefficient-content/digit recursion. Residue-root multiplicities bound surviving reduced-degree mass; at most24 unresolved branches occur at any level for the polynomial pair. At most24N split nodes give <=1+(p-1)24N<=9217 leaves, below20000. The degree and fixed-prime bounds therefore make full residue enumeration unnecessary.', '',
       'Independent probes made **309096** cylinder-certificate comparisons across **2660** small polynomial/ring cases, accepted **285** independently enumerated partitions and crosschecked **285** oracle histograms/root-count vectors. There were no false accepts/rejects. A whole-ring functional cancellation certificate was accepted, and an insufficient-period trap was rejected. Signed/zero-padded output scalars passed. Eight simultaneous degree12/N64/1000-digit cases passed the actual uid65534 native v0.1.1 harness in **1.01s** (maximum701 leaves; portable output73559bytes). These are corroborating measurements, not exhaustive testing of all huge inputs.', '',
       '## Findings, fixes and independent rechecks', '']
for f in findings:
    out += [f"- **{f['id']} — {f['final_status']}**: {f['finding']} {f['fix']} Rechecked: " + '; '.join(f['independent_recheck']) + '.', '']
out += ['The per-case audit records partial successes honestly: the shallow grid passes dead-two/coarse-functional; the all-singular shortcut passes nonsingular/mixed-root members; marginal multiplication happens to be correct on some independent/degenerate members. These do not pass the full conjunctive task. All-root guesses pass exactly three disclosed controls. The22 cases are not advertised as22 independent expert-level problems.', '',
        '## Actual execution and packaging evidence', '',
        'I crosschecked all nine raw v011 Harbor trial result.json files against their reward.txt and complete ten-record CTRF reports: two oracle repeats and one valid alternative score1; no-op, all-root constant, hardcoded public lookup, shallow grid, all-singular shortcut and wrong-marginal strategies score0. The direct standalone task-3 Harbor trial also scores1 with10/10 families, and standalone ALL lint returns[]. Clean no-cache build logs and the actual security probe show pinned offline dependencies, uid/gid65534 with empty groups, denied private-test/reward access and no forwarded credential variables.', '',
        'Independent packaging inspection confirms27 purposeful runtime files, exact standalone/canonical staging/manifest byte agreement, supported manifest fields and every bundled wheel hash. The26 recorded actual upstream shell checks each return0; entry/config/similarity supply the other three local static criteria. Canonical path checks refer to the descriptive repository-shaped staging; direct standalone execution was additionally tested. These are local results, not an external panel verdict.', '',
        '## Criterion-level audit', '',
        'Each row includes the actual evidence and exact source citation. The JSON companion records required behavior, corrections and recheck outcomes separately for every criterion.', '',
        '| Group / criterion | Status | Independent evidence |', '|---|---|---|']
for group, records in [('Static', static), ('Rubric', rubric)]:
    for r in records:
        out.append(f"| {group} / `{r['id']}` | {r['status']} | {r['actual_evidence']} {'; '.join(r['citations'])} |")
out += ['', '## Limits of this verdict', ''] + ['- '+x for x in limitations]
out += ['', 'Primary-source checks: [Conrad, Mahler Expansions](https://kconrad.math.uconn.edu/blurbs/gradnumthy/mahlerexpansions.pdf) and [Elkies, Mahler theorem](https://people.math.harvard.edu/~elkies/Misc/mahler.pdf) support the binomial-basis foundation; the specific finite-degree period proof above is this reviewer\'s derivation. [Cheng et al., published root-counting paper](https://msp.org/obs/2019/2-1/obs-v2-n1-p12-p.pdf) documents the root-counting/Igusa connection. Original UCI fetch returned502 and eScholarship direct fetch challenged the browser; publisher/search-accessible primary text supplied the research relevance check.', '']
(REPORT/'independent_qc_review.md').write_text('\n'.join(out), encoding='utf-8')
print(json.dumps({'verdict': document['verdict'], 'static': document['static_summary'], 'rubric': document['rubric_summary'], 'findings': len(findings), 'raw_native_trials':len(raw_trials), 'standalone': str(standalone[0])}, indent=2))
