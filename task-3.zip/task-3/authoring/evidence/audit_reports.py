"""Task3 local QC statuses derived from recorded native and mathematical evidence."""
import hashlib
import json
from pathlib import Path
import re
import sys
ROOT=Path(__file__).resolve().parents[2];R=ROOT/'authoring/reports'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def citation(path,needle):
    return path+':'+str(next((i for i,l in enumerate((ROOT/path).read_text(encoding='utf-8').splitlines(),1) if needle in l),1))


def main():
    suffix=sys.argv[1] if len(sys.argv)>1 else 'v010'
    a,b=(ROOT/'authoring/inputs/QC-CHECKLIST.md').read_text(encoding='utf-8-sig').split('## LLM judge checks')
    static=re.findall(r'\(`([^`]+)`\)',a);rubric=re.findall(r'\(`([^`]+)`\)',b)
    assert len(static)==29 and len(rubric)==38
    rules=read(R/'upstream_static.json');assert len(rules)==26 and all(x['exit_code']==0 for x in rules)
    package=read(R/'package_manifest.json')
    for path,h in package['files'].items():
        assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==h
        assert hashlib.sha256((ROOT/'authoring/package'/package['canonical_task_path']/path).read_bytes()).hexdigest()==h
    assert read(R/'local_validation.json')['success'] and read(R/'security_probe.json')['success']
    assert (R/('harbor_lint_'+suffix+'.log')).read_text().strip().endswith('[]')
    orig=read(ROOT/'authoring/plagiarism/reports/plagiarism_report.json');assert orig['status']=='PASS_SCOPED'
    trials=[]
    for p in sorted((R/'harbor-jobs').glob('*-'+suffix+'/*/result.json')):
        d=read(p)
        if 'trial_name' not in d:continue
        name=p.parent.parent.name;reward=d['verifier_result']['rewards']['reward']
        ctrf=read(p.parent/'verifier/ctrf.json')['results']['summary']
        assert d['exception_info'] is None and d['verifier_environment_mode']=='separate'
        assert reward==(1 if name.startswith(('oracle','alternative')) else 0)
        assert ctrf['tests']==10 and (ctrf['passed']==10 if reward else ctrf['passed']<10)
        trials.append({'job':name,'trial':d['trial_name'],'reward':reward,'ctrf':ctrf,'checksum':d['task_checksum'],'path':str(p.relative_to(ROOT))})
    assert len(trials)==9 and len({x['checksum'] for x in trials})==1
    (R/'native_summary.json').write_text(json.dumps({'success':True,'trials':trials,'suffix':suffix},indent=2),encoding='utf-8')
    evidence={x['check']:'Actual pinned upstream rule exit0; upstream_static.json' for x in rules}
    evidence.update({'entry-files':'All required entry files exist; package_manifest.json',
                     'config-fields':'Actual Harbor0.27.0 lint [] and native schema1.4 execution',
                     'instruction-similarity':f"Actual upstream TF-IDF calculation:99 references, max{orig['tfidf_max_cosine']:.6f}<0.80; plagiarism_report.json"})
    lines=['# Static QC audit','','29/29 local static checks pass:26 actual pinned shell checks plus measured entry/config/similarity checks. The user-requested standalone folder uses descriptive canonical staging for repository path/slug validation; all packaged bytes are hash-matched. This is not an external dashboard verdict. Contributor contact/profile fields explicitly disclose missing human publication metadata.','','| ID | Status | Evidence |','|---|---|---|']
    for k in static:lines.append(f'| {k} | PASS | {evidence[k]}; task.toml:1 and package_manifest.json |')
    (R/'static_qc_audit.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    ev={
     'well_specified':('environment/spec.md','## Output','Complete mathematical goal, integer encoding, cylinder/histogram/projection schemas and limits'),
     'test_instruction_alignment':('environment/spec.md','The cylinders','Each label, coverage, count and execution condition checked by the harness is public'),
     'instruction_clarity':('instruction.md','For each input','Outcome-focused scientific requirements; no reward or hidden-test narration'),
     'structured_data_schema':('environment/spec.md','histogram','Output fields, scalar conventions and multiplicities match checker'),
     'typos':('environment/spec.md','Place the entry','Actual end-to-end execution validates commands and paths'),
     'scientifically_grounded':('authoring/research/mathematical_justification.md','Newton','Local number-theoretic valuation distributions and root-density analysis; classical sources cited'),
     'scope':('task.toml','field =','Computational number-theory proof certificates within formal mathematics; no theorem-prover claim'),
     'essential_difficulty':('README.md','Singular Hensel','Singular branching, functional cancellation, joint correlations and all-precision populations; empirical difficulty unmeasured'),
     'novel':('authoring/plagiarism/reports/plagiarism_report.md','PASS','Scoped corpus/source and semantic comparisons; distinct from both Task1 and Task2'),
     'agentic':('README.md','compressed','Requires implementing, testing and debugging reusable exact mathematical software'),
     'verifiable':('tests/certificates.py','def certify','Independent universal functional proof and exact prefix/weight/count invariants'),
     'solvable':('solution/solve.py','def visit','General oracle passes all families twice natively; degree12/precision64 and1000-digit inputs covered'),
     'outcome_verified':('authoring/evidence/validate_local.py','coarse','Refined/reordered cylinders and independently derived functional coarsening accepted'),
     'functional_verification':('tests/harness.py','subprocess.Popen','Actual submitted code executes separately; actual integer outputs are checked'),
     'ground_truth_provenance':('tests/cases.py','def batches','New deterministic polynomial generator; no reference output file, independent proof checks'),
     'graded_instances_discriminate':('authoring/reports/test_discrimination_audit.md','NON-DISCRIMINATING','Easy controls disclosed; simple-only/shallow-grid/wrong-marginal failures measured per family'),
     'solution_quality':('solution/solve.py','def classify','Derives labels by content and digit recursion, not hardcoded answers'),
     'do_not_modify_enforced':('tests/harness.py','p.chmod','Read-only source and restricted child ownership/permissions enforced'),
     'deterministic_reproducible':('authoring/reports/native_summary.json','checksum','Two clean native oracle resets share checksum and reward1; deterministic generator'),
     'separate_verifier_configured':('task.toml','environment_mode','Native results explicitly record separate mode and source artifact transfer'),
     'verifier_execution_isolation':('tests/harness.py','restrict','Native UID/GID65534, empty groups and denied tests/reward access'),
     'anti_cheat_robustness':('tests/harness.py','TemporaryDirectory','Fresh outputs, source-only transfer, independent private certificates; hardcoder and trivial guesses fail'),
     'task_security':('task.toml','network_mode','Offline verifier with no host access/credential variables; generic safe process isolation'),
     'resource_configuration':('task.toml','cpus','2CPU/4GiB, noGPU,300sec/2GiB program limits; measured native runtime is far below limits'),
     'task_toml_schema':('task.toml','schema_version','Real Harbor0.27.0 accepts schema1.4 and runs both environments'),
     'environment_hygiene':('environment/Dockerfile','COPY','Pinned hash-checked offline wheels; no private code in solver image; actual clean build/leakage probe'),
     'artifact_efficiency':('task.toml','artifacts','Only self-contained source artifact transfers; no stale output or giant answer population'),
     'ctrf_reporting':('tests/test_outputs.py','globals','Ten independent function names retained in native CTRF; binary rewards'),
     'task_authoring_dir':('authoring/research/task_proposal.md','Title','Research, reviews, logs and reference material under authoring outside image contexts'),
     'no_extraneous_files':('environment/Dockerfile','wheels','Only required scaffold, imported code, input example and offline dependency wheels in runtime package'),
     'reviewable':('authoring/research/mathematical_justification.md','Cylinder','Detailed finite proof, generator, independent checker and measured small-ring comparisons'),
     'difficulty_explanation_quality':('README.md','## Difficulty','Professional workflow, synthetic realism and specific arithmetic obstacles explained; no claimed measured success rate'),
     'solution_explanation_quality':('README.md','## Reference solution','Content tests, singular digit recursion, merging and population projection explained'),
     'verification_explanation_quality':('README.md','## Verification','Functional period proof, prefix completeness, exact counts, controls and isolation explained'),
     'category_and_tags':('task.toml','keywords','Labels name actual p-adic number theory and exact certificate methods'),
     'task_name':('task.toml','name =','Descriptive certified-padic-census canonical slug; task-3 wrapper is user-directed'),
     'task_readme':('README.md','END MANAGED','Actual pinned generated-header and authored-section checks pass')}
    assert set(ev)==set(rubric)-{'hint_discoverability'}
    entries=[]
    for k in rubric:
        if k in ev:
            path,needle,why=ev[k];status='PASS';ref=citation(path,needle)
        else:status='NOT APPLICABLE';why='No optional hint supplied';ref=citation('instruction.md','full mathematical')
        entries.append({'id':k,'required_behavior':'Full governing criterion in authoring/inputs/QC-CHECKLIST.md','status':status,'evidence':why,'citation':ref,'correction':'None unresolved in creator audit','recheck':'Measured/source evidence; independent review tracked separately'})
    (R/'rubric_qc_audit.json').write_text(json.dumps(entries,indent=2),encoding='utf-8')
    lines=['# Local rubric QC audit','','37/38 PASS; optional-hint criterion NOT APPLICABLE. These are local measured/source assessments, not external LLM-panel approval. Additional upstream difficult/expert_time_estimate empirical criteria are NOT TESTED. Independent findings/rechecks are recorded separately.','','| ID | Required behavior | Status | Evidence / file:line | Correction / recheck |','|---|---|---|---|---|']
    for x in entries:lines.append(f"| {x['id']} | Full governing criterion | {x['status']} | {x['evidence']}; {x['citation']} | {x['correction']}; {x['recheck']} |")
    (R/'rubric_qc_audit.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    lines=['# Native Harbor validation','','Both images built cleanly with --no-cache from a pinned base and bundled hash-checked wheels. Actual commands and console output are preserved in clean_build_* and harbor_* logs.','','| Job / trial | Reward | CTRF passed/total | Checksum |','|---|---:|---|---|']
    for t in trials:lines.append(f"| {t['job']} / {t['trial']} | {t['reward']} | {t['ctrf']['passed']}/10 | {t['checksum']} |")
    lines+=['','Two native oracle repeats prove fresh resets and full mathematical acceptance. Correct alternative subdivision passes. All six negative baselines earn0; some correctly solve easy or nonsingular families, as explicitly shown in CTRF and test_discrimination_audit.md. Native isolation/leakage probes pass. Only source artifacts transfer. No portable result is substituted for these actual Harbor runs.','', 'External QC panel NOT RUN. Gemini NOT REQUESTED / NOT RUN. Empirical success rate and measured expert time NOT MEASURED. Generic build/isolation infrastructure is copied into this independent task; no runtime source/data/private evaluator dependency on Task2 exists.']
    (R/'harbor_validation.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('PASS:29 static,37 rubric plus1N/A,9 native trials')


if __name__=='__main__':main()
