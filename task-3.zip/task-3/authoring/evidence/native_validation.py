"""Pinned local-only native Docker/Harbor validation; no provider integrations."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
ROOT=Path(__file__).resolve().parents[2]
DOCKER=r'C:\Users\zubai\AppData\Local\Programs\DockerDesktop\resources\bin\docker.exe'
HARBOR=r'C:\Users\zubai\.local\bin\harbor.exe'
TASK=ROOT/'authoring/package/tasks/mathematical-sciences/formal-mathematics/certified-padic-census'
REPORT=ROOT/'authoring/reports'
env=dict(os.environ)
env['PATH']=str(Path(DOCKER).parent)+os.pathsep+env.get('PATH','')
env['PYTHONPATH']=str(ROOT);env['PYTHONUTF8']='1';env['PYTHONIOENCODING']='utf-8'
env['LITELLM_LOCAL_MODEL_COST_MAP']='True'
for key in list(env):
    if any(part in key.upper() for part in ('API_KEY','AUTH_TOKEN','ACCESS_TOKEN','SECRET_KEY')):env.pop(key)


def execute(args,name,cwd=ROOT,allow_fail=False):
    log=REPORT/(name+'.log')
    if log.exists():raise RuntimeError('Refusing to overwrite '+str(log))
    with log.open('w',encoding='utf-8') as out:
        out.write('COMMAND '+json.dumps(args)+'\n');out.flush()
        code=subprocess.call(args,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
    print(name,'exit',code,flush=True)
    if code and not allow_fail:raise RuntimeError(str(log))
    return code


def main():
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['build','static','harbor']);p.add_argument('--suffix',default='v010');p.add_argument('--image-tag');a=p.parse_args()
    suffix=a.suffix
    if a.phase=='build':
        for part,tag in [('environment','agent'),('tests','verifier')]:
            execute([DOCKER,'build','--no-cache','-t','local-padic-'+tag+':'+suffix,str(TASK/part)],'clean_build_'+tag+'_'+suffix)
    elif a.phase=='static':
        execute([DOCKER,'run','--rm','--network','none','--mount','type=bind,source='+ROOT.as_posix()+',target=/work','-w','/work/authoring/package','local-padic-verifier:'+(a.image_tag or suffix),'python3','/work/authoring/evidence/run_static.py'],'static_'+suffix)
    else:
        execute([HARBOR,'lint',str(TASK),'--json'],'harbor_lint_'+suffix)
        agents=[('oracle','oracle',2),('nop','nop',1),('constant','ConstantAgent',1),('hardcoded','HardcodedAgent',1),('grid','GridAgent',1),('incomplete','IncompleteAgent',1),('incorrect','IncorrectAgent',1),('alternative','AlternativeAgent',1)]
        for label,agent,k in agents:
            name=label+'-'+suffix
            if agent not in ('oracle','nop'):agent='authoring.evidence.baseline_agent:'+agent
            args=[HARBOR,'run','--path',str(TASK),'--agent',agent,'-k',str(k),'--n-concurrent','1','--job-name',name,'--jobs-dir',str(REPORT/'harbor-jobs'),'--quiet']
            execute(args,'harbor_'+name)


if __name__=='__main__':main()
