"""Audit baselines per individual hidden instance, rather than family only."""
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tests'))
from cases import FAMILIES
from harness import run

rows = []
for baseline in ('constant', 'hardcoded', 'simple-only', 'shallow-grid', 'wrong-marginals'):
    for family, cases in FAMILIES:
        for case in cases:
            try:
                run(ROOT / 'authoring/evidence/baselines' / baseline, [case], portable=True)
                accepted, reason = True, 'accepted'
            except Exception as exc:
                accepted, reason = False, str(exc)[:200]
            rows.append({'baseline': baseline, 'family': family, 'case': case['id'],
                         'accepted': accepted, 'reason': reason})
report = {'reviewer': '/root/task3_independent_qc', 'rows': rows,
          'accepted': {name: [r['case'] for r in rows if r['baseline'] == name and r['accepted']]
                       for name in sorted({r['baseline'] for r in rows})}}
(ROOT / 'authoring/reports/independent_qc_per_case.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report['accepted'], indent=2))
