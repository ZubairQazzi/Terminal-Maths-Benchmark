"""Final direct validation of the user-requested standalone Task3 folder."""
from native_validation import execute,HARBOR,ROOT,REPORT
execute([HARBOR,'lint',str(ROOT),'--select','ALL','--json'],'harbor_standalone_lint_v010')
execute([HARBOR,'run','--path',str(ROOT),'--agent','oracle','--n-concurrent','1','--job-name','standalone-v010','--jobs-dir',str(REPORT/'harbor-jobs'),'--quiet'],'harbor_standalone_v010')
