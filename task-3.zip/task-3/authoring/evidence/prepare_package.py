"""Create canonical QC staging from the user-requested standalone task folder."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import tomllib
ROOT=Path(__file__).resolve().parents[2]
config=tomllib.loads((ROOT/'task.toml').read_text())
slug=config['task']['name'].split('/')[-1]
path=Path('tasks')/config['metadata']['domain']/config['metadata']['field']/slug
stage=ROOT/'authoring/package'
dest=stage/path;dest.mkdir(parents=True,exist_ok=True)
for name in ('task.toml','instruction.md','README.md','environment','solution','tests'):
    src=ROOT/name
    if src.is_dir():shutil.copytree(src,dest/name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    else:shutil.copy2(src,dest/name)
upstream=ROOT/'authoring/research/upstream'
spec=importlib.util.spec_from_file_location('readme_generator',upstream/'tools/task-readme/generate.py')
gen=importlib.util.module_from_spec(spec);spec.loader.exec_module(gen)
raw=(ROOT/'README.md').read_bytes()
try:text=raw.decode('utf-8')
except UnicodeDecodeError:text=raw.decode('cp1252')
text=text.replace('\r\n','\n').replace('\r','\n')
body=text.split('<!-- END MANAGED HEADER -->',1)[1].lstrip('\n')
header=gen.render(dest)
readme=header+'\n'+body
(ROOT/'README.md').write_text(readme,encoding='utf-8',newline='\n');(dest/'README.md').write_text(readme,encoding='utf-8',newline='\n')
for name in ('ci_checks','tools'):
    shutil.copytree(upstream/name,stage/name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('test-tasks','__pycache__','*.pyc'))
for name in ('task-readme-template.md','.github/reviewer-pool.yml'):
    p=stage/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(upstream/name,p)
manifest={p.relative_to(dest).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dest.rglob('*')) if p.is_file()}
(ROOT/'authoring/reports/package_manifest.json').write_text(json.dumps({'canonical_task_path':str(path).replace('\\','/'),'files':manifest},indent=2))
print(dest)
