"""Task3 deterministic controls; no AI/model calls."""
from pathlib import Path
from harbor.agents.base import BaseAgent
from harbor.agents.capabilities import AgentCapabilities


class UploadAgent(BaseAgent):
    capabilities=AgentCapabilities(windows=True)
    kind='constant'
    @classmethod
    def name(cls):return 'local-'+cls.kind
    def version(self):return '0.1.0'
    async def setup(self,environment):return None
    async def run(self,instruction,environment,context):
        await environment.upload_dir(source_dir=Path(__file__).parent/'baselines'/self.kind,target_dir='/app/submission')
        (self.logs_dir/'baseline.txt').write_text('Deterministic '+self.kind+'; no provider/model call.\n')


class ConstantAgent(UploadAgent):kind='constant'
class HardcodedAgent(UploadAgent):kind='hardcoded'
class IncompleteAgent(UploadAgent):kind='simple-only'
class GridAgent(UploadAgent):kind='shallow-grid'
class IncorrectAgent(UploadAgent):kind='wrong-marginals'
class AlternativeAgent(UploadAgent):kind='alternative'
