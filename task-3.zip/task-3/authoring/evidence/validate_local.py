"""Independent small-ring enumeration, negatives, alternatives and corruptions."""
from collections import Counter
import copy
import importlib.util
import json
from pathlib import Path
import random
import sys
import time
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tests'))
from cases import FAMILIES
from certificates import verify
from harness import run


def oracle():
    spec=importlib.util.spec_from_file_location('reference',ROOT/'solution/solve.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


def baselines():
    folder=ROOT/'authoring/evidence/baselines';ref=oracle()
    programs={
      'noop':'pass\n',
      'constant':"import json,sys\nfrom reference import summarize\nd=json.load(open(sys.argv[1]));json.dump({'cases':[summarize(c,[[0,0,c['precision'],c['precision']]]) for c in d['cases']]},open(sys.argv[2],'w'))\n",
      'hardcoded':"import json,sys\nd=json.load(open(sys.argv[1]));known=json.load(open(__file__.replace('solve.py','known.json')));json.dump({'cases':[dict(known,id=c['id']) for c in d['cases']]},open(sys.argv[2],'w'))\n",
      'simple-only':"import json,sys,reference as r\noriginal=r.classify\ndef limited(c,p,N):\n v=original(c,p,N)\n if v is not None:return v\n if N==1:return None\n m=min(r.valuation(a,p,N) for a in c);q=[a//p**m for a in c];roots=[a for a in range(p) if r.evaluate(q,a,p)==0];deriv=[i*q[i] for i in range(1,len(q))]\n if roots and all(r.evaluate(deriv,a,p)==0 for a in roots):return m\n return None\nr.classify=limited\nd=json.load(open(sys.argv[1]));json.dump({'cases':[r.solve(c) for c in d['cases']]},open(sys.argv[2],'w'))\n",
      'shallow-grid':"import json,sys\nfrom reference import solve,summarize\nd=json.load(open(sys.argv[1]));out=[]\nfor c in d['cases']:\n cut=min(c['precision'],3);a=solve(dict(c,precision=cut));leaves=[[r,k,c['precision'] if u==cut else u,c['precision'] if v==cut else v] for r,k,u,v in a['leaves']];out.append(summarize(c,leaves))\njson.dump({'cases':out},open(sys.argv[2],'w'))\n",
      'wrong-marginals':"import json,sys\nfrom collections import Counter\nfrom reference import solve\nd=json.load(open(sys.argv[1]));out=[]\nfor c in d['cases']:\n a=solve(c);left=Counter();right=Counter();M=c['p']**c['precision']\n for u,v,n in a['histogram']:left[u]+=n;right[v]+=n\n a['histogram']=[[u,v,x*y//M] for u,x in left.items() for v,y in right.items() if x*y//M];out.append(a)\njson.dump({'cases':out},open(sys.argv[2],'w'))\n",
      'alternative':"import json,sys\nfrom reference import solve,summarize\nd=json.load(open(sys.argv[1]));out=[]\nfor c in d['cases']:\n a=solve(c);leaves=[];p=c['p'];N=c['precision']\n for r,k,u,v in a['leaves']:\n  if k<N:leaves.extend([[r+d*p**k,k+1,u,v] for d in range(p)])\n  else:leaves.append([r,k,u,v])\n out.append(summarize(c,list(reversed(leaves))))\njson.dump({'cases':out},open(sys.argv[2],'w'))\n"}
    example=json.loads((ROOT/'environment/data/example.json').read_text())['cases'][0]
    for name,code in programs.items():
        dest=folder/name;dest.mkdir(parents=True,exist_ok=True);(dest/'solve.py').write_text(code,encoding='utf-8')
        if name not in ('noop','hardcoded'):(dest/'reference.py').write_bytes((ROOT/'solution/solve.py').read_bytes())
        if name=='hardcoded':(dest/'known.json').write_text(json.dumps(ref.solve(example)))
    return folder


def brute(case):
    p,N=case['p'],case['precision'];hist=Counter()
    def val(poly,x,limit):
        n=sum(int(c)*x**i for i,c in enumerate(poly));v=0
        while v<limit and n%p==0:n//=p;v+=1
        return v
    for x in range(p**N):hist[val(case['f'],x,N),val(case['g'],x,N)]+=1
    counts=[sum(val(case['f'],x,s)==s and val(case['g'],x,s)==s for x in range(p**s)) for s in range(1,N+1)]
    return [[a,b,n] for (a,b),n in sorted(hist.items())],counts


def main():
    started=time.monotonic();ref=oracle();rows=[]
    for name,cases in FAMILIES:
        result=run(ROOT/'solution',cases,portable=True);rows.append({'family':name,**result});print(name,result,flush=True)
    rng=random.Random(92711);small=[]
    for i in range(48):
        p=[2,3,5,7][i%4];N=1+i%3
        f=[rng.randint(-20,20) for _ in range(1+i%7)];g=[rng.randint(-20,20) for _ in range(1+(i*3)%7)]
        while len(f)>1 and f[-1]==0:f.pop()
        while len(g)>1 and g[-1]==0:g.pop()
        c={'id':'brute-'+str(i),'p':p,'precision':N,'f':f,'g':g};a=ref.solve(c);verify(c,a)
        h,counts=brute(c);assert a['histogram']==h and a['root_counts']==counts
        small.append({'id':c['id'],'modulus':p**N,'status':'PASS'})
    folder=baselines();negative=[]
    for name in ('noop','constant','hardcoded','simple-only','shallow-grid','wrong-marginals','alternative'):
        for family,cases in FAMILIES:
            try:run(folder/name,cases,portable=True);passed=True;reason='accepted'
            except Exception as e:passed=False;reason=str(e)[:400]
            negative.append({'baseline':name,'family':family,'accepted':passed,'reason':reason})
        print(name,[x['family'] for x in negative if x['baseline']==name and x['accepted']],flush=True)
    assert all(x['accepted'] for x in negative if x['baseline']=='alternative')
    for name in ('noop','constant','hardcoded','simple-only','shallow-grid','wrong-marginals'):
        assert any(not x['accepted'] for x in negative if x['baseline']==name)
    c=FAMILIES[2][1][0];correct=ref.solve(c);mutations=[]
    def reject(name,change):
        bad=copy.deepcopy(correct);change(bad)
        try:verify(c,bad)
        except Exception as e:mutations.append({'mutation':name,'rejected':True,'reason':str(e)});return
        raise AssertionError('Accepted '+name)
    reject('coverage-hole',lambda a:a['leaves'].pop())
    reject('overlap',lambda a:a['leaves'].append(a['leaves'][0][:]))
    reject('bad-residue',lambda a:a['leaves'][0].__setitem__(0,c['p']**c['precision']))
    reject('bad-valuation',lambda a:a['leaves'][0].__setitem__(2,(a['leaves'][0][2]+1)%(c['precision']+1)))
    reject('wrong-weight',lambda a:a['histogram'][0].__setitem__(2,a['histogram'][0][2]+1))
    reject('wrong-projection',lambda a:a['root_counts'].__setitem__(0,a['root_counts'][0]+1))
    reject('duplicate-histogram',lambda a:a['histogram'].append(a['histogram'][0][:]))
    reject('float',lambda a:a['leaves'][0].__setitem__(0,0.0))
    reject('bool',lambda a:a['leaves'][0].__setitem__(0,False))
    reject('missing-field',lambda a:a.pop('root_counts'))
    # Independently derive a valid coarse functional certificate that has content0.
    c=FAMILIES[7][1][0];coarse={'id':c['id'],'leaves':[[0,0,1,c['precision']]],'histogram':[[1,c['precision'],c['p']**c['precision']]],'root_counts':[c['p']]+[0]*(c['precision']-1)}
    verify(c,coarse)
    output={'success':True,'oracle':rows,'small_exhaustive':small,'baselines':negative,'mutations':mutations,'functional_coarse_alternative':'PASS','seconds':time.monotonic()-started,'docker_validated':False,'harbor_validated':False}
    (ROOT/'authoring/reports/local_validation.json').write_text(json.dumps(output,indent=2),encoding='utf-8');print('PASS',output['seconds'])


if __name__=='__main__':main()
