# Reproduction

Use Python3.12.10 at C:/Users/zubai/AppData/Local/Programs/Python/Python312/python.exe and existing Docker/Harbor0.27.0. No model key is needed. From F:/rl/task-3:

```powershell
& 'C:\Users\zubai\AppData\Local\Programs\Python\Python312\python.exe' -X utf8 -B .\authoring\evidence\validate_local.py
& 'C:\Users\zubai\AppData\Local\Programs\Python\Python312\python.exe' -X utf8 -B .\authoring\evidence\prepare_package.py
& 'C:\Users\zubai\AppData\Local\Programs\Python\Python312\python.exe' -X utf8 -B .\authoring\evidence\native_validation.py build --suffix fresh-unique
& 'C:\Users\zubai\AppData\Local\Programs\Python\Python312\python.exe' -X utf8 -B .\authoring\evidence\native_validation.py static --suffix fresh-unique
& 'C:\Users\zubai\AppData\Local\Programs\Python\Python312\python.exe' -X utf8 -B .\authoring\evidence\native_validation.py harbor --suffix fresh-unique
```

Choose a unique suffix: console logs are never silently overwritten. The supplied wheels allow offline installation; the pinned base image must be cached or reachable. Individual native jobs retain configuration, trial results, CTRF and binary rewards. The standalone root can also be passed directly to Harbor; canonical staging is only for repository path/slug conventions. This reproduction invokes deterministic oracle/baseline programs, never a model provider.
