# Test coverage and discrimination

Ten mandatory families contain22 cases. The eight controls/boundary cases are explicitly NON-DISCRIMINATING diagnostics. The scalar simple-lift cases are basic mathematical diagnostics. No controls are advertised as expert-level instances.

| Family | Cases | Property / role |
|---|---:|---|
| controls |8| Entire/empty ring, N1/2/64, signed/zero-padded strings, degree12 and1000-digit limits; all easy non-discriminating diagnostics; max8-case invocation |
| simple-lifts |2| Ordinary nonsingular lifting diagnostic |
| singular-powers |2| Repeated roots with huge populations; discriminating |
| colliding-clusters |1| Roots agreeing to many digits, interacting multiplicities; discriminating |
| dead-lifts |2| dead-three has a nontrivial valuation tail; dead-two is an easy two-parity-leaf/dead-lift diagnostic, not expert evidence |
| content-factors |1| Nonprimitive coefficients and different saturation thresholds; discriminating |
| nonmonic |1| Nonunit leading coefficients with nonsingular local roots; basic lifting diagnostic, not singular/expert evidence by itself |
| functional-cancellation |2| Integer-valued cancellation versus coefficient content; discriminating, including coarse functional certificate |
| large-coefficients |1| Prime7, precision64, close roots and exact huge counts; discriminating |
| affine-metamorphic |2| Unit affine coordinate bijection preserves populations; one base problem plus a metamorphic regression |

The verifier checks every cylinder universally via finite differences and one proven functional period. It does not trust reported labels, counts or reference leaf choices. Forty-eight independently enumerated small rings crosscheck histograms and all smaller-modulus root counts. Local corruptions and a different subdivision/coarse functional representation test rejection and fairness. Native CTRF reports each family separately.

Within functional-cancellation, coarse-functional is an intentionally easy cancellation/representation diagnostic: its complete answer is one constant-valued cylinder. It is not counted as expert difficulty. The other case in that family still requires a nontrivial varying valuation distribution. Counts of22 cases include the disclosed controls and metamorphic duplicate; they are not22 independent hard problems.

Independent per-case results are in independent_qc_per_case.json. Some incomplete algorithms solve individual easy or nonsingular members even when the family fails as a whole. In particular shallow-grid solves dead-two and coarse-functional; the all-singular shortcut solves several nonsingular/mixed-root cases. Those successes are not concealed by family-level reporting.
