import json,sys
from reference import summarize
d=json.load(open(sys.argv[1]));json.dump({'cases':[summarize(c,[[0,0,c['precision'],c['precision']]]) for c in d['cases']]},open(sys.argv[2],'w'))
