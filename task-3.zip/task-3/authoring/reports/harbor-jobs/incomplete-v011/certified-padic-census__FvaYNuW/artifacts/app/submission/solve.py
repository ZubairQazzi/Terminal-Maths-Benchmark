import json,sys,reference as r
original=r.classify
def limited(c,p,N):
 v=original(c,p,N)
 if v is not None:return v
 if N==1:return None
 m=min(r.valuation(a,p,N) for a in c);q=[a//p**m for a in c];roots=[a for a in range(p) if r.evaluate(q,a,p)==0];deriv=[i*q[i] for i in range(1,len(q))]
 if roots and all(r.evaluate(deriv,a,p)==0 for a in roots):return m
 return None
r.classify=limited
d=json.load(open(sys.argv[1]));json.dump({'cases':[r.solve(c) for c in d['cases']]},open(sys.argv[2],'w'))
