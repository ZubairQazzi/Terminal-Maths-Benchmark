import json,sys
from reference import solve,summarize
d=json.load(open(sys.argv[1]));out=[]
for c in d['cases']:
 a=solve(c);leaves=[];p=c['p'];N=c['precision']
 for r,k,u,v in a['leaves']:
  if k<N:leaves.extend([[r+d*p**k,k+1,u,v] for d in range(p)])
  else:leaves.append([r,k,u,v])
 out.append(summarize(c,list(reversed(leaves))))
json.dump({'cases':out},open(sys.argv[2],'w'))
