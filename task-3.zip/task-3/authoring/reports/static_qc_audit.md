# Static QC audit

29/29 local static checks pass:26 actual pinned shell checks plus measured entry/config/similarity checks. The user-requested standalone folder uses descriptive canonical staging for repository path/slug validation; all packaged bytes are hash-matched. This is not an external dashboard verdict. Contributor contact/profile fields explicitly disclose missing human publication metadata.

| ID | Status | Evidence |
|---|---|---|
| entry-files | PASS | All required entry files exist; package_manifest.json; task.toml:1 and package_manifest.json |
| config-fields | PASS | Actual Harbor0.27.0 lint [] and native schema1.4 execution; task.toml:1 and package_manifest.json |
| task-fields | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| task-path | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| task-structure | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| task-slug | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| task-readme | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| canary | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| task-absolute-path | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| instruction-suffix | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| instruction-similarity | PASS | Actual upstream TF-IDF calculation:99 references, max0.566311<0.80; plagiarism_report.json; task.toml:1 and package_manifest.json |
| test-file-references | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| dockerfile-references | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| dockerfile-sanity | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| dockerfile-platform | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| allow-internet | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| separate-verifier | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| compose-host-binds | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| task-timeout | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| gpu-types | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| task-resources | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| verifier-resources | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| nproc | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| verifier-tooling-baked | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| trial-network-fetch | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| pip-pinning | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| pytest-version | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| test-sh-sanity | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
| binary-reward | PASS | Actual pinned upstream rule exit0; upstream_static.json; task.toml:1 and package_manifest.json |
