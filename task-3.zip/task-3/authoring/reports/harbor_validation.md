# Native Harbor validation

Both images built cleanly with --no-cache from a pinned base and bundled hash-checked wheels. Actual commands and console output are preserved in clean_build_* and harbor_* logs.

| Job / trial | Reward | CTRF passed/total | Checksum |
|---|---:|---|---|
| alternative-v011 / certified-padic-census__JrK8AJR | 1.0 | 10/10 | 2c59bee2d13e5bdc942735e3d4d0319276c8bdc625ea2d88f8fdc873292049f6 |
| constant-v011 / certified-padic-census__vSKatJM | 0.0 | 0/10 | 2c59bee2d13e5bdc942735e3d4d0319276c8bdc625ea2d88f8fdc873292049f6 |
| grid-v011 / certified-padic-census__iDfcZ7a | 0.0 | 0/10 | 2c59bee2d13e5bdc942735e3d4d0319276c8bdc625ea2d88f8fdc873292049f6 |
| hardcoded-v011 / certified-padic-census__QjdzDVL | 0.0 | 0/10 | 2c59bee2d13e5bdc942735e3d4d0319276c8bdc625ea2d88f8fdc873292049f6 |
| incomplete-v011 / certified-padic-census__FvaYNuW | 0.0 | 4/10 | 2c59bee2d13e5bdc942735e3d4d0319276c8bdc625ea2d88f8fdc873292049f6 |
| incorrect-v011 / certified-padic-census__mfU2wBt | 0.0 | 2/10 | 2c59bee2d13e5bdc942735e3d4d0319276c8bdc625ea2d88f8fdc873292049f6 |
| nop-v011 / certified-padic-census__4rANaGi | 0.0 | 0/10 | 2c59bee2d13e5bdc942735e3d4d0319276c8bdc625ea2d88f8fdc873292049f6 |
| oracle-v011 / certified-padic-census__3qszuJz | 1.0 | 10/10 | 2c59bee2d13e5bdc942735e3d4d0319276c8bdc625ea2d88f8fdc873292049f6 |
| oracle-v011 / certified-padic-census__qD8k9wr | 1.0 | 10/10 | 2c59bee2d13e5bdc942735e3d4d0319276c8bdc625ea2d88f8fdc873292049f6 |

Two native oracle repeats prove fresh resets and full mathematical acceptance. Correct alternative subdivision passes. All six negative baselines earn0; some correctly solve easy or nonsingular families, as explicitly shown in CTRF and test_discrimination_audit.md. Native isolation/leakage probes pass. Only source artifacts transfer. No portable result is substituted for these actual Harbor runs.

External QC panel NOT RUN. Gemini NOT REQUESTED / NOT RUN. Empirical success rate and measured expert time NOT MEASURED. Generic build/isolation infrastructure is copied into this independent task; no runtime source/data/private evaluator dependency on Task2 exists.
