# QC remediation

The independent reviewer `/root/task3_independent_qc` uses a fresh context and reads original requirements, checklist and runtime sources before creator explanations. Initial findings and independent probes are retained separately.

| Item | Initial finding | Correction / evidence |
|---|---|---|
| F1 | Public execution limits omitted enforced128-descriptor/64MiB-per-file caps | Concise limits added to spec; no mathematical acceptance or runtime security weakened; independent recheck requested |
| I2 advisory | Hidden data lacked low precision, coefficient string spellings, exact1000-digit boundary and max8-case batch | Six easy boundary diagnostics added to controls; all8 controls explicitly non-discriminating. Version0.1.1 reruns all local/static/native checks |
| F2 | Family scores obscured simple dead-two/nonmonic diagnostics and the incomplete baseline's actual scope | Coverage/discrimination reports now identify easy members and the precise all-singular shortcut; independent per-case outcomes linked |

The reviewer independently tested309096 label comparisons,285 small-ring partitions/oracle censuses, functional cancellation, too-short-period rejection, alternative numeric spellings, and8 simultaneous degree12/precision64/1000-digit cases. These are independent author-only stress results, not inflated hidden-difficulty coverage. Retain exact scripts and raw logs.

No changes use model trajectories or Gemini feedback. The oracle and functional proof algorithm are unchanged from0.1.0;0.1.1 clarifies existing resource conditions and strengthens disclosed controls. All genuine findings require independent closure before final gate.

Final independent rechecks CLOSED F1, I2 and F2. See independent_qc_findings.json for file/line citations, initial evidence, corrections and all67 final criterion statuses. The reviewer independently verified current27-file hashes,9 native v011 trials, direct standalone reward1/10tests and all-rule lint, plus final native maximum-size probes. No mandatory local blocker remains.
