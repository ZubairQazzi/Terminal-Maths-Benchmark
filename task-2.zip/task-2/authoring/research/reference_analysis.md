# Reference study and input inventory

The original Task 1 sources and validation report were read without modification. It computes Kronecker/Smith/minimal polynomial pencil structure. Task 2 optimizes strictly convex parametric functions and produces a polygonal atlas, so its scientific objective, algorithm, invariants and evaluator are different.

The attached geometry.json describes a diamond silicon crack frame; area_frame.csv has spatial sampling identifiers/margins; healthy_reference (1).npz is a binary scientific reference; data_checksums.sha256 is a large imagery manifest. None is a complete new mathematical dataset. They are research references only and no runtime dependency.

Pinned source-only public reference snapshot and hashes are recorded in upstream/source_manifest.json. The three reference tasks are Mendota ice phenology, cilia segmentation and silicon fracture FBC. Source inspection covers objective, manifests, instructions, Docker, reference entrypoints and tests. No full scientific raster/volume/atomistic dataset was downloaded and no execution of those examples is claimed.

General lessons: connect intermediate decisions to final scientific objects; verify structure and physical/mathematical identities rather than a success flag; bake dependencies; use separate verifier/artifact transfer; distinguish source inspection from measured execution. No scientific objective, input data or algorithm from those examples is reused.

The actual local checklist and previous message.txt are preserved verbatim in authoring/inputs. The local checklist names 29 static and 38 rubric checks. A current upstream snapshot may have more rubric entries and requires contributor publication metadata. Report local and upstream evidence separately; do not invent a human email/profile for a local AI-assisted package.
