# Task 2 authoring record

The active standalone task is F:/rl/task-2. This location and bare Harbor layout follow the user's later explicit direction. The old partial copy under F:/rl/math-benchmark/task-2 is inactive historical work and was not overwritten. Task 1 is read-only reference material and has not been changed. Task 3 must not be designed until the available Task 2 gate passes.

Canonical source-only packaging for path/slug QC is under authoring/package/tasks/mathematical-sciences/applied-mathematics/certified-qp-atlas. prepare_package.py copies the root runtime files and records hashes. It does not introduce a second mathematical benchmark. Authoring files, independent reports and scientific reference snapshots never enter the agent image.

Research/proposal, requirements matrix and pre-implementation gate are in research/ and reports/. Original instructions and prior feedback are preserved in inputs/. Runtime dependencies are bundled as exact hash-checked wheels, so image builds and normal execution need no package downloads. The upstream QC profile requires public networking for the agent workspace; the submitted solver is executed offline in a separate restricted verifier.

Actual native builds, commands, CTRF results, rewards and Harbor result files are in reports/. The independent reviewer uses a fresh agent context; its own findings and rechecks are retained separately. Scoped originality evidence includes a pinned instruction corpus; standard mathematics and reusable isolation conventions are distinguished from distinctive benchmark content.

No Gemini or paid model API calls, calibration trials, commits, pushes, registry publication, or uploads are authorized or performed. The eight-trial target remains unmeasured. Local evidence is not an external QC panel approval.
