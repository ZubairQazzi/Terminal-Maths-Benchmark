import json,sys
from reference import solve,encode
d=json.load(open(sys.argv[1]));out=[]
for c in d['cases']:
 a=solve(c);a['cells']=a['cells'][:1];l,r,b,t=c['domain'];a['cells'][0]['vertices']=[[l,b],[r,b],[r,t],[l,t]];out.append(a)
json.dump({'cases':out},open(sys.argv[2],'w'),default=encode)
