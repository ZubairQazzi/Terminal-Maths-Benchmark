import json,sys
from reference import solve,encode
d=json.load(open(sys.argv[1]));out=[solve(c) for c in d['cases']]
for a in out:
 for cell in a['cells']:cell['dual']=[[-z for z in row] for row in cell['dual']]
json.dump({'cases':out},open(sys.argv[2],'w'),default=encode)
