"""Shape-correct zero-optimizer guess; intentionally mathematically incomplete."""
import json
import sys
data=json.load(open(sys.argv[1]));out=[]
for c in data['cases']:
    l,r,b,t=c['domain']
    cell={'vertices':[[l,b],[r,b],[r,t],[l,t]],'x':[[0,0,0] for _ in c['Q']],
          'dual':[[0,0,0] for _ in c['A']],'value':[0]*6}
    out.append({'id':c['id'],'cells':[cell]})
json.dump({'cases':out},open(sys.argv[2],'w'))
