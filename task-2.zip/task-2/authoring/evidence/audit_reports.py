"""Derive local QC/report statuses from actual files and retained run evidence."""
import hashlib
import json
from pathlib import Path
import re
import tomllib
ROOT=Path(__file__).resolve().parents[2];R=ROOT/'authoring/reports'
def load(p):return json.loads(p.read_text())
def line(path,needle):
    return next((i for i,s in enumerate((ROOT/path).read_text().splitlines(),1) if needle in s),1)
def cite(path,needle):return f'{path}:{line(path,needle)}'


def main():
    import sys
    suffix=sys.argv[1] if len(sys.argv)>1 else 'final010'
    checklist=(ROOT/'authoring/inputs/QC-CHECKLIST.md').read_text(encoding='utf-8-sig');a,b=checklist.split('## LLM judge checks')
    static=re.findall(r'\(`([^`]+)`\)',a);rubric=re.findall(r'\(`([^`]+)`\)',b)
    assert len(static)==29 and len(rubric)==38
    cfg=tomllib.loads((ROOT/'task.toml').read_text());package=load(R/'package_manifest.json')
    stage=ROOT/'authoring/package'/package['canonical_task_path']
    for name,digest in package['files'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
        assert hashlib.sha256((stage/name).read_bytes()).hexdigest()==digest,name
    rows=load(R/'upstream_static.json');assert len(rows)==26
    assert all(x['exit_code']==0 for x in rows),[x for x in rows if x['exit_code']]
    assert (R/('harbor_lint_'+suffix+'.log')).read_text().strip().endswith('[]')
    assert load(R/'local_validation.json')['success']
    assert load(R/'security_probe.json')['success']
    orig=load(ROOT/'authoring/plagiarism/reports/plagiarism_report.json');assert orig['status']=='PASS_SCOPED'
    trials=[]
    for p in sorted((R/'harbor-jobs').glob('*-'+suffix+'/*/result.json')):
        d=load(p)
        if 'trial_name' not in d:continue
        name=p.parent.parent.name;reward=d['verifier_result']['rewards']['reward']
        ctrf=load(p.parent/'verifier/ctrf.json')['results']['summary']
        assert d['exception_info'] is None and d['verifier_environment_mode']=='separate'
        assert reward==(1 if name.startswith(('oracle','alternative')) else 0)
        assert ctrf['tests']==10 and ctrf['passed']==(10 if reward else 0),ctrf
        trials.append({'job':name,'trial':d['trial_name'],'checksum':d['task_checksum'],'reward':reward,'ctrf':ctrf,'path':str(p.relative_to(ROOT))})
    assert len(trials)==9 and len({t['checksum'] for t in trials})==1
    (R/'native_summary.json').write_text(json.dumps({'suffix':suffix,'trials':trials,'success':True},indent=2))
    evidence={x['check']:('PASS','Actual pinned upstream script exit 0; authoring/reports/upstream_static.json') for x in rows}
    evidence.update({'entry-files':('PASS','Required five entry files exist in standalone root and canonical staging; package_manifest.json'),
                     'config-fields':('PASS','Harbor 0.27.0 lint returned []; native Harbor parsed and ran this manifest'),
                     'instruction-similarity':('PASS',f"Actual upstream TF-IDF calculation: {orig['instruction_count']} references; max {orig['tfidf_max_cosine']:.6f}<0.80; plagiarism_report.json")})
    out=['# Static QC audit','','29 local checklist criteria. Twenty-six actual upstream shell checks ran offline in the native verifier image; entry/config and similarity have separately measured evidence. This is not an external dashboard verdict.','','The standalone folder name/location follows the user’s explicit preference. Canonical staging supplies tasks/<domain>/<field>/<descriptive-slug> for repository-path checks. Every staged runtime file is hash-identical to its standalone counterpart. Publication contact/profile metadata explicitly says it was not supplied; no human identity is fabricated.','','| ID | Status | Evidence |','|---|---|---|']
    for k in static:
        s,e=evidence[k];out.append(f'| {k} | {s} | {e}; task.toml:1 / package_manifest.json |')
    (R/'static_qc_audit.md').write_text('\n'.join(out)+'\n')
    ev={
      'well_specified':('instruction.md','Create a reusable','Goal, program path, schema, exactness and limits stated; actual native invocation succeeds'),
      'test_instruction_alignment':('environment/spec.md','Every polygon','All geometry/KKT/value/format/limit checks are public requirements'),
      'instruction_clarity':('instruction.md','For every input','Outcome-focused paragraphs; no reward/hidden-test narration'),
      'structured_data_schema':('environment/spec.md','Write','Input/output fields and coefficient orders match exact checker'),
      'typos':('environment/spec.md','Entry point','End-to-end paths, commands and coefficient conventions exercised'),
      'scientifically_grounded':('authoring/research/mathematical_justification.md','Classical','Established explicit optimization and sensitivity workflow; sources cited, no new theorem claimed'),
      'scope':('task.toml','domain =','Pure mathematical optimization and geometry'),
      'essential_difficulty':('README.md','Critical regions','Interacting exact KKT, degeneracy and complete polygon atlas; unsupported extreme-difficulty calibration is not asserted'),
      'novel':('authoring/plagiarism/reports/plagiarism_report.md','PASS','Scoped actual source and semantic comparison; classical mathematics distinguished from newly authored benchmark'),
      'agentic':('README.md','The solver must','Requires building and debugging reusable mathematical software, not retrieving a scalar answer'),
      'verifiable':('tests/certificates.py','def verify','Exact feasibility, polynomial identities and coverage; ten mutations rejected'),
      'solvable':('solution/solve.py','def solve','General oracle passed all ten families twice in native Harbor under declared limits'),
      'outcome_verified':('authoring/evidence/validate_local.py',"'alternative'",'Triangulated/reordered correct atlas passes all ten families locally and native Harbor'),
      'functional_verification':('tests/harness.py','subprocess.Popen','Runs submitted program and checks actual output; never trusts a success claim'),
      'ground_truth_provenance':('tests/cases.py','def box','New deterministic input construction; no answer file; independent mathematical proof certificates'),
      'graded_instances_discriminate':('authoring/reports/test_discrimination_audit.md','NON-DISCRIMINATING','Easy controls explicitly identified; all six measured negative baselines fail the discriminating suite'),
      'solution_quality':('solution/solve.py','M.inv','Exact data-dependent KKT and polygon computation; no hidden test imports'),
      'do_not_modify_enforced':('tests/harness.py','p.chmod','Read-only submitted sources enforced by root ownership and restricted child UID; independently probed'),
      'deterministic_reproducible':('authoring/reports/native_summary.json','checksum','Two fresh native oracle trials share a task checksum and reward 1'),
      'separate_verifier_configured':('task.toml','environment_mode','Actual native result records separate verifier mode and correct artifacts'),
      'verifier_execution_isolation':('tests/harness.py','restrict','Actual UID/GID 65534 probe, no groups; tests/reward access denied'),
      'anti_cheat_robustness':('tests/harness.py','TemporaryDirectory','Fresh outputs, protected private calculations, restricted execution; hardcoder/no-op rejected'),
      'task_security':('task.toml','network_mode','Offline private verifier, no host binds/credentials, only source artifact; security_probe.json'),
      'resource_configuration':('task.toml','cpus','2 CPUs/4 GiB, program 2 GiB/300 sec; measured runs complete well within limits'),
      'task_toml_schema':('task.toml','schema_version','Real installed Harbor 0.27.0 accepts and executes schema 1.4'),
      'environment_hygiene':('environment/Dockerfile','COPY','Only spec/example in solver application; pinned hashed wheels, clean native build and leakage probe'),
      'artifact_efficiency':('task.toml','artifacts','Only submission source transfers; fresh candidate directory; no output reuse'),
      'ctrf_reporting':('tests/test_outputs.py',"globals()",'Ten separate test names appear in every native CTRF; reward exactly 0 or 1'),
      'task_authoring_dir':('authoring/research/task_proposal.md','Title','Research, tooling, QC and trajectories in authoring; staging contains runtime files only'),
      'no_extraneous_files':('environment/Dockerfile','wheels','Runtime scaffold, imported code, example and required offline wheels only; author materials outside image contexts'),
      'reviewable':('authoring/research/mathematical_justification.md','The verifier','Traceable proof, generator and independent checker with measured positive/negative evidence'),
      'difficulty_explanation_quality':('README.md','## Difficulty','Specific mathematical dependencies/failure modes; estimates and unmeasured calibration qualified'),
      'solution_explanation_quality':('README.md','## Reference solution','KKT enumeration, clipping/subtraction, affine maps and objective derivation explained'),
      'verification_explanation_quality':('README.md','## Verification','Continuum certification, area completeness, isolated execution and control classifications explained'),
      'category_and_tags':('task.toml','keywords','Tags and applied mathematics field describe actual optimizer/geometry problem'),
      'task_name':('task.toml','name =','Descriptive canonical slug certified-qp-atlas; standalone task-2 name explicitly required by user'),
      'task_readme':('README.md','END MANAGED','Pinned generated header and three authored sections; actual upstream README check passes')}
    assert set(ev)==set(rubric)-{'hint_discoverability'}
    entries=[]
    for k in rubric:
        if k in ev:
            path,needle,why=ev[k];s='PASS';citation=cite(path,needle)
        else:
            s='NOT APPLICABLE';citation=cite('environment/spec.md','Execution')
            why='No optional hint is supplied; the criterion is conditional on such a hint'
        entries.append({'id':k,'status':s,'required_behavior':'See full criterion in authoring/inputs/QC-CHECKLIST.md','evidence':why,'citation':citation,'correction':'None unresolved','recheck':'Measured evidence plus source audit; independent review tracked separately'})
    (R/'rubric_qc_audit.json').write_text(json.dumps(entries,indent=2))
    out=['# Local rubric QC audit','','38 governing criteria. These are evidence-based local assessments, not the external LLM panel. Thirty-seven PASS and one justified NOT APPLICABLE. Independent reviewer findings/rechecks are separate. The upstream snapshot has two additional model/time-calibration criteria, `difficult` and `expert_time_estimate`; empirical difficulty and timing remain NOT TESTED. No external overall approval is asserted.','','| ID | Required behavior | Status | Evidence and file:line | Correction / recheck |','|---|---|---|---|---|']
    for x in entries:out.append(f"| {x['id']} | Governing checklist criterion | {x['status']} | {x['evidence']}; {x['citation']} | {x['correction']}; {x['recheck']} |")
    (R/'rubric_qc_audit.md').write_text('\n'.join(out)+'\n')
    out=['# Native Docker and Harbor validation','','Actual commands are retained in each console log. The initially network-dependent build could not reach PyPI; it was interrupted and replaced with fully vendored hash-checked wheels. Both final images built with --no-cache. No successful network build is claimed.','','| Job | Reward | CTRF passed/total | Checksum |','|---|---:|---|---|']
    for t in trials:out.append(f"| {t['job']} / {t['trial']} | {t['reward']} | {t['ctrf']['passed']}/10 | {t['checksum']} |")
    out+=['','Two fresh oracle containers establish reset/repeatability. All six negative baselines fail; a valid alternate atlas passes. Native security probes deny private-test reads and reward writes. Canonical staging preserves runtime bytes; standalone wrapper layout is user-directed. Upstream agent networking is public; offline submitted-code execution is enforced in the separate no-network verifier. No model call, upload or publication occurred.','',
          'Final delivery note: the nine qc011 trials share one historical task checksum. Subsequent changes only normalize README whitespace and clarify the existing source-path/symlink execution contract; executable solution, evaluator, input data and mathematical acceptance are unchanged. Frozen011 clean images and all-static rerun validate the delivered specification. The separate standalone-v011 job directly evaluated F:/rl/task-2 and passed10/10 with reward1; its task checksum differs because the standalone wrapper contains authoring evidence. Independent hash evidence verifies all27 current packaged runtime files and current verifier code. These distinct checksums are not presented as identical.',
          '', 'A supplemental shape-correct zero-atlas program accepts only the explicitly disclosed zero-control among12 individual inputs (zero_guess_per_case.json), rejects the other11, and is also exercised by native zero-guess-frozen011. It supplements the six mandatory negatives; the empty constant baseline is not treated as mathematical discrimination evidence.',
          '', 'External QC panel: NOT RUN. Gemini: NOT REQUESTED / NOT RUN. Empirical AI success rate: NOT MEASURED.']
    (R/'harbor_validation.md').write_text('\n'.join(out)+'\n')
    print(json.dumps({'static_pass':29,'rubric_pass':37,'rubric_na':1,'native_trials':len(trials),'success':True}))


if __name__=='__main__':main()
