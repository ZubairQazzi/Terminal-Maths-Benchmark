"""Per-instance mathematical discrimination of a shape-correct zero atlas."""
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tests'))
from cases import FAMILIES
from harness import run
rows=[]
for family,cases in FAMILIES:
    for c in cases:
        try:run(ROOT/'authoring/evidence/baselines/trivial',[c],portable=True);accepted=True;reason='valid control'
        except Exception as exc:accepted=False;reason=str(exc)
        rows.append({'family':family,'case':c['id'],'accepted':accepted,'reason':reason})
assert [r['case'] for r in rows if r['accepted']]==['zero-control']
(ROOT/'authoring/reports/zero_guess_per_case.json').write_text(json.dumps(rows,indent=2))
print('Accepted only zero-control; rejected other11 instances')
