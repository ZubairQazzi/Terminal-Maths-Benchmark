"""Fetch source-only research at one public immutable revision; no model calls."""
import concurrent.futures as cf
import hashlib
import json
from pathlib import Path
import urllib.request

ROOT = Path(__file__).resolve().parents[1] / 'research' / 'upstream'
tree = json.loads((ROOT / 'tree.json').read_text())
sha = tree['sha']
names = {'CONTRIBUTING.md', 'TASK_REVIEW_AUTOMATION.md', 'rubrics/task-implementation.toml',
         'rubrics/task-proposal.md', 'task-readme-template.md', '.github/reviewer-pool.yml',
         'tools/task-readme/generate.py'}
reference_slugs = ['mendota-ice-phenology', 'cilia-segmentation', 'si-fracture-fbc']
for item in tree['tree']:
    p = item['path']
    if item['type'] != 'blob':
        continue
    if p.startswith('ci_checks/check-') or p.startswith('scripts/check-'):
        names.add(p)
    if any('/' + s + '/' in p for s in reference_slugs) and (
        p.endswith(('.py', '.sh', '.toml', '.md', 'Dockerfile', 'requirements.txt'))
    ):
        names.add(p)

def fetch(p):
    dest = ROOT / p
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        data = urllib.request.urlopen(
            f'https://raw.githubusercontent.com/harbor-framework/terminal-bench-science/{sha}/{p}', timeout=40
        ).read()
        dest.write_bytes(data)
    return {'path': p, 'sha256': hashlib.sha256(dest.read_bytes()).hexdigest()}

with cf.ThreadPoolExecutor(max_workers=8) as pool:
    results = list(pool.map(fetch, sorted(names)))
(ROOT / 'source_manifest.json').write_text(json.dumps({'commit':sha,'files':results}, indent=2))
print(json.dumps({'commit':sha,'source_files':len(results)}))
