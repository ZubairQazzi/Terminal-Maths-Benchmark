"""Validate the exact standalone folder requested by the user."""
from native_validation import execute,HARBOR,ROOT,REPORT
execute([HARBOR,'lint',str(ROOT),'--json'],'harbor_standalone_lint_v011')
execute([HARBOR,'run','--path',str(ROOT),'--agent','oracle','--n-concurrent','1','--job-name','standalone-v011','--jobs-dir',str(REPORT/'harbor-jobs'),'--quiet'],'harbor_standalone_v011')
