"""Actual Linux identity/permission/resource and agent image leakage probes."""
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[2]
DOCKER=r'C:\Users\zubai\AppData\Local\Programs\DockerDesktop\resources\bin\docker.exe'
code=r'''
import json,os,pathlib,resource,subprocess,sys
sys.path.insert(0,'/tests')
from harness import restrict
child=r"""
import os,json,resource
out={'uid':os.getuid(),'gid':os.getgid(),'groups':os.getgroups()}
for k in ['CPU','AS','NOFILE','FSIZE']:
 out[k]=resource.getrlimit(getattr(resource,'RLIMIT_'+k))[0]
for k,p,mode in [('private_tests','/tests/cases.py','r'),('reward','/logs/verifier/reward.txt','w')]:
 try:
  f=open(p,mode);f.close();out[k]='ALLOWED'
 except PermissionError:out[k]='DENIED'
out['credential_variables']=[k for k in os.environ if 'API_KEY' in k or 'TOKEN' in k]
print(json.dumps(out))
"""
p=subprocess.run([sys.executable,'-c',child],preexec_fn=restrict,env={'PATH':'/usr/local/bin:/usr/bin:/bin'},capture_output=True,text=True,check=True)
d=json.loads(p.stdout)
assert d['uid']==d['gid']==65534 and d['groups']==[]
assert d['private_tests']==d['reward']=='DENIED' and d['credential_variables']==[]
assert d['CPU']==300 and d['AS']==2147483648 and d['NOFILE']==128
print(json.dumps(d))
'''
tag=sys.argv[1] if len(sys.argv)>1 else 'final010'
p=subprocess.run([DOCKER,'run','--rm','-i','--network','none','local-qp-verifier:'+tag,'python3','-'],input=code,text=True,capture_output=True,check=True)
result={'restricted_child':json.loads(p.stdout)}
p=subprocess.run([DOCKER,'run','--rm','--network','none','local-qp-agent:'+tag,'sh','-c',"test ! -e /tests/cases.py && test ! -e /solution/solve.py && find /app -type f"],capture_output=True,text=True,check=True)
result['agent_files']=p.stdout.splitlines();assert set(result['agent_files'])=={'/app/spec.md','/app/data/example.json'}
result['success']=True
(ROOT/'authoring/reports/security_probe.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
