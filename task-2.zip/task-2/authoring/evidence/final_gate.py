"""Close the available non-Gemini gate only after independent review resolves."""
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];R=ROOT/'authoring/reports'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
review=read(R/'independent_qc_findings.json')
assert not any(x['status'] in ('OPEN','FAIL','UNRESOLVED') for x in review['findings']), 'Review findings remain open'
assert 'IN PROGRESS' not in review.get('review_state',''), 'Review not final'
assert all(x['exit_code']==0 for x in read(R/'upstream_static.json'))
assert read(R/'local_validation.json')['success'] and read(R/'security_probe.json')['success']
manifest=read(R/'package_manifest.json')
for p,h in manifest['files'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
for job,want in [('standalone-v011',1),('zero-guess-frozen011',0)]:
    rows=[read(p) for p in (R/'harbor-jobs'/job).glob('*/result.json')]
    assert len(rows)==1 and rows[0]['exception_info'] is None and rows[0]['verifier_result']['rewards']['reward']==want
prior=read(R/'task1_readonly_snapshot.json')
assert all(hashlib.sha256(Path(x['Path']).read_bytes()).hexdigest().upper()==x['Hash'] for x in prior)
result={'task':'Task 2','version':'0.1.1','verdict':'TASK 2 - NON-GEMINI VALIDATION COMPLETE','static':{'pass':29,'total':29},'rubric':{'pass':37,'not_applicable':1,'total':38},'independent_qc':'PASS','oracle':'PASS','negative_baselines':'PASS','docker_harbor':'PASS','originality':'PASS_SCOPED','external_qc_panel':'NOT RUN','gemini_permission':'NOT REQUESTED','gemini_trials':'NOT RUN','success_rate':'NOT MEASURED','task1_unchanged':True,'limitations':['No external QC panel approval','No empirical model difficulty or timed human completion study','Scoped originality, not global uniqueness proof'],'runtime_hashes':manifest['files']}
(R/'final_gate.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
(R/'final_validation.md').write_text('# TASK 2 - NON-GEMINI VALIDATION COMPLETE\n\nTask: Task 2\n\nTask Name: Certified Parametric Quadratic Optimizer Atlas\n\nDomain: Mathematical Sciences / Applied Mathematics\n\nOriginality: PASS within pinned comparison scope\n\nTask Implementation: PASS\n\nOracle: PASS (two canonical native repeats and direct standalone run)\n\nNegative Baselines: PASS; six mandatory negatives plus shape-correct zero guess rejected\n\nHidden-Test Discrimination: PASS; the zero control is explicitly non-discriminating\n\nDocker/Harbor: PASS; clean offline builds, resets, artifact transfer, binary rewards and isolation verified\n\nStatic QC: 29/29 passed on canonical staging; standalone layout follows user direction\n\nRubric QC: 37/38 passed locally; optional hint criterion not applicable\n\nIndependent QC: PASS; distinct reviewer, corrections independently rechecked\n\nExternal QC: NOT RUN\n\nGemini Permission: NOT REQUESTED\n\nGemini Trials: NOT RUN\n\nObserved Success Rate: NOT MEASURED\n\nRemaining Issues: No unresolved locally executable mandatory defect; external panel approval and empirical difficulty/timing evidence unavailable or intentionally deferred.\n\nFinal Non-Gemini Verdict: VALIDATED\n\nOverall External QC Approval: NOT RUN\n\nThe native historical checksum and final documentation/standalone checksum distinction is explained in harbor_validation.md. Full evidence and independent final criterion statuses are retained. Task 1 hashes remain unchanged.\n',encoding='utf-8')
(ROOT/'authoring/trajectories/status.json').write_text(json.dumps({'status':'NOT RUN','permission':'NOT REQUESTED','valid_agent_trials':0}),encoding='utf-8')
print(result['verdict'])
