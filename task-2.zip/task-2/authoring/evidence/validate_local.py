"""Author-only measured tests. Portable runs do not establish container isolation."""
import copy
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import time
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tests'))
from cases import FAMILIES
from certificates import verify
from harness import run


def load_oracle():
    spec=importlib.util.spec_from_file_location('reference',ROOT/'solution/solve.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def setup_baselines():
    folder=ROOT/'authoring/evidence/baselines'
    programs={
        'noop':'pass\n',
        'constant':"import json,sys\nd=json.load(open(sys.argv[1]));json.dump({'cases':[{'id':c['id'],'cells':[]} for c in d['cases']]},open(sys.argv[2],'w'))\n",
        'hardcoded':"import json,sys\nd=json.load(open(sys.argv[1]));known=json.load(open(__file__.replace('solve.py','known.json')));json.dump({'cases':[dict(known,id=c['id']) for c in d['cases']]},open(sys.argv[2],'w'))\n",
        'unconstrained':"import json,sys,sympy as s\nfrom reference import encode,product\nd=json.load(open(sys.argv[1]));out=[]\nfor c in d['cases']:\n Q=s.Matrix(c['Q']);C=s.Matrix(c['c']);X=-Q.inv()*C;l,r,b,t=map(s.Rational,c['domain']);val=[s.Rational(0)]*6\n for i in range(Q.rows):\n  val=[a+z/2 for a,z in zip(val,product(C.row(i),X.row(i)))]\n out.append({'id':c['id'],'cells':[{'vertices':[(l,b),(r,b),(r,t),(l,t)],'x':X.tolist(),'dual':[[0,0,0] for _ in c['A']],'value':val}]})\njson.dump({'cases':out},open(sys.argv[2],'w'),default=encode)\n",
        'center-only':"import json,sys\nfrom reference import solve,encode\nd=json.load(open(sys.argv[1]));out=[]\nfor c in d['cases']:\n a=solve(c);a['cells']=a['cells'][:1];l,r,b,t=c['domain'];a['cells'][0]['vertices']=[[l,b],[r,b],[r,t],[l,t]];out.append(a)\njson.dump({'cases':out},open(sys.argv[2],'w'),default=encode)\n",
        'wrong-dual':"import json,sys\nfrom reference import solve,encode\nd=json.load(open(sys.argv[1]));out=[solve(c) for c in d['cases']]\nfor a in out:\n for cell in a['cells']:cell['dual']=[[-z for z in row] for row in cell['dual']]\njson.dump({'cases':out},open(sys.argv[2],'w'),default=encode)\n",
        'alternative':"import json,sys\nfrom reference import solve,encode\nd=json.load(open(sys.argv[1]));out=[]\nfor c in d['cases']:\n a=solve(c);cells=[]\n for cell in a['cells']:\n  p=cell['vertices']\n  for i in range(1,len(p)-1):\n   q=[p[0],p[i],p[i+1]]\n   if (q[1][0]-q[0][0])*(q[2][1]-q[0][1])-(q[1][1]-q[0][1])*(q[2][0]-q[0][0])>0:cells.append(dict(cell,vertices=q))\n a['cells']=list(reversed(cells));out.append(a)\njson.dump({'cases':out},open(sys.argv[2],'w'),default=encode)\n"
    }
    oracle=load_oracle();known=json.loads(json.dumps(oracle.solve(FAMILIES[0][1][1]),default=oracle.encode))
    for name,code in programs.items():
        dest=folder/name;dest.mkdir(parents=True,exist_ok=True)
        (dest/'solve.py').write_text(code)
        if name in ('unconstrained','center-only','wrong-dual','alternative'):
            (dest/'reference.py').write_bytes((ROOT/'solution/solve.py').read_bytes())
        if name=='hardcoded':(dest/'known.json').write_text(json.dumps(known))
    return folder


def main():
    started=time.monotonic();reports=ROOT/'authoring/reports';reports.mkdir(exist_ok=True)
    rows=[]
    for family,cases in FAMILIES:
        result=run(ROOT/'solution',cases,portable=True)
        rows.append({'family':family,'status':'PASS',**result});print(family,result,flush=True)
    baseline_dir=setup_baselines();neg=[]
    # Each baseline is measured per family, including control behavior.
    for name in ('noop','constant','hardcoded','unconstrained','center-only','wrong-dual','alternative'):
        for family,cases in FAMILIES:
            try:
                result=run(baseline_dir/name,cases,portable=True);passed=True;reason='accepted'
            except Exception as exc:
                passed=False;reason=str(exc)[:600]
            neg.append({'baseline':name,'family':family,'accepted':passed,'reason':reason})
        print('baseline',name,[x['family'] for x in neg if x['baseline']==name and x['accepted']],flush=True)
    assert all(x['accepted'] for x in neg if x['baseline']=='alternative')
    assert all(not all(x['accepted'] for x in neg if x['baseline']==name) for name in ('noop','constant','hardcoded','unconstrained','center-only','wrong-dual'))
    oracle=load_oracle();case=FAMILIES[1][1][0]
    correct=json.loads(json.dumps(oracle.solve(case),default=oracle.encode));mutations=[]
    def check(label,change):
        bad=copy.deepcopy(correct);change(bad)
        try:verify(case,bad)
        except Exception as exc:mutations.append({'mutation':label,'rejected':True,'reason':str(exc)});return
        raise AssertionError('Accepted mutation: '+label)
    check('coverage-hole',lambda a:a['cells'].pop())
    check('overlap',lambda a:a['cells'].append(copy.deepcopy(a['cells'][0])))
    check('stationarity',lambda a:a['cells'][0]['x'][0].__setitem__(0,'999'))
    check('objective-cross-term',lambda a:a['cells'][0]['value'].__setitem__(4,'999'))
    check('negative-dual',lambda a:a['cells'][0]['dual'][0].__setitem__(0,'-999'))
    check('clockwise',lambda a:a['cells'][0]['vertices'].reverse())
    check('float',lambda a:a['cells'][0]['x'][0].__setitem__(0,0.0))
    check('bool',lambda a:a['cells'][0]['x'][0].__setitem__(0,True))
    check('outside-domain',lambda a:a['cells'][0]['vertices'][0].__setitem__(0,'999'))
    check('missing-field',lambda a:a['cells'][0].pop('value'))
    result={'oracle':rows,'baselines':neg,'mutations':mutations,'seconds':time.monotonic()-started,'docker_validated':False,'harbor_validated':False,'success':True}
    (reports/'local_validation.json').write_text(json.dumps(result,indent=2))
    print('PASS',result['seconds'],flush=True)


if __name__=='__main__':main()
