"""Source-only pinned instruction corpus and transparent lexical comparisons."""
import concurrent.futures as cf
import hashlib
import json
from pathlib import Path
import re
import sys
import urllib.request
ROOT=Path(__file__).resolve().parents[2]
UP=ROOT/'authoring/research/upstream'


def main():
    tree=json.loads((UP/'tree.json').read_text());sha=tree['sha']
    paths=[x['path'] for x in tree['tree'] if x['type']=='blob' and x['path'].startswith(('tasks/','lite/')) and x['path'].endswith('/instruction.md')]
    corpus=ROOT/'authoring/plagiarism/corpus';corpus.mkdir(exist_ok=True,parents=True)
    def fetch(p):
        dest=corpus/p
        if not dest.exists():
            data=urllib.request.urlopen(f'https://raw.githubusercontent.com/harbor-framework/terminal-bench-science/{sha}/{p}',timeout=45).read()
            dest.parent.mkdir(exist_ok=True,parents=True);dest.write_bytes(data)
        return {'path':p,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()}
    with cf.ThreadPoolExecutor(max_workers=8) as pool:manifest=list(pool.map(fetch,paths))
    (corpus/'manifest.json').write_text(json.dumps({'commit':sha,'files':manifest},indent=2))
    spec=__import__('importlib.util',fromlist=['x']).spec_from_file_location('similarity',UP/'ci_checks/check-similarity.py')
    module=__import__('importlib.util',fromlist=['x']).module_from_spec(spec);spec.loader.exec_module(module)
    refs={p.relative_to(corpus).as_posix():p.read_text(encoding='utf-8') for p in corpus.rglob('instruction.md')}
    assert len(refs)==len(manifest), 'Every pinned instruction must participate'
    previous=Path(r'F:\rl\Task-1-maths\tasks\mathematical-sciences\applied-mathematics\certified-pencil-structure')
    refs['existing-task-1']=(previous/'instruction.md').read_text(encoding='utf-8')
    score,closest=module.check_similarity((ROOT/'instruction.md').read_text(),refs)
    assert score<module.SIMILARITY_THRESHOLD
    def grams(p):
        words=re.findall(r'[A-Za-z_]+|\d+',p.read_text(errors='replace').lower())
        return set(tuple(words[i:i+9]) for i in range(len(words)-8))
    comparisons=[]
    for ours in (ROOT/'solution/solve.py',ROOT/'tests/certificates.py',ROOT/'tests/cases.py'):
        a=grams(ours)
        sources=list((UP/'tasks').rglob('*.py'))+list((previous/'solution').glob('*.py'))+list((previous/'tests').glob('*.py'))
        scores=[]
        for ref in sources:
            b=grams(ref);scores.append((len(a&b)/len(a|b) if a|b else 0,str(ref)))
        best=max(scores,default=(0,''));comparisons.append({'source':str(ours.relative_to(ROOT)),'max_9_token_jaccard':best[0],'closest':best[1]})
    result={'status':'PASS_SCOPED','instruction_corpus_commit':sha,'instruction_count':len(refs),'tfidf_max_cosine':score,'closest_instruction':closest,'threshold':module.SIMILARITY_THRESHOLD,'code_comparisons':comparisons,'semantic_assessment':'Classical multiparametric QP theory; newly authored certificate-atlas benchmark. Distinct from pencil algebra, phenology, segmentation and fracture. No global uniqueness claim.','limitations':['Lexical similarity is not proof of originality.','No exhaustive search of unpublished/private benchmarks.','Standard mathematical identities and generic process isolation are not distinctive scientific borrowing.']}
    report=ROOT/'authoring/plagiarism/reports';report.mkdir(exist_ok=True,parents=True)
    (report/'plagiarism_report.json').write_text(json.dumps(result,indent=2))
    (report/'plagiarism_report.md').write_text('# Scoped originality audit\n\n'+f'PASS within the inspected scope: {len(manifest)} pinned main/lite instructions plus existing Task 1, {len(refs)} total references; maximum actual upstream TF-IDF cosine {score:.6f} (threshold 0.80), closest {closest}.\n\n'+'The math is classical, as described in the cited research. The input generator, rational atlas contract, optimization oracle and certificate checker are newly authored. The science reference tasks use imagery and atomistic models. Task 1 uses polynomial matrix pencils; no distinctive mathematical implementation is reused. Generic isolation conventions are shared infrastructure. Source-token comparisons are in the JSON report.\n\n'+'This is a scoped investigation, not proof of global originality or an external plagiarism-service verdict.\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
