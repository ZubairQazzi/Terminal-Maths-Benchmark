"""Deterministic Harbor adapters for measured controls; no model calls."""
from pathlib import Path
from harbor.agents.base import BaseAgent
from harbor.agents.capabilities import AgentCapabilities


class UploadAgent(BaseAgent):
    capabilities=AgentCapabilities(windows=True)
    kind='constant'
    @classmethod
    def name(cls):return 'local-'+cls.kind
    def version(self):return '0.1.0'
    async def setup(self,environment):return None
    async def run(self,instruction,environment,context):
        await environment.upload_dir(source_dir=Path(__file__).parent/'baselines'/self.kind,target_dir='/app/submission')
        (self.logs_dir/'baseline.txt').write_text('Deterministic '+self.kind+' control. No model or API call.\n')


class ConstantAgent(UploadAgent):kind='constant'
class HardcodedAgent(UploadAgent):kind='hardcoded'
class UnconstrainedAgent(UploadAgent):kind='unconstrained'
class IncompleteAgent(UploadAgent):kind='center-only'
class IncorrectAgent(UploadAgent):kind='wrong-dual'
class AlternativeAgent(UploadAgent):kind='alternative'
class TrivialAgent(UploadAgent):kind='trivial'
