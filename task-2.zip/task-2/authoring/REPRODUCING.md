# Reproduction

Runtime root: F:/rl/task-2. Use the descriptive canonical task path printed by prepare_package.py for Harbor and upstream repository-path checks. The root runtime files and canonical copy are hash-matched.

Installed tools on this PC: Python 3.12.10 at C:/Users/zubai/AppData/Local/Programs/Python/Python312/python.exe; Harbor 0.27.0 at C:/Users/zubai/.local/bin/harbor.exe; Docker CLI at C:/Users/zubai/AppData/Local/Programs/DockerDesktop/resources/bin/docker.exe. No model key is needed.

```powershell
Set-Location F:\rl\task-2
& 'C:\Users\zubai\AppData\Local\Programs\Python\Python312\python.exe' -B .\authoring\evidence\validate_local.py
& 'C:\Users\zubai\AppData\Local\Programs\Python\Python312\python.exe' -B .\authoring\evidence\prepare_package.py
& 'C:\Users\zubai\AppData\Local\Programs\Python\Python312\python.exe' -B .\authoring\evidence\native_validation.py build --suffix unique-reproduction
& 'C:\Users\zubai\AppData\Local\Programs\Python\Python312\python.exe' -B .\authoring\evidence\native_validation.py static --suffix unique-reproduction
& 'C:\Users\zubai\AppData\Local\Programs\Python\Python312\python.exe' -B .\authoring\evidence\native_validation.py harbor --suffix unique-reproduction
```

Choose a new suffix; native tooling refuses to overwrite existing console logs. Build dependencies are supplied with exact hashes. No internet is required to install them. The base image digest must already be cached or reachable. Raw trial files are preserved per job; no model-agent runs are part of this reproduction.

Reports distinguish portable math checks, native Docker/Harbor evidence, independent review and external panel status. Read the latest final gate report before using this task as validated evidence.
