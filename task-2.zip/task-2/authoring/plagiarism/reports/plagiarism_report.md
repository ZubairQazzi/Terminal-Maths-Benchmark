# Scoped originality audit

PASS within the inspected scope: 97 pinned main/lite instructions plus existing Task 1, 98 total references; maximum actual upstream TF-IDF cosine 0.348013 (threshold 0.80), closest existing-task-1.

The math is classical, as described in the cited research. The input generator, rational atlas contract, optimization oracle and certificate checker are newly authored. The science reference tasks use imagery and atomistic models. Task 1 uses polynomial matrix pencils; no distinctive mathematical implementation is reused. Generic isolation conventions are shared infrastructure. Source-token comparisons are in the JSON report.

This is a scoped investigation, not proof of global originality or an external plagiarism-service verdict.
