import json,sys
x={'cases': [{'id': 'zero-control', 'cells': [{'vertices': [[-1, -1], [1, -1], [1, 1], [-1, 1]], 'x': [[0, 0, 0]], 'dual': [[0, 0, 0]], 'value': [0, 0, 0, 0, 0, 0]}], 'diagnostics': {'elapsed_seconds': 0.125}}]}
json.dump(x,open(sys.argv[2],'w'))
