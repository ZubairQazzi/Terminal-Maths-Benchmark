import json,os,sys
assert os.getuid()==65534 and os.getgid()==65534 and os.getgroups()==[]
for path,mode in [('/tests/cases.py','r'),('/logs/verifier/reward.txt','w'),(__file__,'a')]:
    try:
        f=open(path,mode);f.close()
    except PermissionError:
        continue
    raise AssertionError('unexpected access to '+path)
c=json.load(open(sys.argv[1]))['cases'][0]
l,r,b,t=c['domain']
answer={'cases':[{'id':c['id'],'cells':[{'vertices':[[l,b],[r,b],[r,t],[l,t]],'x':[[0,0,0]],'dual':[[0,0,0]],'value':[0,0,0,0,0,0]}]}]}
json.dump(answer,open(sys.argv[2],'w'))
