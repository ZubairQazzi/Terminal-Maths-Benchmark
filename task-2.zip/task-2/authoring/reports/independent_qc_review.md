# Independent Task 2 QC review

Reviewer: `/root/task2_independent_qc`, a distinct fresh-context QC sub-agent. The original request, complete `QC-CHECKLIST.md`, previous failure feedback, mathematical specification, runtime sources, oracle, evaluator and Dockerfiles were read directly. The first output-contract findings were formed and preserved before consulting creator explanations; subsequent rubric/evidence findings and every recheck are recorded below. The reviewer changed only author-only review/probe files. No Gemini, paid API, external QC panel, publishing or GitHub operation was used.

Local non-Gemini verdict: **PASS**. All 29 static criteria pass; 37 of 38 rubric criteria pass and the optional-hint criterion is not applicable. All nine findings are resolved with direct rechecks. This is independent local review, not external QC approval.

## Mathematical and behavioral assessment

The formulation is sound: positive definiteness gives a unique primal minimizer on every nonempty polyhedron, including lower-dimensional feasible sets. Polyhedral normal cones and conic reduction justify an independent active support of size at most n; its KKT matrix is nonsingular and yields rational affine laws. Their primal/dual nonnegativity regions are rational polygons. The reference computes these objects from each input and has no test imports or hardcoded answers.

The independently implemented verifier is sufficient for the accepted output contract. Affine inequalities valid at all vertices hold on the entire convex polygon. Full polynomial stationarity, complementarity and objective identities certify KKT optimality. Exact convexity/containment, zero-area pairwise intersections and equal rectangle area prove coverage: a finite closed union missing any rectangle point would omit a relative open neighborhood of positive area. No numerical tolerance or canonical active-set partition biases the result.

Reviewer probes accepted six new n=4,m=12 moving-bound instances and an eight-case invocation with 16-digit rational data. The latter completed in 17.17 seconds under the offline native Linux restrictions. A manually derived split of duplicate-row multipliers, an allowed positive zero-row multiplier and a redundant collinear boundary vertex passed; a perturbed allocation failed stationarity. Correct triangulated/reordered atlases also passed all native families. The latter comparator reuses the oracle optimizer, so it is evidence for representation flexibility rather than an independently implemented optimizer.

The reviewer also independently executed the shape-correct zero atlas against all twelve inputs: only the explicitly non-discriminating zero-control passed; the other eleven failed mathematical checks. Its supplemental frozen native Harbor run earned reward 0 with ten failed family tests. The empty constant-output baseline is treated only as a gross-contract check, not scientific discrimination evidence. See `independent_zero_guess_per_case.json`.

The native permission probe confirmed UID/GID 65534, empty groups, denied private-test reads, denied reward writes and denied source mutation. Fresh work/output paths, separate verifier state and exact scientific checks prevent the tested stale-output, direct reward, trivial lookup and incomplete-map shortcuts. No claim of exhaustive adversarial security or exhaustive rational-input testing is made.

## Findings and independent rechecks

| Finding | Initial status | Final status | Correction and recheck |
|---|---|---|---|
| IQC-001 | FAIL | RESOLVED | Ignored extra output JSON fields were globally rejected when they contained ordinary numeric floats, contradicting the output contract. Only parsed mathematical fields enforce exact rational types; standard JSON floats may occur in ignored metadata. Recheck: independent_recheck_probes.json: same exact certificate with diagnostics.elapsed_seconds 0.125 accepted; float/bool mathematical coefficients still rejected |
| IQC-002 | FAIL | RESOLVED | The rational parser required a minus-only numerator sign and no leading zeros in a denominator, rejecting equivalent signed integer/fraction spellings allowed by the specification. Parse signed numerator and positive integer denominator, including explicit plus and leading zeros. Recheck: independent_recheck_probes.json: five equivalent spellings accepted; zero/negative denominators, bools and mathematical floats rejected |
| IQC-003 | WARNING | RESOLVED | Execution specification included artifact-transfer mechanism and sandbox hygiene details discouraged by the pinned instruction_clarity rubric. State self-contained program, offline/read-only requirements and relevant wall/CPU/address-space/output limits as requirements. Recheck: Current environment/spec.md Execution inspected directly: staging narration and hygiene details removed; scientific requirements retained |
| IQC-004 | FAIL | RESOLVED | README Difficulty lacked explicit synthetic-data and professional-workflow context and included a target agent pass-rate figure, contrary to pinned rubric guidance. Describe synthetic rational instances and control/optimization researcher use; keep calibration targets in author-only reports. Recheck: Current README.md Difficulty inspected: both required context sentences present; no pass-rate figure; estimate clearly unmeasured |
| IQC-005 | FAIL | RESOLVED | Originality evidence skipped four UTF-8 corpus instructions under Windows cp1252 and reported an inaccurate corpus/reference count. Read all corpus files as UTF-8 and report 97 corpus instructions + 1 prior task = 98 total. Recheck: independent_similarity.json: all 97 hashes match; all UTF-8 files decode; 98 total references; maximum cosine 0.3480133285469611 < 0.8; Corrected plagiarism_report.md/json inspected; exact count and score agree |
| IQC-006 | WARNING | RESOLVED | The execution contract described a CPU limit per invocation, but RLIMIT_CPU is per process. State CPU and address-space limits per process. Recheck: Current environment/spec.md states 300 CPU seconds per process and 2 GiB address-space per process, matching enforcement |
| IQC-007 | FAIL | RESOLVED | The actual generated-README check failed initially. Correcting header encoding left a CRLF/body-normalization mismatch, which the qc011 recheck also detected. Use generator-compatible UTF-8 text and newline normalization, regenerate root/staging README, then rerun the real check. Recheck: Final upstream_static.json contains all 26 exit-0 checks including task-readme; root/canonical final hashes match; UTF-8 glyphs and generator-compatible newline output inspected. |
| IQC-008 | FAIL | RESOLVED | All source symlinks were rejected, including an internal self-contained helper alias, without an explicit contract restriction. The specification now requires regular files/directories and explicitly excludes symbolic links. Recheck: Frozen environment/spec.md Execution inspected; existing verifier restriction is now explicit and unchanged. |
| IQC-009 | WARNING | RESOLVED | A literal fixed submission-path invocation could imply that the source path is fixed, while the harness executes a read-only relocated program directory. Specify the command-line interface independently of source location, and require operation from any read-only source directory with supporting files located relative to the program. Recheck: Frozen specification states both the portable directory requirement and the unchanged /app/submission deliverable location; harness behavior now matches the documented requirement. |

Initial artifacts remain in `independent_initial_probes.json`, `independent_initial_static.json`, `independent_initial_package_manifest.json` and `independent_initial_originality_warnings.log`. Corrected behavior is independently preserved in `independent_recheck_probes.json` and `independent_native_contract_recheck.log`. The complete finding record is `independent_qc_findings.json`.

## Raw execution and package evidence

The reviewer parsed each raw result, literal reward file and all ten individual CTRF statuses in the nine qc011 trials: two oracle runs and the triangulated alternative earned 1; all six incorrect baselines earned 0. All nine share task checksum `22d3d684bd99bab18379dec477ac9e12ee5b241b1fbf16ea1744d19276dd0902`. The separate standalone-root oracle earned 1 with 10/10 tests. The reviewer checked all 27 current package manifest entries against both standalone and canonical staging bytes, found no extra canonical files, and hash-compared every verifier runtime source in the qc011 image with the current files. See `independent_final_evidence.json`.

Later README whitespace and specification clarifications affect package checksums without changing executable code, mathematical input generation or acceptance. The qc011 historical checksum, standalone run and final file manifest are deliberately distinct evidence. Final static rechecks and clean image builds cover the documentation-frozen package; prior native runs are not mislabeled as having an identical final-package checksum.

The reviewer independently decoded all 97 manifest-verified corpus instructions as UTF-8 and compared them plus Task 1: 98 references, maximum TF-IDF cosine 0.3480133285, below the 0.80 investigation threshold. Scientific objectives and implementation structures differ from the matrix-pencil task and supplied science examples. This supports scoped originality, not proof of global uniqueness.

## All 29 static criteria

| ID | Status | Independent evidence and source |
|---|---|---|
| entry-files | PASS | All five required entry files exist in root and canonical stage; the final manifest has 27 matched files. (instruction.md:2) |
| config-fields | PASS | Supported schema 1.4 fields; installed Harbor lint is empty and actual native runs parse the manifest. (task.toml:2) |
| task-fields | PASS | Publisher/name/description/author/keyword metadata is populated without fabricated human credentials. (task.toml:4; authoring/reports/upstream_static.json:3) |
| task-path | PASS | Canonical staging follows tasks/mathematical-sciences/applied-mathematics/certified-qp-atlas; standalone task-2 follows the explicit user override. (task.toml:11; authoring/reports/upstream_static.json:8) |
| task-structure | PASS | Stage contains only recognized runtime scaffold, imported code, data and build wheels; author materials remain outside image contexts. (authoring/reports/package_manifest.json:2; authoring/reports/upstream_static.json:13) |
| task-slug | PASS | certified-qp-atlas is descriptive kebab case with three tokens. (task.toml:5; authoring/reports/upstream_static.json:18) |
| task-readme | PASS | The exact pinned generated-README check now exits 0 after UTF-8 and newline repairs. (README.md:2; authoring/reports/upstream_static.json:23) |
| canary | PASS | The actual eligible-source canary check exits 0. (instruction.md:1; authoring/reports/upstream_static.json:28) |
| task-absolute-path | PASS | Submission, specification and example locations use absolute paths. (instruction.md:4; authoring/reports/upstream_static.json:33) |
| instruction-suffix | PASS | Canonical 28800-second trailer agrees with the required 8-hour agent budget. (instruction.md:8; authoring/reports/upstream_static.json:38) |
| instruction-similarity | PASS | Reviewer independently read all 97 hash-verified UTF-8 corpus instructions plus Task 1; cosine 0.3480133285 is below 0.80. (authoring/reports/independent_similarity.json:8) |
| test-file-references | PASS | The only required submission source directory and entry point are explicit in the contract; output is supplied by argument. (tests/test_outputs.py:8; authoring/reports/upstream_static.json:43) |
| dockerfile-references | PASS | COPY requirements, wheels, specification, example and verifier sources all resolve within their build contexts. (environment/Dockerfile:3; authoring/reports/upstream_static.json:48) |
| dockerfile-sanity | PASS | Native no-cache builds succeed; Dockerfile operations are necessary local setup. (environment/Dockerfile:2; authoring/reports/upstream_static.json:53) |
| dockerfile-platform | PASS | No hardcoded --platform declaration; the base is pinned by immutable digest. (environment/Dockerfile:2; authoring/reports/upstream_static.json:58) |
| allow-internet | PASS | Explicit public agent networking satisfies the active upstream profile; submitted-code grading is no-network and requires offline operation. (task.toml:30; authoring/reports/upstream_static.json:63) |
| separate-verifier | PASS | Native trial results confirm separate mode and source-only artifact transfer. (task.toml:27; authoring/reports/upstream_static.json:68) |
| compose-host-binds | PASS | No shipped Compose host bind or unrelated host mount; local author validation mounts are not runtime task configuration. (task.toml:3; authoring/reports/upstream_static.json:73) |
| task-timeout | PASS | Agent 28800 seconds, verifier 3600 seconds, and 900-second image build declaration meet the active checks. (task.toml:23; authoring/reports/upstream_static.json:78) |
| gpu-types | PASS | No GPU is requested. (task.toml:34; authoring/reports/upstream_static.json:83) |
| task-resources | PASS | Explicit 2 CPUs, 4096 MiB RAM, 10240 MiB storage and zero GPUs are within the active profile. (task.toml:31; authoring/reports/upstream_static.json:88) |
| verifier-resources | PASS | Separate verifier explicitly declares matching CPU, memory, storage and GPU allocations. (task.toml:29; authoring/reports/upstream_static.json:93) |
| nproc | PASS | No bare nproc usage; the actual rule exits 0. (authoring/reports/upstream_static.json:98; authoring/reports/upstream_static.json:98) |
| verifier-tooling-baked | PASS | All verifier tools are installed from local hashed wheels during build; test.sh installs nothing. (tests/Dockerfile:5; authoring/reports/upstream_static.json:103) |
| trial-network-fetch | PASS | Trial scripts perform no download and the verifier has no network. (tests/test.sh:8; authoring/reports/upstream_static.json:108) |
| pip-pinning | PASS | Every Python dependency is pinned and hash locked; both images install with --no-index --require-hashes. (tests/requirements.txt:8; authoring/reports/upstream_static.json:113) |
| pytest-version | PASS | pytest 8.4.1 and pytest-json-ctrf 0.3.5 match the required pins. (tests/requirements.txt:8; authoring/reports/upstream_static.json:118) |
| test-sh-sanity | PASS | Protected reward initialization, isolated Python invocation and fail-closed binary score follow the conventions. (tests/test.sh:4; authoring/reports/upstream_static.json:123) |
| binary-reward | PASS | All nine native reward files were read as literal 0 or 1; successful scientific tests alone cause reward 1. (tests/test.sh:6; authoring/reports/upstream_static.json:128) |

## All 38 rubric criteria

| ID | Status | Independent evidence and source |
|---|---|---|
| well_specified | PASS | The goal, input/output schema, exactness, closed-domain obligations, portable source path, no-symlink policy, offline operation and per-process limits are explicit. (environment/spec.md:44) |
| test_instruction_alignment | PASS | Every mathematical/geometry/schema assertion maps to the specification. Rejected metadata/rational spellings were repaired; source restrictions and relocation are now stated. (tests/certificates.py:64) |
| instruction_clarity | PASS | The instruction describes the atlas outcome and points to the complete spec without revealing hidden data, reward bookkeeping or a solution recipe. (instruction.md:6) |
| structured_data_schema | PASS | Fields, dimensions, coefficient order, rational representation, cell bounds and flexible ordering/subdivision rules match the actual parser. (environment/spec.md:24) |
| typos | PASS | Identifiers, paths and invocation arguments were read directly and exercised by native execution. (environment/spec.md:46) |
| hint_discoverability | NOT APPLICABLE | No authoring/hint.md is supplied; this optional-hint criterion is not applicable. (authoring/inputs/QC-CHECKLIST.md:66) |
| scientifically_grounded | PASS | Exact multiparametric optimization is tied to explicit constrained control and sensitivity analysis; synthetic instances require mathematical optimization and geometry. (README.md:28) |
| scope | PASS | The substantive subject fits Mathematical Sciences / Applied Mathematics: convex optimization, exact algebra and computational geometry. (task.toml:11) |
| essential_difficulty | PASS | The work joins exact KKT systems, degeneracy, polygon clipping and global continuum coverage; precision protects real thin regions rather than a numerical matching tolerance. (README.md:28) |
| novel | PASS | Within the scoped source/semantic review, new inputs and atlas/certificate construction require computation; classical theory is not claimed as new research. (authoring/reports/independent_similarity.json:8) |
| agentic | PASS | Delivering reusable exact software calls for mathematical implementation, running cases and debugging coupled algebra/geometry; no scalar answer or canned data conversion suffices. (solution/solve.py:68) |
| verifiable | PASS | Independent Fraction arithmetic checks concrete certificates, exact polynomial identities, feasibility and complete nonoverlapping coverage without an optimizer oracle. (tests/certificates.py:64) |
| solvable | PASS | Two fresh full native oracles and the standalone oracle pass. An independent eight-case invocation at dimension/row/digit bounds passes under native restrictions. (authoring/reports/independent_final_evidence.json:9) |
| outcome_verified | PASS | No active-set labels or canonical atlas are required. Triangulation/reordering passes all families; a manually derived alternative dual allocation and collinear vertex pass. (authoring/reports/independent_alternative_certificate.json:183) |
| functional_verification | PASS | Submitted code is actually executed, its fresh output is parsed, and scientific claims are recomputed. Text keywords and success flags cannot supply correctness. (tests/harness.py:47) |
| ground_truth_provenance | PASS | Seeded input generation is inspectable. The verifier grades exact KKT/value/coverage obligations and has no oracle-generated answer key. (tests/cases.py:7) |
| graded_instances_discriminate | PASS | The zero control is explicitly easy; clamp/thin/zero-row/metamorphic roles are qualified. Six native negative baselines fail and meaningful mathematical mutations are rejected. (authoring/reports/test_discrimination_audit.md:3) |
| solution_quality | PASS | The reference derives affine maps and rational polygons from each Q/A/b/c/domain. It imports no hidden tests and stores no expected atlas. (solution/solve.py:82) |
| do_not_modify_enforced | PASS | The declared read-only source boundary is enforced by root ownership and permissions; reviewer native code could not append its own source. Pristine verifier inputs are isolated. (tests/harness.py:39) |
| deterministic_reproducible | PASS | Fixed seeds, hashed local dependencies, exact arithmetic and two clean native oracle passes agree; no live service affects grading. (authoring/reports/independent_final_evidence.json:92) |
| separate_verifier_configured | PASS | All required code/data comes from declared submission artifacts or baked verifier files. Tools and matching core dependency versions are present in both image contexts. (task.toml:27) |
| verifier_execution_isolation | PASS | Candidate code runs in a subprocess after UID/GID 65534 and empty groups; tests and reward remain root private. Native permission probes deny access and source mutation. (tests/harness.py:18) |
| anti_cheat_robustness | PASS | Fresh per-invocation files, immutable verifier calculations, source symlink rejection, sanitized environment and protected reward prevent the tested direct shortcuts. (tests/harness.py:33) |
| task_security | PASS | No task code accesses credentials, exports data or requests host mounts. Necessary local artifact execution has an offline, unprivileged verifier boundary. (task.toml:30) |
| resource_configuration | PASS | The independent 8-case maximum dimension/row/digit probe finishes in 17.17 seconds in the restricted Linux harness; full native suite and alternative have ample declared resources. (authoring/reports/independent_native_bounds.log:2) |
| task_toml_schema | PASS | Actual installed Harbor parses schema 1.4, emits no lint findings and runs the task; root fields and each section were inspected. (task.toml:2) |
| environment_hygiene | PASS | Only specification/example and mathematical dependencies enter the agent image. Tests/oracle remain separate; test tools are correctly baked into the private verifier image. (environment/Dockerfile:7) |
| artifact_efficiency | PASS | Only /app/submission source transfers. Work/output files are fresh and build-fixed data is baked, so no stale scientific output earns credit. (task.toml:3) |
| ctrf_reporting | PASS | Every raw qc011 trial has all ten named CTRF outcomes; success is 10/10 and each tested negative is 0/10. Literal reward files agree. (authoring/reports/independent_final_evidence.json:9) |
| task_authoring_dir | PASS | Research, generators, review evidence, logs and alternative probes are author-only; runtime folders contain their actual executed/imported resources. (authoring/reports/package_manifest.json:2) |
| no_extraneous_files | PASS | Canonical stage has exactly the 27 manifested purpose-bearing files; root runtime caches were cleaned. Wheels are required by offline builds. (authoring/reports/independent_final_evidence.json:4) |
| reviewable | PASS | The formulation, existence/KKT arguments, finite-region construction and exact coverage proof can be traced into independent evaluator code and retained positive/negative evidence. (authoring/research/mathematical_justification.md:7) |
| difficulty_explanation_quality | PASS | The explanation identifies interacting mathematical decisions, synthetic-data context and professional use; empirical extreme-difficulty and timing claims are explicitly unmeasured. (README.md:26) |
| solution_explanation_quality | PASS | The strategy matches implementation: independent active subsets, exact KKT solve, clipping/subtraction and objective polynomial expansion; the reference is genuine computation. (README.md:32) |
| verification_explanation_quality | PASS | The README explains vertex inequalities, polynomial identities, exact area/nonoverlap coverage, execution isolation and easy-control roles; there is no tuned numerical acceptance range. (README.md:36) |
| category_and_tags | PASS | Specific optimization, geometry, exact-certificate and quadratic-programming tags match the applied-mathematics field. (task.toml:9) |
| task_name | PASS | The canonical slug certified-qp-atlas is concise and descriptive; task-2 is the user-required standalone wrapper. (task.toml:5) |
| task_readme | PASS | The managed header and authored sections are accurate, informative and now pass the actual generator check after encoding/newline correction. (README.md:2) |

## Limitations

- External QC dashboard/panel: NOT RUN; no external approval is claimed.
- Gemini and other model-agent calibration: NOT RUN. The requested extreme difficulty and 40–60% success target are not empirically established. The 16-hour expert estimate is unmeasured.
- The pinned upstream rubric includes `difficult` and `expert_time_estimate` beyond the supplied 38 rubric items; empirical difficulty/time calibration remains NOT TESTED and is not counted as a local pass.
- Independent checks used finite generated cases and one manually derived alternate certificate. No separate complete optimizer implementation was authored by this reviewer.
- The active upstream profile requires public agent networking; the delivered solver must execute offline and the private verifier has no network.
- Review covers Task 2 only. It does not approve or design Task 3.

Checklist SHA-256: `66d8a65d56748ffb491339e851d827612e70d2138ceaa6f989962414a7225ffb`. Final package-manifest SHA-256: `a70992c6e8f9b78bb1667b718495a5396b45a0a5b85774e898b76b8ea10a9222`.
