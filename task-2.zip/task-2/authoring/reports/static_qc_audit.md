# Static QC audit

29 local checklist criteria. Twenty-six actual upstream shell checks ran offline in the native verifier image; entry/config and similarity have separately measured evidence. This is not an external dashboard verdict.

The standalone folder name/location follows the user’s explicit preference. Canonical staging supplies tasks/<domain>/<field>/<descriptive-slug> for repository-path checks. Every staged runtime file is hash-identical to its standalone counterpart. Publication contact/profile metadata explicitly says it was not supplied; no human identity is fabricated.

| ID | Status | Evidence |
|---|---|---|
| entry-files | PASS | Required five entry files exist in standalone root and canonical staging; package_manifest.json; task.toml:1 / package_manifest.json |
| config-fields | PASS | Harbor 0.27.0 lint returned []; native Harbor parsed and ran this manifest; task.toml:1 / package_manifest.json |
| task-fields | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| task-path | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| task-structure | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| task-slug | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| task-readme | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| canary | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| task-absolute-path | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| instruction-suffix | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| instruction-similarity | PASS | Actual upstream TF-IDF calculation: 98 references; max 0.348013<0.80; plagiarism_report.json; task.toml:1 / package_manifest.json |
| test-file-references | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| dockerfile-references | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| dockerfile-sanity | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| dockerfile-platform | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| allow-internet | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| separate-verifier | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| compose-host-binds | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| task-timeout | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| gpu-types | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| task-resources | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| verifier-resources | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| nproc | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| verifier-tooling-baked | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| trial-network-fetch | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| pip-pinning | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| pytest-version | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| test-sh-sanity | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
| binary-reward | PASS | Actual pinned upstream script exit 0; authoring/reports/upstream_static.json; task.toml:1 / package_manifest.json |
