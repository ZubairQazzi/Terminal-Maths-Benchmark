# QC remediation

The independent reviewer uses a fresh context under `/root/task2_independent_qc`; original findings and probes are retained separately, without replacing initial failures.

| Finding | Correction | Recheck evidence |
|---|---|---|
| Ignored diagnostics with floating values rejected | Parse ordinary JSON first; exact scalar enforcement stays on mathematical fields | independent_recheck_probes.json; full v0.1.1 regression |
| Legitimate signed/zero-padded rational spellings rejected | Parse signed integer numerator and positive integer denominator without canonical lexical restriction | independent_recheck_probes.json; invalid mathematical scalars remain rejected |
| Instruction-side staging and sandbox hygiene narration | State self-contained source, offline operation, read-only source and relevant resource/output requirements | Independent source recheck; unchanged mathematical requirements |
| CPU budget wording implied aggregate accounting | State per-process CPU/address-space limits and per-invocation wall time | Independent source and native restricted process inspection |
| Source symlink rejection was undocumented | State regular files/directories only and no symbolic links | Independent symlink probe; documentation recheck |
| Execution path differed from submitted source location | Define the argument interface and require helper lookup relative to the program at any read-only source-directory path | Independent contract/source recheck; executable checks unchanged |
| Difficulty omitted synthetic data/professional context; mentioned target success rate | Add explicit synthetic-control/optimization workflow context; keep calibration target in author-only records | Independent README source recheck |
| Windows encoding skipped four originality references | Decode every corpus instruction explicitly as UTF-8; assert full manifest count | 97 pinned references + Task 1 =98; independent_similarity.json matches score |
| Generated README encoding/blank-line drift | Explicit UTF-8 output and universal-newline normalization before extracting body | Exact pinned README static check rerun; see final static evidence |
| Upstream agent networking requirement | Set public agent workspace and no-network separate verifier; keep solver offline execution contract | Actual allow-internet check and native runs |

Version 0.1.1 repairs verifier fairness to the original mathematical contract. Mathematical fields must still be exact; no equations or coverage checks were relaxed. Prior native runs and failure logs remain preserved by suffix. Final README-only whitespace normalization does not change executable files, inputs, outputs, limits or mathematical acceptance; a final standalone oracle regression verifies the delivered folder.
