# Native Docker and Harbor validation

Actual commands are retained in each console log. The initially network-dependent build could not reach PyPI; it was interrupted and replaced with fully vendored hash-checked wheels. Both final images built with --no-cache. No successful network build is claimed.

| Job | Reward | CTRF passed/total | Checksum |
|---|---:|---|---|
| alternative-qc011 / certified-qp-atlas__8VCE9za | 1.0 | 10/10 | 22d3d684bd99bab18379dec477ac9e12ee5b241b1fbf16ea1744d19276dd0902 |
| constant-qc011 / certified-qp-atlas__orA4kLB | 0.0 | 0/10 | 22d3d684bd99bab18379dec477ac9e12ee5b241b1fbf16ea1744d19276dd0902 |
| hardcoded-qc011 / certified-qp-atlas__GzuKqdx | 0.0 | 0/10 | 22d3d684bd99bab18379dec477ac9e12ee5b241b1fbf16ea1744d19276dd0902 |
| incomplete-qc011 / certified-qp-atlas__24i3Gt7 | 0.0 | 0/10 | 22d3d684bd99bab18379dec477ac9e12ee5b241b1fbf16ea1744d19276dd0902 |
| incorrect-qc011 / certified-qp-atlas__LiusThL | 0.0 | 0/10 | 22d3d684bd99bab18379dec477ac9e12ee5b241b1fbf16ea1744d19276dd0902 |
| nop-qc011 / certified-qp-atlas__bWtBWR6 | 0.0 | 0/10 | 22d3d684bd99bab18379dec477ac9e12ee5b241b1fbf16ea1744d19276dd0902 |
| oracle-qc011 / certified-qp-atlas__33KVHXM | 1.0 | 10/10 | 22d3d684bd99bab18379dec477ac9e12ee5b241b1fbf16ea1744d19276dd0902 |
| oracle-qc011 / certified-qp-atlas__BZ2ZvM3 | 1.0 | 10/10 | 22d3d684bd99bab18379dec477ac9e12ee5b241b1fbf16ea1744d19276dd0902 |
| unconstrained-qc011 / certified-qp-atlas__ogaxWui | 0.0 | 0/10 | 22d3d684bd99bab18379dec477ac9e12ee5b241b1fbf16ea1744d19276dd0902 |

Two fresh oracle containers establish reset/repeatability. All six negative baselines fail; a valid alternate atlas passes. Native security probes deny private-test reads and reward writes. Canonical staging preserves runtime bytes; standalone wrapper layout is user-directed. Upstream agent networking is public; offline submitted-code execution is enforced in the separate no-network verifier. No model call, upload or publication occurred.

Final delivery note: the nine qc011 trials share one historical task checksum. Subsequent changes only normalize README whitespace and clarify the existing source-path/symlink execution contract; executable solution, evaluator, input data and mathematical acceptance are unchanged. Frozen011 clean images and all-static rerun validate the delivered specification. The separate standalone-v011 job directly evaluated F:/rl/task-2 and passed10/10 with reward1; its task checksum differs because the standalone wrapper contains authoring evidence. Independent hash evidence verifies all27 current packaged runtime files and current verifier code. These distinct checksums are not presented as identical.

A supplemental shape-correct zero-atlas program accepts only the explicitly disclosed zero-control among12 individual inputs (zero_guess_per_case.json), rejects the other11, and is also exercised by native zero-guess-frozen011. It supplements the six mandatory negatives; the empty constant baseline is not treated as mathematical discrimination evidence.

External QC panel: NOT RUN. Gemini: NOT REQUESTED / NOT RUN. Empirical AI success rate: NOT MEASURED.
