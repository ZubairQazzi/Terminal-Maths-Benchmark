# Test coverage

Ten mandatory independently named families, twelve instances. Every output cell is checked over an entire two-dimensional parameter continuum. These counts are coverage, not twelve claims of high difficulty.

| Family | Instances | Purpose | Difficulty role |
|---|---:|---|---|
| controls | 2 | Zero objective and scalar clamp | Non-discriminating zero control; clamp is a simple diagnostic, not expert evidence |
| coupled-two | 2 | Coupled objective and moving constraints | Discriminating multiregion geometry |
| coupled-three | 1 | Three-dimensional primal interaction | Discriminating |
| dimension-four | 1 | Upper dimension bound | Discriminating |
| dual-degeneracy | 1 | Duplicate scaled row and identically zero row | Discriminating overall; zero row itself is a control |
| lower-dimensional | 1 | Always binding opposing affine constraints | Discriminating degeneracy |
| thin-regions | 1 | Positive-area strip of width about 2e-11 | Precision/discovery diagnostic; scalar mathematics is simple |
| coordinate-scaling | 1 | Invertible variable scaling and poorly conditioned data | Discriminating exactness |
| row-metamorphic | 1 | Row permutation of moving-constraint problem | Certificate row-order regression, not independent scientific problem |
| rational-domain | 1 | Noninteger rectangle and coupled constraints | Boundary/geometry discrimination |

No hidden expected atlas is used. Per-family baseline outcomes and actual region counts are in local_validation.json and native CTRF. The problem permits several valid region subdivisions and multiplier choices. The alternate candidate triangulates every region and reverses cell order; it must pass the same full suite.
