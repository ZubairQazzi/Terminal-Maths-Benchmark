import json,sys
d=json.load(open(sys.argv[1]));json.dump({'cases':[{'id':c['id'],'cells':[]} for c in d['cases']]},open(sys.argv[2],'w'))
