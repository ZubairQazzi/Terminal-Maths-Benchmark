import json,sys,sympy as s
from reference import encode,product
d=json.load(open(sys.argv[1]));out=[]
for c in d['cases']:
 Q=s.Matrix(c['Q']);C=s.Matrix(c['c']);X=-Q.inv()*C;l,r,b,t=map(s.Rational,c['domain']);val=[s.Rational(0)]*6
 for i in range(Q.rows):
  val=[a+z/2 for a,z in zip(val,product(C.row(i),X.row(i)))]
 out.append({'id':c['id'],'cells':[{'vertices':[(l,b),(r,b),(r,t),(l,t)],'x':X.tolist(),'dual':[[0,0,0] for _ in c['A']],'value':val}]})
json.dump({'cases':out},open(sys.argv[2],'w'),default=encode)
