import json,sys
from reference import solve,encode
d=json.load(open(sys.argv[1]));out=[]
for c in d['cases']:
 a=solve(c);cells=[]
 for cell in a['cells']:
  p=cell['vertices']
  for i in range(1,len(p)-1):
   q=[p[0],p[i],p[i+1]]
   if (q[1][0]-q[0][0])*(q[2][1]-q[0][1])-(q[1][1]-q[0][1])*(q[2][0]-q[0][0])>0:cells.append(dict(cell,vertices=q))
 a['cells']=list(reversed(cells));out.append(a)
json.dump({'cases':out},open(sys.argv[2],'w'),default=encode)
