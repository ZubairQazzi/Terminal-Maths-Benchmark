"""Verify source distribution or restore the exact task from an authorized local copy.

Standard-library only. No network, subprocesses, package installs, deletion or regeneration.
Do not point Harbor at this source distribution before preparing a complete task.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import os
import shutil
import sys


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def safe_file(root, relative):
    parts = PurePosixPath(relative)
    if parts.is_absolute() or '..' in parts.parts or '\\' in relative or ':' in relative:
        raise ValueError('Unsafe manifest path: ' + relative)
    path = root.joinpath(*parts.parts)
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError('Path escapes root: ' + relative)
    current = root
    if current.is_symlink() or current.is_junction():
        raise ValueError('Linked root refused')
    for part in parts.parts:
        current = current / part
        if current.is_symlink() or current.is_junction():
            raise ValueError('Linked path refused: ' + relative)
    return path


def verify(path, expected):
    return (path.is_file() and path.stat().st_size == expected['bytes']
            and digest(path) == expected['sha256'])


def inspect(root, files):
    missing, mismatched = [], []
    for name, item in files.items():
        path = safe_file(root, name)
        if not path.exists():
            missing.append(name)
        elif not verify(path, item):
            mismatched.append(name)
    return missing, mismatched


def complete_check(root, manifest):
    missing, mismatched = inspect(root, manifest['files'])
    actual = set()
    for path in root.rglob('*'):
        if path.is_symlink() or path.is_junction():
            raise ValueError('Linked output refused')
        if path.is_file():
            actual.add(path.relative_to(root).as_posix())
    extra = sorted(actual - set(manifest['files']))
    if missing or mismatched or extra:
        raise ValueError(json.dumps({'missing': missing, 'mismatched': mismatched, 'extra': extra}))
    aggregate = hashlib.sha256(json.dumps(
        {name: digest(safe_file(root, name)) for name in sorted(manifest['files'])},
        sort_keys=True).encode()).hexdigest()
    if aggregate != manifest['aggregate_sha256']:
        raise ValueError('Complete-tree aggregate mismatch')
    return aggregate


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='Check complete task; missing payload exits 2')
    parser.add_argument('--task-root', type=Path, help='Complete prepared task to check')
    parser.add_argument('--frozen-source', type=Path, help='Lawfully held complete frozen task; read only')
    parser.add_argument('--output', type=Path, help='New complete task directory on F drive')
    args = parser.parse_args()
    base = Path(__file__).resolve().parent.parent
    manifest = json.loads((base / 'distribution/frozen_manifest.json').read_text(encoding='utf-8'))
    bundled = base / manifest['slug']
    if args.check:
        if args.frozen_source or args.output:
            parser.error('--check cannot be combined with preparation arguments')
        root = (args.task_root or bundled).resolve()
        missing, mismatched = inspect(root, manifest['files'])
        if missing or mismatched:
            print(json.dumps({'status': 'NOT_RUNNABLE', 'missing': missing, 'mismatched': mismatched,
                              'action': 'Restore exact files from an authorized complete frozen source.'}, indent=2))
            return 2
        print(json.dumps({'status': 'PASS', 'version': manifest['version'],
                          'files': len(manifest['files']), 'aggregate_sha256': complete_check(root, manifest)}))
        return 0
    if not args.frozen_source or not args.output or args.task_root:
        parser.error('Preparation requires --frozen-source and --output')
    source = args.frozen_source.resolve()
    output = args.output.absolute()
    # This Windows publication workflow promises all new artifacts stay on F.
    if os.name != 'nt' or output.drive.lower() != 'f:':
        parser.error('Preparation output must be a new directory on Windows F:')
    if output.exists() or output.is_symlink() or output.is_junction():
        raise ValueError('Refusing pre-existing output; choose a new directory')
    if not output.parent.is_dir() or output.parent.is_symlink() or output.parent.is_junction():
        raise ValueError('Output parent must be an existing ordinary directory')
    if output.resolve() != output or output.is_relative_to(source) or output.is_relative_to(bundled):
        raise ValueError('Output must be separate from source and source distribution')
    # Validate every file before writing any output. Bundled code always wins;
    # source arguments cannot replace a solution, verifier or scientific policy.
    selected = {}
    for name, item in manifest['files'].items():
        root = bundled if item['distribution'] == 'included_unchanged' else source
        path = safe_file(root, name)
        if not verify(path, item):
            raise ValueError('Missing or incorrect frozen file: ' + name)
        selected[name] = path
    output.mkdir(exist_ok=False)
    for name, path in selected.items():
        target = safe_file(output, name)
        target.parent.mkdir(parents=True, exist_ok=True)
        # Exclusive creation and post-copy digest prevent silent overwrite or drift.
        with path.open('rb') as src, target.open('xb') as dst:
            shutil.copyfileobj(src, dst, length=1024 * 1024)
    aggregate = complete_check(output, manifest)
    print(json.dumps({'status': 'PASS', 'version': manifest['version'], 'files': len(selected),
                      'aggregate_sha256': aggregate, 'output': str(output)}, indent=2))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError) as exc:
        print('PREPARATION REFUSED: ' + str(exc), file=sys.stderr)
        raise SystemExit(2)
