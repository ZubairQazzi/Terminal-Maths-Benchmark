# Transcript Provenance Audit v0.3.1: source and local acquisition

**This public ZIP is not a self-contained runnable Harbor task.** Data, derivatives,
private evaluator payloads and wheel binaries are intentionally absent. No scientific
file was substituted and no frozen requirement, solution, verifier or tolerance changed.
Do not run Harbor against the unprepared `transcript-provenance-audit/` directory.

The archive includes the unchanged instruction.md, task.toml, README.md, environment
Dockerfile/requirements, solution algorithms and separate verifier code. The source
files are author/reviewer materials: solution/ and tests/ are deliberately public here.
They are not copied into the agent Docker context. A solver with access to this public
repository can read reference code; preserve normal evaluation isolation yourself.

## Exact offline preparation (Python 3.12 or newer, Windows F drive)

Use an authorized, lawfully held **complete frozen task v0.3.1**, such as the
original local source, for the missing payload. Choose an existing parent on F: and
a new output directory; preparation refuses overwrite. Run from this extracted root:

```powershell
python -I -B distribution/prepare.py --check
# Expected: exit 2 / NOT_RUNNABLE until the payload is restored.
python -I -B distribution/prepare.py --frozen-source 'F:/path/to/complete/transcript-provenance-audit' --output 'F:/path/to/new-transcript-provenance-audit'
python -I -B distribution/prepare.py --check --task-root 'F:/path/to/new-transcript-provenance-audit'
```

The script has no network, shell, install or regeneration mode. It verifies every
bundled source file and every omitted payload's byte count and SHA-256 before creating
the output. It then verifies the complete 51-file tree against
the frozen manifest, including the aggregate below. A wrong or missing file fails
closed. It creates no fake data and never changes the original frozen task. A
successful exact reconstruction can be supplied to Harbor locally with the original
Docker and verifier isolation. Scientific dependency wheels and grader dependencies
are restored to their separate original contexts, not installed on the host.

Frozen aggregate SHA-256: `90ccdb0ef7de6b9a7948394823bbd22e9d11e2067156c53be907d717e2a1dd73`

Harbor frozen task checksum: `1c3e7498e4db3296bf81485b7b718c27cfdb578b18bb51b9a3c2651f643a63bd`

## Provenance, acquisition and permissions

The biological measurements originate from NCBI GEO GSE273600. Original raw-count
and TPM URLs, byte counts and SHA-256s are in distribution/source_acquisition.json.
For lawful original-data acquisition, obtain those exact files from the listed official
URLs into a new F-drive directory and verify SHA-256 and size **before parsing**:

```powershell
Get-FileHash -Algorithm SHA256 -LiteralPath 'F:/new-data/GSE273600_Control_Conditions_Raw_Counts.txt.gz'
Get-FileHash -Algorithm SHA256 -LiteralPath 'F:/new-data/GSE273600_Control_Conditions_TPMs.txt.gz'
```

These original downloads alone are **not** a complete frozen-task preparation
recipe. Associated annotations, metadata, controlled cases and, for Task 2, OS-randomized
anonymous fixtures and private evaluator truth are also required. Private generation
records are excluded. There is no established public-only recipe that regenerates
their exact frozen bytes. Acquire an authorized complete local payload; otherwise
preparation must stop. SHA-256 metadata does not grant access or permission.

Unrestricted redistribution of the deposited matrices or derivatives is not established.
The cached associated publication was labeled CC BY-NC-ND 4.0; this is not treated as
a blanket license for GEO deposits or derivatives. NCBI repository availability is not
a transfer of third-party rights: https://www.ncbi.nlm.nih.gov/home/about/policies/ .
Obtain rights clarification before distributing a hydrated task or image. Specific
third-party wheel-license review is also incomplete, so wheel binaries are omitted;
pinned versions and exact file hashes remain in the source/manifest. Do not silently
substitute package versions or assume every frozen wheel is available from PyPI.
External model/provider processing permission is unresolved. No external model or
model API was used for this packaging. No new blanket license is granted here.

## Validation and limitations

Frozen v0.3.1 previously passed its reference and alternative solutions at
63/63 verifier checks, negative controls, numeric boundaries and environment
isolation. The package publication README records fresh extraction, exact local
restoration, offline regression and source-preservation outcomes. Public-source
completeness and runnable hydrated-task completeness are different checks.
Official independent human acceptance and empirical frontier-model difficulty have
not been established. No extreme-difficulty claim is made.
