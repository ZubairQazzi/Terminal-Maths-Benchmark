# Task 1 — Mathematics benchmark

Exactly one implemented task: **Certified Kronecker Structure of Singular Matrix Pencils**, mathematical-sciences/applied-mathematics, version **0.1.4**. Task path: [certified-pencil-structure](tasks/mathematical-sciences/applied-mathematics/certified-pencil-structure/). It requires exact normal rank, finite Smith factors, infinite block sizes, left/right minimal indices, and independently checkable polynomial minimal bases.

Local Docker/Harbor evidence is recorded in [native validation](authoring/reports/harbor_validation.md). The suite separately identifies six non-discriminating convention controls and34 structural cases. The original36 generated inputs/expectations and oracle remain unchanged. Later QC fixes align exact rational parsing, ignored diagnostic fields, arbitrary-precision integer handling, source copying and root-symlink rejection with the existing contract. Every mathematical comparison and execution-isolation/resource rule remains intact. Each source revision has distinct validation evidence. See [per-case discrimination](authoring/reports/test_discrimination_audit.md).

**AI difficulty calibration is incomplete.** The latest retained v0.1.3 Gemini smoke attempt ended with an infrastructure interruption and zero valid graded trials. No v0.1.4 model calibration was run during QC remediation. Success rate is undefined; API failures are not mathematical failures. No 40–60% measured success rate or demonstrated extreme difficulty is claimed. Historical trajectories and source-version hashes are preserved under authoring/trajectories/.

All remediation work is local. The current request prohibits Git publication; no commit, push, registry upload or hosted submission was performed during this remediation. Public references were inspected through browser-accessible sources only.

Supporting records:

- [Current remediation and unresolved requirements](authoring/reports/qc_remediation.md)
- [All 29 static checks](authoring/reports/static_qc_audit.md) and [all 38 rubric criteria](authoring/reports/rubric_qc_audit.md)
- [Independent QC reviewer](authoring/reports/independent_qc_review.md)
- [Author evidence index](authoring/README.md), [research](authoring/math_research_review.md), [originality](authoring/originality_assessment.md)
- [Reproduction commands](REPRODUCING.md)

The full comparison against the external pipeline's pinned main/lite instruction corpus is **NOT TESTED** because the runner and corpus revisions were not supplied. The historical twelve-document similarity sample predates the updated instructions and cannot settle that requirement. Independent human domain review, measured expert time and empirical difficulty remain unverified.

Original external QC: **NOT RUN**. Local audit results and the separate AI reviewer do not constitute the original three-judge pipeline or human mathematical certification.

Final local QC review: both prior findings and a subsequently reproduced rational-parser defect are corrected and independently rechecked. All14 final-hash native validations have expected outcomes. Local criteria:28/29 static PASS,36/38 rubric PASS (one N/A, one novelty warning). Overall **NEEDS FURTHER WORK** because required full-corpus similarity/external QC and eight-trial difficulty calibration remain unresolved. See [final status](authoring/reports/final_delivery_status.json).
