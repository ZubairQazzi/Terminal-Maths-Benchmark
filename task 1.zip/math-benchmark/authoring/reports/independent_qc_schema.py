from pathlib import Path
from datetime import datetime, timezone
from importlib.metadata import version
import json, tomllib
from pydantic import BaseModel
from harbor.models.task.config import TaskConfig
from harbor.models.task.task import Task

root=Path('F:/rl/math-benchmark')
task=root/'tasks/mathematical-sciences/applied-mathematics/certified-pencil-structure'
data=tomllib.loads((task/'task.toml').read_text())
parsed=TaskConfig.model_validate(data)
checked=[]
def check(raw,obj,path):
    assert isinstance(obj,BaseModel)
    extra=set(raw)-set(type(obj).model_fields)
    assert not extra,(path,extra)
    checked.append({'table':path,'supplied_keys':sorted(raw),'unsupported_keys':sorted(extra)})
    for k,v in raw.items():
        target=getattr(obj,k)
        if isinstance(target,BaseModel):check(v,target,path+'.'+k)
        elif isinstance(target,list):
            for i,value in enumerate(target):
                if isinstance(value,BaseModel):check(v[i],value,path+'.'+k+'['+str(i)+']')
check(data,parsed,'root')
assert parsed.agent.timeout_sec==28800
assert data['verifier']['environment_mode']=='separate'
assert data['verifier']['environment']['network_mode']=='no-network'
discovered=Task(task)
assert Task.is_valid_dir(task)
out={'recorded_utc':datetime.now(timezone.utc).isoformat(),'reviewer':'/root/independent_qc','harbor_version':version('harbor'),'native_task_checksum':discovered.checksum,'task_discovery_valid':True,'success':True,'tables_checked':checked,'metadata_note':'TaskConfig.metadata is a supported free-form dictionary; required publishing values were separately inspected against the supplied checklist and current upstream advisory sources.'}
(root/'authoring/reports/independent_qc_schema.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
