"""Independent final offline Linux recheck of all four contract-sweep findings."""
from pathlib import Path
from datetime import datetime, timezone
import tempfile, sys, json, hashlib, copy
sys.path.insert(0,'/tests')
import harness, certificates

def zero(cid):
    return {'id':cid,'A':[[0]],'B':[[0]]},{'normal_rank':0,'smith_factors':[],'infinite_sizes':[],'right_indices':[0],'left_indices':[0]}
batch=[zero(cid) for cid in ('signed-rational','huge-integer','huge-rational','extra-diagnostic')]
HELPER='''def coefficient(cid):
 if cid=='signed-rational': return '1/+2'
 if cid=='huge-integer': return 10**5000+3
 if cid=='huge-rational': return str(10**5000+3)+'/+'+str(10**5000+7)
 return 1
'''
CANDIDATE='''from pathlib import Path
import importlib.util,json,sys,os
sys.set_int_max_str_digits(0)
spec=importlib.util.spec_from_file_location('actual_support_helper',Path(__file__).parent/'__pycache__'/'helper.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
data=json.load(open(sys.argv[1])); out=[]
probe={'uid':os.getuid(),'gid':os.getgid(),'groups':os.getgroups()}
for name,path,mode in [('tests_read','/tests/cases.py','r'),('reward_write','/logs/verifier/reward.txt','w'),('source_write',__file__,'a')]:
 try:
  with open(path,mode):pass
  probe[name]='UNEXPECTED_SUCCESS'
 except PermissionError:probe[name]='DENIED'
for c in data['cases']:
 q=helper.coefficient(c['id'])
 out.append({'id':c['id'],'normal_rank':0,'smith_factors':[],'infinite_sizes':[],'right_indices':[0],'left_indices':[0],'right_basis':[[[q]]],'left_basis':[[[q]]],'elapsed_seconds':0.25,'ignored_nested':{'flag':True,'other':None},'probe':probe})
json.dump({'cases':out},open(sys.argv[2],'w'))
'''
observed=[]
original_verify=harness.verify
def capture(c,e,o):
    original_verify(c,e,o)
    scalar=o['right_basis'][0][0][0]
    observed.append({'id':c['id'],'basis_scalar_type':type(scalar).__name__,'basis_scalar_characters':len(str(scalar)),
                     'ignored_float':o['elapsed_seconds'],'probe':o['probe']})
harness.verify=capture
with tempfile.TemporaryDirectory(prefix='independent-contract-after-') as tmp:
    root=Path(tmp);program=root/'regular-submission';program.mkdir()
    (program/'__pycache__').mkdir();(program/'__pycache__/helper.py').write_text(HELPER)
    (program/'solve.py').write_text(CANDIDATE)
    run=harness.run_batch(program,batch)
    link=root/'submission-link';link.symlink_to(program,target_is_directory=True)
    try:harness.run_batch(link,batch);root_rejected=False;root_error=None
    except AssertionError as exc:root_rejected=True;root_error=str(exc)
    bad=program/'ordinary-descendant-link';bad.symlink_to(program/'__pycache__/helper.py')
    try:harness.run_batch(program,batch);descendant_rejected=False;descendant_error=None
    except AssertionError as exc:descendant_rejected=True;descendant_error=str(exc)
    bad.unlink()
harness.verify=original_verify
assert len(observed)==4 and root_rejected and descendant_rejected
assert sys.get_int_max_str_digits()==0
assert all(o['probe']['uid']==o['probe']['gid']==65534 and o['probe']['groups']==[] for o in observed)
assert all(o['probe'][k]=='DENIED' for o in observed for k in ('tests_read','reward_write','source_write'))
assert next(o for o in observed if o['id']=='huge-integer')['basis_scalar_characters']==5001
assert next(o for o in observed if o['id']=='huge-rational')['basis_scalar_characters']==10004

# Required-field floats still fail even though unscored finite floats are ignored.
c,e=zero('exactness-negative')
answer={'id':c['id'],**e,'right_basis':[[[1]]],'left_basis':[[[1]]]}
regular={'id':'regular-negative','A':[[1]],'B':[[0]]}
regular_expected={'normal_rank':1,'smith_factors':[[certificates.F(1)]],'infinite_sizes':[1],'right_indices':[],'left_indices':[]}
regular_answer={'id':regular['id'],**regular_expected,'smith_factors':[[1]],'right_basis':[],'left_basis':[]}
invalid=[]
for name,case,expected,base,key,value in [
 ('float-rank',c,e,answer,'normal_rank',0.0),('float-right-degree',c,e,answer,'right_indices',[0.0]),
 ('float-left-degree',c,e,answer,'left_indices',[0.0]),('float-right-basis',c,e,answer,'right_basis',[[[1.0]]]),
 ('float-left-basis',c,e,answer,'left_basis',[[[1.0]]]),('float-Smith-coefficient',regular,regular_expected,regular_answer,'smith_factors',[[1.0]]),
 ('float-infinity',regular,regular_expected,regular_answer,'infinite_sizes',[1.0]),('boolean-rank',c,e,answer,'normal_rank',False),
 ('boolean-basis',c,e,answer,'right_basis',[[[True]]]),('boolean-degree',c,e,answer,'right_indices',[False])]:
    candidate=copy.deepcopy(base);candidate[key]=value
    try:certificates.verify(case,expected,candidate);rejected=False
    except Exception:rejected=True
    assert rejected,name
    invalid.append({'case':name,'rejected':True})
constants=[]
for token in ('NaN','Infinity','-Infinity'):
    try:json.loads('{"cases":[],"extra":'+token+'}',parse_constant=harness.reject_float);rejected=False
    except Exception:rejected=True
    assert rejected
    constants.append({'token':token,'rejected':True})
report={'reviewer':'/root/independent_qc','recorded_utc':datetime.now(timezone.utc).isoformat(),'success':True,
 'actual_image_source_sha256':{n:hashlib.sha256(Path('/tests',n).read_bytes()).hexdigest() for n in ('harness.py','certificates.py')},
 'findings':{
   'IQC-013':{'local_recheck':'PASS','ignored_finite_diagnostic_float_accepted':True,'scored_inexact_fields_still_rejected':invalid,'invalid_JSON_constants_still_rejected':constants},
   'IQC-014':{'local_recheck':'PASS','verifier_decimal_digit_cap':sys.get_int_max_str_digits(),'string_and_JSON_integer_5001_digit_valid_bases_accepted':True},
   'IQC-015':{'local_recheck':'PASS','root_symlink_rejected':root_rejected,'root_error':root_error,'descendant_symlink_rejected':descendant_rejected,'descendant_error':descendant_error},
   'IQC-016':{'local_recheck':'PASS','ordinary_supporting_source_path':'__pycache__/helper.py','full_valid_submission_accepted':True}},
 'full_harness_positive_run':run,'observations':observed,'closure_note':'Full current-source native pre/post regression still required for final report closure.'}
print(json.dumps(report,indent=2))
