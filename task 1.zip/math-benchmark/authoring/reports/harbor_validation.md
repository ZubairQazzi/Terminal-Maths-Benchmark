# Measured local Harbor validation — v0.1.4

Task framing SHA-256: `d707fcadcc382bfe39bceb0a4a9ce6e8a9f87200517d4d3bbf8fe08adcd2b87f`. Native Harbor checksum: `85773b829a06b44bbb3a707087d606f100504a58d9432caf4ef5dadfd5b50cb2`. These are distinct hash schemes. All listed trials have ten distinct CTRF tests, separate offline verifier mode, matching task checksum, no exceptions and expected literal binary reward.

| Job | Trial | Reward | Tests passed | Exceptions |
|---|---|---:|---:|---:|
| qc-v014-r3-post-review-hardcoded | certified-pencil-structure__RyCaVVE | 0.0 | 0/10 | 0 |
| qc-v014-r3-post-review-nop | certified-pencil-structure__WWRGQY8 | 0.0 | 0/10 | 0 |
| qc-v014-r3-post-review-oracle | certified-pencil-structure__9mWWVz2 | 1.0 | 10/10 | 0 |
| qc-v014-r3-post-review-oracle | certified-pencil-structure__WUSLiSV | 1.0 | 10/10 | 0 |
| qc-v014-r3-post-review-partial | certified-pencil-structure__JPruUF8 | 0.0 | 1/10 | 0 |
| qc-v014-r3-post-review-rational | certified-pencil-structure__nEBhn75 | 1.0 | 10/10 | 0 |
| qc-v014-r3-post-review-trivial | certified-pencil-structure__dsL7kvH | 0.0 | 1/10 | 0 |
| qc-v014-r3-pre-review-hardcoded | certified-pencil-structure__oboJhUF | 0.0 | 0/10 | 0 |
| qc-v014-r3-pre-review-helper | certified-pencil-structure__8NkV67i | 1.0 | 10/10 | 0 |
| qc-v014-r3-pre-review-nop | certified-pencil-structure__ss5AkFZ | 0.0 | 0/10 | 0 |
| qc-v014-r3-pre-review-oracle | certified-pencil-structure__NLrb86e | 1.0 | 10/10 | 0 |
| qc-v014-r3-pre-review-oracle | certified-pencil-structure__us4VePd | 1.0 | 10/10 | 0 |
| qc-v014-r3-pre-review-partial | certified-pencil-structure__hBAXq3t | 0.0 | 1/10 | 0 |
| qc-v014-r3-pre-review-trivial | certified-pencil-structure__6k7npLE | 0.0 | 1/10 | 0 |

Each oracle trial checks all 40 pencils. No-op submits nothing. Trivial recovers only zero/scalar conventions; the public-example hardcoder knows no hidden instances; finite-only partial omits infinity and minimal bases. Their reward zero is the expected correct rejection, not a broken infrastructure failure. The helper oracle exercises a valid executable supporting source layout and earns full credit. These are deterministic author controls, not independent AI attempts.

Portable regression: 23 checks PASS in 30.641s; independent matrix/discrimination audit PASS in 41.125s. Portable flags remain honestly separate from Linux validation. Per-case results: test_discrimination_audit.md / discrimination_v014.json.

## Clean builds, isolation and provenance

Initial agent and verifier builds used --no-cache --pull against the pinned base digest and actually executed dependency installs; successful logs remain in history/qc-v014-r1. Dockerfiles, base and pins are unchanged by later contract corrections. A redundant r2 no-cache attempt encountered Network is unreachable during pip; this is a build-infrastructure interruption, not a mathematical failure. An r2 network-none source build also failed because that flag invalidates the dependency RUN cache key. Final source builds with the default cache key succeeded using the same installed dependency layers and rebuilt the verifier COPY containing the corrected checker/harness. Current successful logs: cached-*-build-r3.*; failed intermediate attempt: source-agent-build-r2.* and r2-build-console.log. Native final-hash trials validate the actual images. No host installation occurred. No successful final-revision no-cache dependency reinstall is claimed.

The real harness probe returns UID/GID 65534, no supplementary groups, denied hidden-test reads, denied reward and copied-source writes, no oracle file, and no API key variables. CPU/address-space/descriptor limits match the spec. Agent-image enumeration contains only /app/spec.md and /app/data/examples.json as application files. Probes use --network none; the task verifier declares no-network. This is measured protection of private files and score paths; it is not a claim that a shared-UID child subprocess design provides a separate per-batch kernel sandbox.

All original36 generated inputs and expectations are preserved exactly. The reference solver, shell tests, package pins and Dockerfiles are byte-identical to v0.1.3. The hidden-suite change appends four justified structural cases and identifies controls. Later independent contract audits corrected three parsing defects: positive +q denominators normalize via integer components; finite floats in ignored extra result fields parse normally while scientific fields retain exact type/value checks; the implicit4300-digit conversion cap is disabled for contract-valid arbitrary-precision output integers/rationals, within the existing16MiB output cap. Isolation/resource limits and every mathematical identity/invariant comparison are unchanged. Before/after full-submission reproductions and malformed/exact-type rejections are retained in rational_spelling_*.json and json_contract_*.json. Source snapshots of original and intermediate r1/r2 revisions are preserved.

Harbor logs include nonfatal image-OS-inspection warnings; builds, all expected grading outcomes, recorded separate mode and completed trial results establish actual execution. No such warning is counted as a valid AI failure.

## Reproduction and raw evidence

From F:/rl/math-benchmark:

```powershell
& .\authoring\evidence\run_qc_validation.ps1 -Phase build
& .\authoring\evidence\run_qc_validation.ps1 -Phase pre-review
& .\authoring\evidence\run_qc_validation.ps1 -Phase post-review
```

Use fresh job names on a later reproduction to preserve evidence. Exact native executable paths, all argument arrays, UTC timestamps and exit codes are saved in qc-v014/*.command.json. Raw native config/result/lock/agent/artifact/verifier logs remain under harbor-jobs/qc-v014-*. No upload/publish command was executed. qc-v014/runtime_summary.json indexes every trial and CTRF file. Earlier v0.1.3 evidence remains in history/harbor_validation_v013.md and its original job directories.

AI calibration remains incomplete: the latest retained Gemini smoke summary has zero valid graded trials, one infrastructure interruption, no meaningful success percentage. That historical v0.1.3 provider failure is not an evaluation of v0.1.4. No new model API calls were made during QC remediation. Original external QC is NOT RUN.

## Final post-review regression

Completed seven new native trials after the independent source review: two oracle repeats, four negative baselines and a valid general oracle using a regular source helper in __pycache__, p/+q spellings,5001-digit rational/JSON-integer basis coefficients and ignored finite diagnostic floats. All expected rewards/tests agree on the same final checksum; the combined valid-contract control passes10/10 in real Linux grading. Repeated portable suite: 23 checks PASS in 30.906s. Separate post-review real-harness isolation, root-symlink rejection and agent-leakage probes PASS; native all-rule lint again returns []. See *_post_review.json and qc-v014-r3-post-review-* for preserved raw results. These final runs do not add any valid model-calibration trials.
