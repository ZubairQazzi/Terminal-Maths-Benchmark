"""Author-only general oracle with equivalent signed-denominator encoding."""
from fractions import Fraction
import json
from pathlib import Path
import subprocess
import sys

subprocess.run([sys.executable,str(Path(__file__).with_name('reference.py')),sys.argv[1],sys.argv[2]],check=True)
path=Path(sys.argv[2]);result=json.loads(path.read_text())
def encode(value):
    f=Fraction(value)
    return str(f.numerator)+'/+'+str(f.denominator)
for case in result['cases']:
    case['smith_factors']=[[encode(v) for v in p] for p in case['smith_factors']]
    for side in ('right_basis','left_basis'):
        case[side]=[[[encode(v) for v in vector] for vector in cert] for cert in case[side]]
path.write_text(json.dumps(result))
