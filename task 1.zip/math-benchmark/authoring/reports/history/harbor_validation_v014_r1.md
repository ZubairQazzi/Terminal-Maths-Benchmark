# Measured local Harbor validation — v0.1.4

Task framing SHA-256: `8e8d439f790b2efe3745e2d3856d3259d6b94ac47bde3012e2c3583d447c550c`. Native Harbor checksum: `8f3c4f225a250885cc0285769bb7a93b4c32a47e5f1e879d4ccb69c2ff2af864`. These are distinct hash schemes. All listed trials have ten distinct CTRF tests, separate offline verifier mode, matching task checksum, no exceptions and expected literal binary reward.

| Job | Trial | Reward | Tests passed | Exceptions |
|---|---|---:|---:|---:|
| qc-v014-pre-review-hardcoded | certified-pencil-structure__Yck94Nj | 0.0 | 0/10 | 0 |
| qc-v014-pre-review-helper | certified-pencil-structure__FYjujpt | 1.0 | 10/10 | 0 |
| qc-v014-pre-review-nop | certified-pencil-structure__kisfaVT | 0.0 | 0/10 | 0 |
| qc-v014-pre-review-oracle | certified-pencil-structure__2Ag6DyZ | 1.0 | 10/10 | 0 |
| qc-v014-pre-review-oracle | certified-pencil-structure__sLRTmiz | 1.0 | 10/10 | 0 |
| qc-v014-pre-review-partial | certified-pencil-structure__obyXxaN | 0.0 | 1/10 | 0 |
| qc-v014-pre-review-trivial | certified-pencil-structure__jpK2x6E | 0.0 | 1/10 | 0 |

Each oracle trial checks all 40 pencils. No-op submits nothing. Trivial recovers only zero/scalar conventions; the public-example hardcoder knows no hidden instances; finite-only partial omits infinity and minimal bases. Their reward zero is the expected correct rejection, not a broken infrastructure failure. The helper oracle exercises a valid executable supporting source layout and earns full credit. These are deterministic author controls, not independent AI attempts.

Portable regression: 23 checks PASS in 42.781s; independent matrix/discrimination audit PASS in 57.094s. Portable flags remain honestly separate from Linux validation. Per-case results: test_discrimination_audit.md / discrimination_v014.json.

## Clean builds, isolation and provenance

Both agent and verifier images were built with --no-cache --pull against the pinned base-image digest. Dependency-install layers actually executed; the base digest itself may already have existed locally. Raw build logs and exact argument arrays are in qc-v014/clean-*-build.*. No host package installation occurred. Harbor subsequently built/reused equivalent task images from these same Dockerfile contexts.

The real harness probe returns UID/GID 65534, no supplementary groups, denied hidden-test reads, denied reward and copied-source writes, no oracle file, and no API key variables. CPU/address-space/descriptor limits match the spec. Agent-image enumeration contains only /app/spec.md and /app/data/examples.json as application files. Probes use --network none; the task verifier declares no-network. This is measured protection of private files and score paths; it is not a claim that a shared-UID child subprocess design provides a separate per-batch kernel sandbox.

All original 36 generated inputs and expectations are preserved exactly. The reference solver, certificate checker, harness, shell tests, package pins and Dockerfiles are byte-identical to v0.1.3. The only hidden-suite change appends four justified structural cases and identifies controls in comments. Source snapshots and hashes are under authoring/provenance/qc_v013_*.json.

Harbor logs include nonfatal image-OS-inspection warnings; builds, all expected grading outcomes, recorded separate mode and completed trial results establish actual execution. No such warning is counted as a valid AI failure.

## Reproduction and raw evidence

From F:/rl/math-benchmark:

```powershell
& .\authoring\evidence\run_qc_validation.ps1 -Phase build
& .\authoring\evidence\run_qc_validation.ps1 -Phase pre-review
& .\authoring\evidence\run_qc_validation.ps1 -Phase post-review
```

Use fresh job names on a later reproduction to preserve evidence. Exact native executable paths, all argument arrays, UTC timestamps and exit codes are saved in qc-v014/*.command.json. Raw native config/result/lock/agent/artifact/verifier logs remain under harbor-jobs/qc-v014-*. No upload/publish command was executed. qc-v014/runtime_summary.json indexes every trial and CTRF file. Earlier v0.1.3 evidence remains in history/harbor_validation_v013.md and its original job directories.

AI calibration remains incomplete: the latest retained Gemini smoke summary has zero valid graded trials, one infrastructure interruption, no meaningful success percentage. That historical v0.1.3 provider failure is not an evaluation of v0.1.4. No new model API calls were made during QC remediation. Original external QC is NOT RUN.
