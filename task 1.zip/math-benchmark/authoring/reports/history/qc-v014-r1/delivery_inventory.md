# Local remediation file inventory

Runtime task: 5 files changed, 13 byte-identical to v0.1.3. No Git commit/push. Unrelated concurrent workspace files are excluded and left untouched.

| Changed task file | Before SHA-256 | After SHA-256 |
|---|---|---|
| environment/spec.md | ea0035cf89be85703cc44465fc955c89948389e182791ad216d2d612c6077933 | 3ef6f9d3def47c79a42477530842560df4d80493bf6e5c4331aaa7ae3ccdfcbe |
| instruction.md | c6c7ac501e945634a67958942860fe744a75f725e08b34160baecefeb09744e3 | a4d8d88b24bc8460316d612ade1939c6b2ed8d3105b7f9383436d2273ba75809 |
| README.md | 807dacd817423d55ba843a6f0bc6530165a048928a1d63ed7414b1ff621d9667 | 5e8893b82d3cf020f9ca30fedf27072a5d576135e66af6eb3bfd0e9a4620f929 |
| task.toml | 3b0f9630b85937cbdd1012dc164d6c915b5e8d2b7ba4943c2ba7c273c5da5359 | fa12c086b4e84117d5532f67f45d58bb4218e71079f3b1f99d080639f315e452 |
| tests/cases.py | 421c6bf52ca68dbea2852efec5cc3fea5c0d963b73e8885b3b163c21946ee98c | 7c3beea729534d5af30288441e7a04aca5cb1c5bd4aa9988f2c4ef1cd90bd7a3 |

## Supporting files and evidence

This machine inventory lists all scoped modified/new files, including raw per-trial evidence; the JSON is authoritative for the complete path list. It is captured from read-only git status, not a commit.

- ` M` `README.md`
- ` M` `REPRODUCING.md`
- ` M` `authoring/evidence/baseline_agent.py`
- ` M` `authoring/math_research_review.md`
- ` M` `authoring/originality_assessment.md`
- ` M` `authoring/reports/harbor_validation.md`
- ` M` `authoring/task_file_manifest.json`
- ` M` `tasks/mathematical-sciences/applied-mathematics/certified-pencil-structure/README.md`
- ` M` `tasks/mathematical-sciences/applied-mathematics/certified-pencil-structure/environment/spec.md`
- ` M` `tasks/mathematical-sciences/applied-mathematics/certified-pencil-structure/instruction.md`
- ` M` `tasks/mathematical-sciences/applied-mathematics/certified-pencil-structure/task.toml`
- ` M` `tasks/mathematical-sciences/applied-mathematics/certified-pencil-structure/tests/cases.py`
- `??` `authoring/README.md`
- `??` `authoring/evidence/audit_discrimination.py`
- `??` `authoring/evidence/baselines/hardcoded/solve.py`
- `??` `authoring/evidence/baselines/trivial/solve.py`
- `??` `authoring/evidence/probe_qc_isolation.py`
- `??` `authoring/evidence/qc_build_reports.py`
- `??` `authoring/evidence/qc_delivery_inventory.py`
- `??` `authoring/evidence/qc_remediate.py`
- `??` `authoring/evidence/qc_static_audit.py`
- `??` `authoring/evidence/run_qc_probes.py`
- `??` `authoring/evidence/run_qc_validation.ps1`
- `??` `authoring/evidence/update_qc_delivery_docs.py`
- `??` `authoring/provenance/qc_v013_generated_cases.json`
- `??` `authoring/provenance/qc_v013_snapshot.json`
- `??` `authoring/reports/agent_leakage_probe_v014.json`
- `??` `authoring/reports/discrimination_v014.json`
- `??` `authoring/reports/history/REPRODUCING_v013.md`
- `??` `authoring/reports/history/harbor_validation_v013.md`
- `??` `authoring/reports/independent_qc_evidence.py`
- `??` `authoring/reports/independent_qc_initial.json`
- `??` `authoring/reports/isolation_probe_v014.json`
- `??` `authoring/reports/local_validation_v014.json`
- `??` `authoring/reports/pre_remediation_audit.md`
- `??` `authoring/reports/qc-v014/agent_leakage_probe_v014.command.json`
- `??` `authoring/reports/qc-v014/agent_leakage_probe_v014.log`
- `??` `authoring/reports/qc-v014/clean-agent-build.command.json`
- `??` `authoring/reports/qc-v014/clean-agent-build.log`
- `??` `authoring/reports/qc-v014/clean-verifier-build.command.json`
- `??` `authoring/reports/qc-v014/clean-verifier-build.log`
- `??` `authoring/reports/qc-v014/discrimination-console.log`
- `??` `authoring/reports/qc-v014/isolation_probe_v014.command.json`
- `??` `authoring/reports/qc-v014/isolation_probe_v014.log`
- `??` `authoring/reports/qc-v014/local-validation-console.log`
- `??` `authoring/reports/qc-v014/native-pre-review-console.log`
- `??` `authoring/reports/qc-v014/pre-review-lint.command.json`
- `??` `authoring/reports/qc-v014/pre-review-lint.log`
- `??` `authoring/reports/qc-v014/qc-v014-pre-review-hardcoded.command.json`
- `??` `authoring/reports/qc-v014/qc-v014-pre-review-hardcoded.log`
- `??` `authoring/reports/qc-v014/qc-v014-pre-review-helper.command.json`
- `??` `authoring/reports/qc-v014/qc-v014-pre-review-helper.log`
- `??` `authoring/reports/qc-v014/qc-v014-pre-review-nop.command.json`
- `??` `authoring/reports/qc-v014/qc-v014-pre-review-nop.log`
- `??` `authoring/reports/qc-v014/qc-v014-pre-review-oracle.command.json`
- `??` `authoring/reports/qc-v014/qc-v014-pre-review-oracle.log`
- `??` `authoring/reports/qc-v014/qc-v014-pre-review-partial.command.json`
- `??` `authoring/reports/qc-v014/qc-v014-pre-review-partial.log`
- `??` `authoring/reports/qc-v014/qc-v014-pre-review-trivial.command.json`
- `??` `authoring/reports/qc-v014/qc-v014-pre-review-trivial.log`
- `??` `authoring/reports/qc-v014/runtime_summary.json`
- `??` `authoring/reports/qc_remediation.md`
- `??` `authoring/reports/qc_remediation_inputs/QC-CHECKLIST.md`
- `??` `authoring/reports/qc_remediation_inputs/hashes.json`
- `??` `authoring/reports/qc_remediation_inputs/message.txt`
- `??` `authoring/reports/qc_remediation_inputs/remediation_request.txt`
- `??` `authoring/reports/qc_requirements.json`
- `??` `authoring/reports/reconciled_qc_requirements.md`
- `??` `authoring/reports/rubric_qc_audit.json`
- `??` `authoring/reports/rubric_qc_audit.md`
- `??` `authoring/reports/static_qc_audit.json`
- `??` `authoring/reports/static_qc_audit.md`
- `??` `authoring/reports/test_discrimination_audit.md`

Secret-format pattern scan: 0 hit(s) across 186 scoped text files. No matched contents are emitted. This bounded scan does not read credential stores or prove absence of every possible secret.
