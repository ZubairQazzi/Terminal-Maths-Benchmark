# Measured local Harbor validation — v0.1.4

Task framing SHA-256: `1e24a04800f7eb852687191d4b49562fe8d4ff3a5c0a74a554c6b0500278c4c0`. Native Harbor checksum: `998a638169b79150cda6bb43e9d8c8a7dd96a3d73c506b5a3adbe827494be695`. These are distinct hash schemes. All listed trials have ten distinct CTRF tests, separate offline verifier mode, matching task checksum, no exceptions and expected literal binary reward.

| Job | Trial | Reward | Tests passed | Exceptions |
|---|---|---:|---:|---:|
| qc-v014-r2-post-review-hardcoded | certified-pencil-structure__gDKH5Tg | 0.0 | 0/10 | 0 |
| qc-v014-r2-post-review-nop | certified-pencil-structure__Lhu59A5 | 0.0 | 0/10 | 0 |
| qc-v014-r2-post-review-oracle | certified-pencil-structure__DBWn3oS | 1.0 | 10/10 | 0 |
| qc-v014-r2-post-review-oracle | certified-pencil-structure__YhwNdX7 | 1.0 | 10/10 | 0 |
| qc-v014-r2-post-review-partial | certified-pencil-structure__FmfCExJ | 0.0 | 1/10 | 0 |
| qc-v014-r2-post-review-rational | certified-pencil-structure__5TL9yUL | 1.0 | 10/10 | 0 |
| qc-v014-r2-post-review-trivial | certified-pencil-structure__arxUc64 | 0.0 | 1/10 | 0 |
| qc-v014-r2-pre-review-hardcoded | certified-pencil-structure__8Cisqa2 | 0.0 | 0/10 | 0 |
| qc-v014-r2-pre-review-helper | certified-pencil-structure__TX6Vi4F | 1.0 | 10/10 | 0 |
| qc-v014-r2-pre-review-nop | certified-pencil-structure__Sf4swFN | 0.0 | 0/10 | 0 |
| qc-v014-r2-pre-review-oracle | certified-pencil-structure__ocB8hEV | 1.0 | 10/10 | 0 |
| qc-v014-r2-pre-review-oracle | certified-pencil-structure__YGvmVxi | 1.0 | 10/10 | 0 |
| qc-v014-r2-pre-review-partial | certified-pencil-structure__TyZCQfK | 0.0 | 1/10 | 0 |
| qc-v014-r2-pre-review-trivial | certified-pencil-structure__owTvxK5 | 0.0 | 1/10 | 0 |

Each oracle trial checks all 40 pencils. No-op submits nothing. Trivial recovers only zero/scalar conventions; the public-example hardcoder knows no hidden instances; finite-only partial omits infinity and minimal bases. Their reward zero is the expected correct rejection, not a broken infrastructure failure. The helper oracle exercises a valid executable supporting source layout and earns full credit. These are deterministic author controls, not independent AI attempts.

Portable regression: 23 checks PASS in 24.344s; independent matrix/discrimination audit PASS in 37.563s. Portable flags remain honestly separate from Linux validation. Per-case results: test_discrimination_audit.md / discrimination_v014.json.

## Clean builds, isolation and provenance

Initial agent and verifier builds used --no-cache --pull against the pinned base digest and actually executed dependency installs; these successful logs are preserved in history/qc-v014-r1. Dockerfiles, base digest and dependency pins are unchanged by the later scalar-parser correction. A redundant final no-cache attempt encountered Network is unreachable during pip; this is a build-infrastructure interruption, not a mathematical failure. A network-none source build also failed because that option invalidates the dependency RUN cache key; its failed log is retained. Final source builds with the original default cache key succeeded using the same installed pinned dependency layers and rebuilt the verifier COPY containing the corrected checker. See cached-*-build-r2.* and source-*-build-r2.*. Native final-hash trials validate the actual current images. No host installation occurred. Do not claim a successful final-revision no-cache dependency reinstall.

The real harness probe returns UID/GID 65534, no supplementary groups, denied hidden-test reads, denied reward and copied-source writes, no oracle file, and no API key variables. CPU/address-space/descriptor limits match the spec. Agent-image enumeration contains only /app/spec.md and /app/data/examples.json as application files. Probes use --network none; the task verifier declares no-network. This is measured protection of private files and score paths; it is not a claim that a shared-UID child subprocess design provides a separate per-batch kernel sandbox.

All original 36 generated inputs and expectations are preserved exactly. The reference solver, harness, shell tests, package pins and Dockerfiles are byte-identical to v0.1.3. The hidden-suite change appends four justified structural cases and identifies controls in comments. A later independent QC edge-case audit corrected scalar parsing: positive denominators written with a plus sign now normalize via integer components instead of Fraction(string). This accepts the existing documented rational grammar; all mathematical checks and expected values remain unchanged. Before/after full-certificate reproductions, forty equivalent-output checks and twelve malformed-scalar rejections are retained in rational_spelling_before.json and rational_spelling_after.json. Original source snapshots and the intermediate r1 snapshot are preserved under authoring/provenance/.

Harbor logs include nonfatal image-OS-inspection warnings; builds, all expected grading outcomes, recorded separate mode and completed trial results establish actual execution. No such warning is counted as a valid AI failure.

## Reproduction and raw evidence

From F:/rl/math-benchmark:

```powershell
& .\authoring\evidence\run_qc_validation.ps1 -Phase build
& .\authoring\evidence\run_qc_validation.ps1 -Phase pre-review
& .\authoring\evidence\run_qc_validation.ps1 -Phase post-review
```

Use fresh job names on a later reproduction to preserve evidence. Exact native executable paths, all argument arrays, UTC timestamps and exit codes are saved in qc-v014/*.command.json. Raw native config/result/lock/agent/artifact/verifier logs remain under harbor-jobs/qc-v014-*. No upload/publish command was executed. qc-v014/runtime_summary.json indexes every trial and CTRF file. Earlier v0.1.3 evidence remains in history/harbor_validation_v013.md and its original job directories.

AI calibration remains incomplete: the latest retained Gemini smoke summary has zero valid graded trials, one infrastructure interruption, no meaningful success percentage. That historical v0.1.3 provider failure is not an evaluation of v0.1.4. No new model API calls were made during QC remediation. Original external QC is NOT RUN.

## Final post-review regression

Completed seven new native trials after the independent source review: two oracle repeats, four negative baselines and a valid general oracle using p/+q scalar encodings throughout. All expected rewards/tests agree on the same final checksum; the rational encoding control passes10/10 and directly verifies the parser fix in Linux grading. Repeated portable suite: 23 checks PASS in 29.109s. Separate post-review real-harness isolation and agent-leakage probes PASS; native all-rule lint again returns []. See *_post_review.json and qc-v014-r2-post-review-* for preserved raw results. These final runs do not add any valid model-calibration trials.
