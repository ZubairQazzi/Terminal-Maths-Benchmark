from pathlib import Path
from datetime import datetime, timezone
import ast, json, hashlib
ROOT=Path('F:/rl/math-benchmark');TASK=ROOT/'tasks/mathematical-sciences/applied-mathematics/certified-pencil-structure';OUT=ROOT/'authoring/reports'
initial=json.loads((OUT/'independent_qc_initial.json').read_text(encoding='utf-8'))
old=json.loads((ROOT/'authoring/provenance/qc_v013_snapshot.json').read_text(encoding='utf-8'))
files=sorted(p for p in TASK.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
sha=lambda data:hashlib.sha256(data).hexdigest()
hashes={p.relative_to(TASK).as_posix():sha(p.read_bytes()) for p in files}
framed=hashlib.sha256()
for p in files:framed.update(p.relative_to(TASK).as_posix().encode()+b'\0'+p.read_bytes()+b'\0')
changed=[n for n,h in hashes.items() if h!=initial['file_sha256'][n]]
assert changed==['tests/certificates.py','tests/harness.py']
def funcs(source):
    return {x.name:ast.dump(x,include_attributes=False) for x in ast.parse(source).body if isinstance(x,ast.FunctionDef)}
unchanged_science=[]
f='tests/certificates.py';before=funcs(old['files'][f]['text']);after=funcs((TASK/f).read_text(encoding='utf-8'))
for name in ('poly','rank','integers','basis','verify'):
    assert before[name]==after[name],name
    unchanged_science.append(name)
hf='tests/harness.py';hb=funcs(old['files'][hf]['text']);ha=funcs((TASK/hf).read_text(encoding='utf-8'))
assert hb['_limits']==ha['_limits']
for name in ('solution/solve.py','solution/solve.sh','tests/test.sh','tests/test_outputs.py','environment/Dockerfile','tests/Dockerfile','environment/requirements.txt','tests/requirements.txt'):
    assert hashes[name]==old['files'][name]['sha256'],name
image=json.loads((OUT/'independent_qc_contract_sweep_after.json').read_text(encoding='utf-8'))
assert image['success']
assert hashes['tests/harness.py']==image['actual_image_source_sha256']['harness.py']
assert hashes['tests/certificates.py']==image['actual_image_source_sha256']['certificates.py']
assert framed.hexdigest()=='d707fcadcc382bfe39bceb0a4a9ce6e8a9f87200517d4d3bbf8fe08adcd2b87f'
report={'reviewer':'/root/independent_qc','recorded_utc':datetime.now(timezone.utc).isoformat(),'success':True,'task_framed_sha256':framed.hexdigest(),'file_sha256':hashes,'changed_from_initial_independent_review':changed,'unchanged_scientific_checker_function_AST':unchanged_science,'resource_limit_function_AST_unchanged':True,'reference_acceptance_shell_build_requirements_unchanged_from_v013':True,'rebuilt_image_hashes_match_current_host_sources':True,'explanation':'Only valid-scalar parsing and implicit digit-limit initialization changed in checker. Harness changes align ignored extras, reject source-root symlinks and preserve all validated submission files. Mathematical value/identity/minimality/rank/type assertions and resource limits are unchanged.'}
(OUT/'independent_qc_source_recheck.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
