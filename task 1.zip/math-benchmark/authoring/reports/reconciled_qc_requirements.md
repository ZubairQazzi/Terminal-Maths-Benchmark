# Reconciled QC requirements

Governing supplied checklist: **29 static + 38 rubric = 67 criteria**. Its SHA-256 is `66d8a65d56748ffb491339e851d827612e70d2138ceaa6f989962414a7225ffb`. The new remediation request governs this work; the external report provides findings, not new permissions. Earlier publication authorization is superseded: all work remains local.

The Standard profile is the available baseline. No external executable, pinned main/lite corpus revisions, active Local profile, custom publisher/canary, or local caps were supplied; the user confirmed that only the supplied files are available. Do not invent them. Native Harbor 0.27.0 lint covers 18 rules and is supplementary, not a substitute for all 29 checks. Original external QC is NOT RUN.

Use PASS, FAIL, WARNING, NOT TESTED, or justified NOT APPLICABLE. Manual checklist-based findings are local findings, not the original three-judge vote. Historical 40-item reviews do not satisfy the current 38-item denominator. No API interruption counts as a valid agent failure. A fresh distinct QC sub-agent is mandatory after implementation and local validation.

Evidence hierarchy: current measured runs and raw source; independent reviewer findings; creator explanation; historical version-specific records. Unmeasured difficulty and limited similarity sampling must remain qualified.

## Static requirements

| ID | Supplied requirement |
|---|---|
| `entry-files` | Check for `instruction.md`, `task.toml`, `environment/Dockerfile`, `solution/solve.sh`, and `tests/test.sh`. |
| `config-fields` | Parse the manifest and check its field names and table structure against the supported configuration. |
| `task-fields` | Check the publisher, task name, description, authors, keywords, and required metadata. |
| `task-path` | Check that the task’s directory agrees with the domain and field in its manifest. |
| `task-structure` | Check that instructions and configuration are at the root and that environment, solution, grading, and authoring files are in their expected locations. |
| `task-slug` | Check the folder name against the allowed format and length. |
| `task-readme` | If a README is included, check its expected sections and whether its managed header matches the manifest. |
| `canary` | Check that eligible source files carry the marker required by the active profile. |
| `task-absolute-path` | Flag relative locations where the solver needs an absolute path to an input or deliverable. |
| `instruction-suffix` | Check the standard closing paragraph and compare its stated time allowance with `agent.timeout_sec`. |
| `instruction-similarity` | Compare instruction text against the pinned main and lite task collections and flag close matches. |
| `test-file-references` | Look for submission paths shared by the tests and reference solution that are missing from the instructions or manifest. |
| `dockerfile-references` | Check that local sources referenced by supported `COPY` and `ADD` instructions exist in the build context. |
| `dockerfile-sanity` | Flag prohibited Dockerfile patterns that can make the image invalid or break packaging rules. |
| `dockerfile-platform` | Flag `FROM --platform` settings that hardcode a processor architecture. |
| `allow-internet` | Check the solver and verifier network declarations against the active rules. |
| `separate-verifier` | Check the verifier environment declaration and how the expected artifacts are handed over. |
| `compose-host-binds` | Flag prohibited host-directory mounts in Docker Compose volumes. |
| `task-timeout` | Check the configured timeouts against the standard rules and any additional local grader or build limit. |
| `gpu-types` | Check GPU requests against the supported hardware types. |
| `task-resources` | Check CPU, memory, storage, and GPU declarations against the package rules and any local caps. |
| `verifier-resources` | Check that a separate verifier declares the resources it needs and flag suspicious differences from the solver’s allocation. |
| `nproc` | Flag bare `nproc` calls that may count host processors and create too many workers. |
| `verifier-tooling-baked` | Check for dependencies that the verifier tries to install during grading. |
| `trial-network-fetch` | Flag prohibited live network fetches in the inspected trial scripts. |
| `pip-pinning` | Check that Python dependencies are pinned where repeatable installs require it. |
| `pytest-version` | When the task pins either test tool, check against the required versions `pytest==8.4.1` and `pytest-json-ctrf==0.3.5`. |
| `test-sh-sanity` | Check `tests/test.sh` for shell patterns and setup that conflict with grading conventions. |
| `binary-reward` | Check score-writing code for patterns that can produce an invalid value in `/logs/verifier/reward.txt`. The grading contract uses `0` or `1`. |

## Rubric requirements

| ID | Supplied requirement |
|---|---|
| `well_specified` | An independent expert can identify the goal, output path, format, grading metrics, and any convention or execution limit that changes the answer. |
| `test_instruction_alignment` | Each scored requirement appears in the instructions, and the grader checks each promised requirement. |
| `instruction_clarity` | The instructions make the task easy to understand, give the necessary context, and state what the submission must achieve without giving away the method. |
| `structured_data_schema` | For structured submissions, the specified fields, types, and layout agree with what the grader reads. |
| `typos` | Names, paths, commands, and symbols point to the intended files or concepts. |
| `hint_discoverability` | When a hint exists, its information can be traced to solver-visible evidence or established domain knowledge. |
| `scientifically_grounded` | The work reflects a real research workflow and produces a result useful for a scientific question or decision. |
| `scope` | The problem and deliverable fit the assigned domain and field. |
| `essential_difficulty` | The challenge comes from the science or reasoning the solver must do. Formatting, repetition, and precision demands have a scientific purpose when required. |
| `novel` | The instance requires new reasoning or computation. The judge can use similarity findings to assess whether an earlier answer can be copied. |
| `agentic` | Reaching a correct answer requires work such as exploring data, testing a hypothesis, or running a computation. |
| `verifiable` | The grader can observe the required outcome and distinguish correct work from meaningful errors. |
| `solvable` | A correct approach can finish and pass using the data, tools, and resources available to the solver. |
| `outcome_verified` | A scientifically valid alternative can earn full credit by meeting the same result requirements. |
| `functional_verification` | The grader checks the actual behavior or scientific output and catches answers that only look correct. |
| `ground_truth_provenance` | The expected values or scoring objective can be traced to their source, such as a generator, published data, or an independent calculation. |
| `graded_instances_discriminate` | Check per-case results from plausible trivial guesses when available, and account for any intentionally easy cases described in the documentation. |
| `solution_quality` | The reference derives its answer from the supplied inputs, and reviewers can inspect the implementation that actually produces it. |
| `do_not_modify_enforced` | When the instructions protect a file, the verifier or execution boundary enforces that requirement. |
| `deterministic_reproducible` | Builds and runs reproduce the expected data and score within the task’s stated rules for variation. |
| `separate_verifier_configured` | The verifier has the intended inputs and tools, including matching copies of any shared data required by both environments. |
| `verifier_execution_isolation` | When the verifier runs submitted code, the code cannot write the score, modify grading files, or read private answers. |
| `anti_cheat_robustness` | The grading setup and available controls show whether shortcuts can earn credit without solving the scientific problem. |
| `task_security` | Build and runtime files avoid unsafe access to credentials, the host, and unrelated networks. Sensitive operations have a clear task purpose. |
| `resource_configuration` | Time, CPU, memory, storage, and other requested resources are reasonable and give valid approaches enough room to finish. |
| `task_toml_schema` | The manifest uses supported settings and supplies the naming, publisher, and metadata required by the active profile. |
| `environment_hygiene` | The solver image contains the needed tools and data. Reference solutions, private answers, and grading materials stay outside the solver’s view. |
| `artifact_efficiency` | The verifier receives the files it needs, and collection handles failures without reusing stale outputs. |
| `ctrf_reporting` | When the grader runs discrete tests, the review evidence shows the outcome of each applicable check. |
| `task_authoring_dir` | Review-only material belongs in `authoring/`. Runtime files contain the material needed to build, solve, and grade the task. |
| `no_extraneous_files` | Every shipped file has a required purpose or is covered by an exception in the rubric. |
| `reviewable` | Another reviewer can trace the assumptions, inputs, and calculations through to an expected result. |
| `difficulty_explanation_quality` | The documentation explains the specific scientific decisions that make the task challenging and where plausible simpler approaches fall short. |
| `solution_explanation_quality` | The documentation explains the reference approach and connects it to the implemented solution. |
| `verification_explanation_quality` | The documentation describes what the grader measures and why the checks suffice. Where the rubric requires it, calibration evidence shows how alternative correct methods and flawed methods scored. |
| `category_and_tags` | The labels describe the actual science and methods clearly enough to find and group the task. |
| `task_name` | The name is descriptive and follows the active naming rules. |
| `task_readme` | When included, the README provides accurate, useful context and reflects the task as packaged. |

## Additional upstream findings

Browser inspection of the [current upstream README rules](https://github.com/harbor-framework/terminal-bench-science/blob/main/ci_checks/check-task-readme.sh) and [metadata rules](https://github.com/harbor-framework/terminal-bench-science/blob/main/ci_checks/check-task-fields.sh) found a missing managed README header, extra authored sections, and absent author email/organization/profile. These sources are current-main references, not the unavailable pinned external pipeline. No upstream source snapshot was downloaded. Contributor facts must come from the user.
