# Hidden-test discrimination audit

Measured 40 actual generated pencils in 10 mandatory batches: **6 non-discriminating controls, 34 structural cases**.

Zero controls are case-000 (2×3), case-030 (1×18), case-031 (18×1). Scalar controls are case-001, case-002, case-003. These six test conventions and bounds; they are not evidence of mathematical difficulty. The first batch consists only of controls; the other nine contain structural cases. Four structural cases (032–035) are related metamorphic checks, so there are thirty other structural designs, not 34 independent families.

All original 36 inputs/ids/expected invariants match the pre-remediation snapshot exactly. New cases 036–039 add repeated positive right indices [2,2] with finite/infinite/left components; repeated positive indices on both sides; repeated left indices [2,2] in a mixed pencil; and a right index four with regular, infinite and left components. These additions cover distinct block multiplicities and degree filtration gaps. They were not selected using AI outcomes.

Exact sampled rank is conclusive: every pencil minor has degree ≤ min(m,n), so min(m,n)+1 distinct rational samples determine the maximal rank. Independent coefficient-matrix ranks at degrees 0–4 give nullities; their second differences recover minimal-index multiplicities on both sides. This audit uses rational elimination, not the reference generator-selection algorithm. Construction proves finite/infinite invariants; the general Smith-form oracle independently agrees on all cases. Full certificates pass coefficient identities and leading-rank tests.

Fresh suite generation agrees byte-for-byte. Forty alternate valid outputs pass after rational rescaling and, wherever there are two generators, nonconstant unimodular mixing (including equal-degree mixing). The checker does not require the oracle basis representation.

| Program | All cases passed | Structural cases passed | Full benchmark credit |
|---|---:|---:|---|
| oracle | 40/40 | 34/34 | Yes |
| trivial | 6/40 | 0/34 | No |
| hardcoded | 3/40 | 0/34 | No |
| partial | 6/40 | 4/34 | No |

The finite-Smith-only baseline is deliberately plausible and can solve finite-only structural cases. This is useful evidence that each semantic family is needed; do not call every structural case hard for every incomplete method. The trivial baseline recovers zero/scalar conventions only; the hardcoder knows only public examples plus a zero guess. None receives the hidden expectations. Full native Harbor rewards are reported separately.

## Per-case measured results

| Case | Shape | Category | Rank | Right / left degrees | Trivial | Hardcoded | Partial | Oracle |
|---|---|---|---:|---|---|---|---|---|
| case-000 | 2×3 | non-discriminating-zero-control | 0 | [0, 0, 0] / [0, 0] | PASS | PASS | FAIL | PASS |
| case-001 | 1×1 | non-discriminating-scalar-control | 1 | [] / [] | PASS | FAIL | PASS | PASS |
| case-002 | 1×1 | non-discriminating-scalar-control | 1 | [] / [] | PASS | FAIL | FAIL | PASS |
| case-003 | 1×1 | non-discriminating-scalar-control | 1 | [] / [] | PASS | FAIL | PASS | PASS |
| case-004 | 1×2 | structural-discrimination | 1 | [1] / [] | FAIL | FAIL | FAIL | PASS |
| case-005 | 2×1 | structural-discrimination | 1 | [] / [1] | FAIL | FAIL | FAIL | PASS |
| case-006 | 5×5 | structural-discrimination | 4 | [4] / [0] | FAIL | FAIL | FAIL | PASS |
| case-007 | 5×5 | structural-discrimination | 4 | [0] / [4] | FAIL | FAIL | FAIL | PASS |
| case-008 | 2×2 | structural-discrimination | 2 | [] / [] | FAIL | FAIL | PASS | PASS |
| case-009 | 2×2 | structural-discrimination | 2 | [] / [] | FAIL | FAIL | PASS | PASS |
| case-010 | 4×4 | structural-discrimination | 4 | [] / [] | FAIL | FAIL | PASS | PASS |
| case-011 | 4×4 | structural-discrimination | 4 | [] / [] | FAIL | FAIL | PASS | PASS |
| case-012 | 4×4 | structural-discrimination | 4 | [] / [] | FAIL | FAIL | FAIL | PASS |
| case-013 | 4×4 | structural-discrimination | 4 | [] / [] | FAIL | FAIL | FAIL | PASS |
| case-014 | 4×4 | structural-discrimination | 4 | [] / [] | FAIL | FAIL | FAIL | PASS |
| case-015 | 7×7 | structural-discrimination | 6 | [1] / [2] | FAIL | FAIL | FAIL | PASS |
| case-016 | 12×12 | structural-discrimination | 11 | [2] / [1] | FAIL | FAIL | FAIL | PASS |
| case-017 | 8×9 | structural-discrimination | 7 | [0, 2] / [1] | FAIL | FAIL | FAIL | PASS |
| case-018 | 8×9 | structural-discrimination | 6 | [0, 1, 3] / [0, 2] | FAIL | FAIL | FAIL | PASS |
| case-019 | 8×8 | structural-discrimination | 8 | [] / [] | FAIL | FAIL | FAIL | PASS |
| case-020 | 5×5 | structural-discrimination | 4 | [1] / [0] | FAIL | FAIL | FAIL | PASS |
| case-021 | 6×6 | structural-discrimination | 5 | [1] / [0] | FAIL | FAIL | FAIL | PASS |
| case-022 | 6×6 | structural-discrimination | 5 | [2] / [0] | FAIL | FAIL | FAIL | PASS |
| case-023 | 10×10 | structural-discrimination | 9 | [3] / [2] | FAIL | FAIL | FAIL | PASS |
| case-024 | 7×7 | structural-discrimination | 6 | [0] / [3] | FAIL | FAIL | FAIL | PASS |
| case-025 | 6×6 | structural-discrimination | 5 | [3] / [0] | FAIL | FAIL | FAIL | PASS |
| case-026 | 12×12 | structural-discrimination | 11 | [2] / [3] | FAIL | FAIL | FAIL | PASS |
| case-027 | 10×10 | structural-discrimination | 9 | [2] / [2] | FAIL | FAIL | FAIL | PASS |
| case-028 | 18×18 | structural-discrimination | 17 | [3] / [2] | FAIL | FAIL | FAIL | PASS |
| case-029 | 15×15 | structural-discrimination | 14 | [1] / [1] | FAIL | FAIL | FAIL | PASS |
| case-030 | 1×18 | non-discriminating-zero-control | 0 | [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] / [0] | PASS | PASS | FAIL | PASS |
| case-031 | 18×1 | non-discriminating-zero-control | 0 | [0] / [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] | PASS | PASS | FAIL | PASS |
| case-032 | 12×12 | structural-discrimination | 11 | [1] / [2] | FAIL | FAIL | FAIL | PASS |
| case-033 | 9×8 | structural-discrimination | 7 | [1] / [0, 2] | FAIL | FAIL | FAIL | PASS |
| case-034 | 7×7 | structural-discrimination | 6 | [1] / [2] | FAIL | FAIL | FAIL | PASS |
| case-035 | 8×8 | structural-discrimination | 8 | [] / [] | FAIL | FAIL | FAIL | PASS |
| case-036 | 10×11 | structural-discrimination | 9 | [2, 2] / [1] | FAIL | FAIL | FAIL | PASS |
| case-037 | 6×6 | structural-discrimination | 4 | [1, 1] / [1, 1] | FAIL | FAIL | FAIL | PASS |
| case-038 | 12×11 | structural-discrimination | 10 | [3] / [2, 2] | FAIL | FAIL | FAIL | PASS |
| case-039 | 14×13 | structural-discrimination | 12 | [4] / [0, 2] | FAIL | FAIL | FAIL | PASS |

Exact outputs, rejection reasons, kernel nullities and input fingerprints: discrimination_v014.json. This is an author-only Windows audit, not a Linux isolation claim. Native run evidence must agree before final acceptance.
