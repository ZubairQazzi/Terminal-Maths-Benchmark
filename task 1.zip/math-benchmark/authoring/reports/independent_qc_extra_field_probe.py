from pathlib import Path
from datetime import datetime, timezone
import sys, json, copy
ROOT=Path('F:/rl/math-benchmark');TASK=ROOT/'tasks/mathematical-sciences/applied-mathematics/certified-pencil-structure'
sys.path.insert(0,str(TASK/'tests'))
import harness
from certificates import verify
c={'id':'reviewer-extra-diagnostic','A':[[0]],'B':[[0]]}
e={'normal_rank':0,'smith_factors':[],'infinite_sizes':[],'right_indices':[0],'left_indices':[0]}
o={'id':c['id'],**e,'right_basis':[[[1]]],'left_basis':[[[1]]]}
observations=[]
for value in [0.25,True,None,'0.25',1]:
    answer=copy.deepcopy(o);answer['elapsed_seconds']=value
    verify(c,e,answer)
    source=json.dumps({'cases':[answer]})
    try:
        decoded=json.loads(source,parse_float=harness.reject_float,parse_constant=harness.reject_float)
        verify(c,e,decoded['cases'][0]);accepted=True;error=None
    except Exception as exc:accepted=False;error=repr(exc)
    observations.append({'extra_field':'elapsed_seconds','value':value,'scientific_result_valid':True,'shipped_parser_accepted':accepted,'error':error})
assert observations[0]['shipped_parser_accepted'] is False
assert all(x['shipped_parser_accepted'] for x in observations[1:])
report={'reviewer':'/root/independent_qc','recorded_utc':datetime.now(timezone.utc).isoformat(),'finding_id':'IQC-013','status':'WARNING','evidence':observations,
 'contract_interpretation':'environment/spec.md line7 says extra result fields ignored; line16 bans floats/booleans in the scalar-rational paragraph. Shipped JSON parser rejects finite floats even in unused result fields but permits unused booleans/null. This is a real parser behavior and a potential public-contract ambiguity, not a mathematical certificate failure.',
 'recommended_correction':'Make treatment of ignored extra fields and global versus mathematical-scalar encoding explicit; if extras are truly ignored, retain exact type validation of scored scalar fields and allow finite JSON floats only in unscored extras. Recheck any changed behavior and fresh source hash.'}
(ROOT/'authoring/reports/independent_qc_extra_field_probe.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
