# QC remediation — v0.1.4

Task: **Certified Kronecker Structure of Singular Matrix Pencils**. Original external findings: **2**, each confirmed by three judges. This remediation changes the existing task only. Governing requirement source: the supplied 29-static/38-rubric checklist and remediation brief; copies/hashes are retained under qc_remediation_inputs/.

## Changes and reasons

- `instruction.md` and `environment/spec.md`: replace verifier-trust/reward narration with mathematical and execution obligations. All scalar types, identities, degree/basis requirements, file paths, allowed packages and limits are retained.
- `tests/cases.py`: identify convention controls and append four mathematically distinct block combinations for repeated positive indices and a maximal right index in a mixed pencil. Preserve all original 36 inputs/expectations, including every challenging case.
- Task README: replace placeholder header with manifest-derived author/budget/resources; use exactly the three authored sections; disclose six non-discriminating controls and distinguish the 34 structural cases/four related metamorphs. Remove stale validation/provenance/changelog sections to project authoring records.
- `task.toml`: bump local version to 0.1.4 and complete user-authorized contributor metadata. No human credentials or human review are fabricated.
- Author-only tooling: add exact matrix/nullity audits, trivial/public-example baselines, clean-build/native-run drivers, real-harness isolation probes, complete 29/38 reports, original source snapshots and evidence indexes.

**Unchanged core:** reference solution, test shell, batch entrypoint, dependency pins, Dockerfiles and public examples match original v0.1.3 hashes. Five confirmed contract defects were corrected: positive +q rational parsing, ignored diagnostic floats, the implicit4300-digit exact-integer conversion cap, submission-root symlink detection and silently discarded regular source in cache-named directories. Exact mathematical comparisons, all execution resources and UID/permission boundaries remain intact. Before/after full-submission probes and independent Linux rechecks establish each correction; malformed scientific fields still reject. No hard case was removed and no change was based on AI outcomes.

## Measured validation

- Initial clean no-cache agent/verifier builds: PASS on unchanged Dockerfiles/base/pins; later redundant final no-cache attempt interrupted by network loss. Final corrected-source builds: PASS using existing dependency layers; fresh native results validate that exact source.
- Fresh native oracle repeats: reward 1, 10/10 tests each, all forty pencils.
- Valid executable source-helper layout: reward 1, 10/10 tests.
- Native no-op, finite-only partial, trivial zero/scalar solver and public-example hardcoder: expected reward 0, no infrastructure exception.
- Actual per-case oracle 40/40; trivial 6/40 (0/34 structural); hardcoder 3/40 (0/34 structural); partial 6/40 (4/34 structural).
- All forty sampled-rank/kernel-nullity checks and alternate valid basis checks pass; original 36 generated inputs/expectations agree exactly.
- Real harness isolation and agent-image leakage probes: PASS.
- Native all-rule Harbor lint: empty findings array. Local static 28 PASS/1 NOT TESTED; creator rubric 36 PASS/1 WARNING/1 NOT APPLICABLE, confirmed by the distinct reviewer within the documented local scope.

See harbor_validation.md, test_discrimination_audit.md, static_qc_audit.md and rubric_qc_audit.md for item-level evidence. Exact native commands and logs remain under qc-v014/; raw task/trial evidence remains under harbor-jobs/. Reproduction commands are in project-root REPRODUCING.md.

## Independent review and final regression

The mandatory distinct reviewer /root/independent_qc used fork_turns=none, recorded initial findings before reading creator explanations, independently evaluated all67 supplied criteria and rechecked corrections. Its separate integer elimination reproduced all40 ranks and both kernel-nullity sequences; its certificate, baseline, alternative-basis and rational-encoding checks agree. All confirmed task/documentation defects are closed on independent evidence, including IQC-011 after actual final-hash Linux grading. Final regression comprises14 native trials on one checksum: four oracle repeats, eight expected-failing negative controls, one executable helper and one equivalent-rational oracle. Every CTRF file has ten distinct results; all trials have expected reward and zero exceptions. Post-review portable23 checks and both isolation probes pass. See independent_qc_initial.json, independent_qc_review.md, independent_qc_findings.json and qc-v014/runtime_summary.json. The independent review is complete; its overall QC verdict remains incomplete because the mandatory pinned-corpus comparison is unavailable.

## Originality and integrity

The objective is classical mathematics, not a new theorem. Inputs are newly constructed exact algebraic instances; expected structure is derived from canonical blocks, while the reference computes from mixed matrices. Primary mathematical references and source comparisons remain in authoring/math_research_review.md and reference_analysis.md. The original supplied scientific data files are not required by this synthetic pencil benchmark. No public benchmark answer or reference solution has been copied. Global novelty is not proven: the historical 12-document browser-only similarity sample predates instruction edits and is not the required pinned-corpus comparison.

## Unresolved external requirements

1. **Full pinned main/lite instruction-similarity check: NOT TESTED.** The user confirmed that only the supplied QC documents are available; exact corpus revisions/runner/profile were not supplied.
2. **Original external QC: NOT RUN.** Local checks and the distinct AI reviewer are not the original three-judge panel. Submit the corrected local package/evidence to that system for a full 67-check rerun; no publication is needed to keep these local results.
3. **AI difficulty calibration: incomplete.** Latest historical v0.1.3 smoke summary records zero valid graded trials and an infrastructure interruption. No new provider call, eight-trial sample or 40–60% result is claimed.
4. Independent human domain review and expert-time estimates remain unverified; contributor fields explicitly avoid implying otherwise.

The independent review and final regression are complete. The required full-corpus comparison and external decision are unresolved, so do not call the task perfect or claim all QC passed. All files remain local; no Git commit/push/publication or model-provider spending occurred during this remediation.

## Final evidence-based summary

| Item | Actual status |
|---|---|
| Task | Certified Kronecker Structure of Singular Matrix Pencils v0.1.4 |
| Previous QC failures | 2; both locally corrected and independently rechecked |
| Static QC | 28/29 PASS; 1 NOT TESTED (required pinned-corpus comparison) |
| Rubric QC | 36/38 PASS; 1 WARNING (novelty scope); 1 NOT APPLICABLE (no optional hints) |
| Independent QC | Completed; distinct fresh context, all67 criteria and final native rechecks |
| Oracle | PASS; four fresh final-hash repeats,40/40 pencils each |
| Negative controls | PASS; expected reward0 in all eight final-hash negative trials |
| Docker/Harbor | PASS current source builds/native grading; redundant final no-cache retry interrupted by network outage |
| External QC | NOT RUN |
| AI calibration | 0/8 valid trials;40–60% target NOT DETERMINED |
| Final verdict | NEEDS FURTHER WORK: required external comparison/clearance and empirical calibration unresolved |

Complete local modified/supporting-file inventory: qc-v014/delivery_inventory.md/json. Final machine status: final_delivery_status.json and qc-v014/final_status.json. No commit, push, upload or model API call occurred during remediation.
