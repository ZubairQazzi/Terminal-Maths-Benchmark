# Pre-remediation audit

Recorded before modifying task sources. Original version: **0.1.3**; 18 files; framed SHA-256 `28b89df5a40a09efbaa8eec4fa36e2458960b18020aff314bfcb6634ceb076f5`. Full original source text/hashes and actual generated inputs are preserved under authoring/provenance/qc_v013_*.json.

## Confirmed issues

- External `graded_instances_discriminate`: zero pencils case-000, case-030, case-031 were counted in 36-case coverage without disclosure. Scalar cases 001–003 are also conservatively treated as convention controls. Thus 6 controls and 30 structurally discriminating cases, not 36 difficult cases. Four of the latter are related metamorphic cases, not independent design families.
- External `instruction_clarity`: instruction and authoritative spec narrate verifier trust/reward instead of stating obligations. Remove that wording without changing identities, schema, exactness, resources, or acceptance.
- Additional `task-readme`: placeholder header, missing END marker, and extra authored level-two sections conflict with current upstream rules.
- Additional `task-fields`: human email, affiliation and profile absent. Asked user; do not invent identity, experience or conflict disclosure.

## Coverage and mathematical assessment

The generator assembles exact canonical blocks then applies constant invertible row/column shears. The checker uses standard-library rational arithmetic and construction-derived invariants, with no oracle import. The oracle computes from inputs using SymPy. Original cases cover zero indices, transpose/shift relations, repeated finite/infinite partitions, scaling, dimensions up to 18 and infinity size six. Repeated positive minimal-index multiplicities and degree-four indices inside mixed regular/singular pencils are not explicitly covered. Add narrowly justified cases for these gaps while preserving every original input and expected invariant. Do not change reference solver, certificate checker, or execution harness unless a concrete defect is established.

## Historical execution evidence (v0.1.3 only)

Raw Harbor jobs record two 9/9 oracle repeats, no-op 0/9, partial 1/9, and executable-helper 9/9 with expected binary rewards and no trial exceptions. Portable 22-check validation is a separate Windows check. New task bytes require new execution; these old results are not a v0.1.4 pass. Existing provider-stalled Gemini trajectories contain no completed eight-trial calibration.

## Baseline status across all 67 criteria

Only confirmed defects are marked FAIL below; NOT TESTED means this new audit had not yet settled that criterion when the baseline was captured. It does not erase historical evidence.

### Static

| ID | Baseline status |
|---|---|
| `entry-files` | NOT TESTED |
| `config-fields` | NOT TESTED |
| `task-fields` | FAIL |
| `task-path` | NOT TESTED |
| `task-structure` | NOT TESTED |
| `task-slug` | NOT TESTED |
| `task-readme` | FAIL |
| `canary` | NOT TESTED |
| `task-absolute-path` | NOT TESTED |
| `instruction-suffix` | NOT TESTED |
| `instruction-similarity` | NOT TESTED |
| `test-file-references` | NOT TESTED |
| `dockerfile-references` | NOT TESTED |
| `dockerfile-sanity` | NOT TESTED |
| `dockerfile-platform` | NOT TESTED |
| `allow-internet` | NOT TESTED |
| `separate-verifier` | NOT TESTED |
| `compose-host-binds` | NOT TESTED |
| `task-timeout` | NOT TESTED |
| `gpu-types` | NOT TESTED |
| `task-resources` | NOT TESTED |
| `verifier-resources` | NOT TESTED |
| `nproc` | NOT TESTED |
| `verifier-tooling-baked` | NOT TESTED |
| `trial-network-fetch` | NOT TESTED |
| `pip-pinning` | NOT TESTED |
| `pytest-version` | NOT TESTED |
| `test-sh-sanity` | NOT TESTED |
| `binary-reward` | NOT TESTED |

### Rubric

| ID | Baseline status |
|---|---|
| `well_specified` | NOT TESTED |
| `test_instruction_alignment` | NOT TESTED |
| `instruction_clarity` | FAIL |
| `structured_data_schema` | NOT TESTED |
| `typos` | NOT TESTED |
| `hint_discoverability` | NOT TESTED |
| `scientifically_grounded` | NOT TESTED |
| `scope` | NOT TESTED |
| `essential_difficulty` | NOT TESTED |
| `novel` | NOT TESTED |
| `agentic` | NOT TESTED |
| `verifiable` | NOT TESTED |
| `solvable` | NOT TESTED |
| `outcome_verified` | NOT TESTED |
| `functional_verification` | NOT TESTED |
| `ground_truth_provenance` | NOT TESTED |
| `graded_instances_discriminate` | FAIL |
| `solution_quality` | NOT TESTED |
| `do_not_modify_enforced` | NOT TESTED |
| `deterministic_reproducible` | NOT TESTED |
| `separate_verifier_configured` | NOT TESTED |
| `verifier_execution_isolation` | NOT TESTED |
| `anti_cheat_robustness` | NOT TESTED |
| `task_security` | NOT TESTED |
| `resource_configuration` | NOT TESTED |
| `task_toml_schema` | FAIL |
| `environment_hygiene` | NOT TESTED |
| `artifact_efficiency` | NOT TESTED |
| `ctrf_reporting` | NOT TESTED |
| `task_authoring_dir` | NOT TESTED |
| `no_extraneous_files` | NOT TESTED |
| `reviewable` | NOT TESTED |
| `difficulty_explanation_quality` | NOT TESTED |
| `solution_explanation_quality` | NOT TESTED |
| `verification_explanation_quality` | NOT TESTED |
| `category_and_tags` | NOT TESTED |
| `task_name` | NOT TESTED |
| `task_readme` | FAIL |
