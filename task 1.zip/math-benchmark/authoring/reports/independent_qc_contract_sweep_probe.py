"""Offline author-only Linux probe; no task or host-source writes."""
from pathlib import Path
from datetime import datetime, timezone
import tempfile, sys, json, hashlib
sys.path.insert(0,'/tests')
import harness, certificates

case={'id':'contract-sweep','A':[[0]],'B':[[0]]}
expected={'normal_rank':0,'smith_factors':[],'infinite_sizes':[],'right_indices':[0],'left_indices':[0]}
answer={'id':case['id'],**expected,'right_basis':[[[1]]],'left_basis':[[[1]]]}
digits='1'+'0'*5000
large={**answer,'right_basis':[[[digits]]],'left_basis':[[[digits]]]}
old_limit=sys.get_int_max_str_digits()
try:certificates.verify(case,expected,large);string_before=True;string_error=None
except Exception as e:string_before=False;string_error=repr(e)
numeric_source=json.dumps({'cases':[answer]}).replace('[[[1]]]', '[[['+digits+']]]')
assert len(numeric_source.encode())<16*1024**2
try:json.loads(numeric_source);numeric_before=True;numeric_error=None
except Exception as e:numeric_before=False;numeric_error=repr(e)
sys.set_int_max_str_digits(0)
certificates.verify(case,expected,large)
decoded=json.loads(numeric_source)
certificates.verify(case,expected,decoded['cases'][0])
sys.set_int_max_str_digits(old_limit)

CANDIDATE='''import json,sys
data=json.load(open(sys.argv[1])); out=[]
for c in data['cases']:
 out.append({'id':c['id'],'normal_rank':0,'smith_factors':[],'infinite_sizes':[],'right_indices':[0],'left_indices':[0],'right_basis':[[[1]]],'left_basis':[[[1]]]})
json.dump({'cases':out},open(sys.argv[2],'w'))
'''
with tempfile.TemporaryDirectory(prefix='independent-contract-') as tmp:
    root=Path(tmp);actual=root/'real-program';actual.mkdir()
    (actual/'solve.py').write_text(CANDIDATE)
    link=root/'submission-link';link.symlink_to(actual,target_is_directory=True)
    assert link.is_symlink()
    try:run=harness.run_batch(link,[(case,expected)]);link_accepted=True;link_error=None
    except Exception as e:run=None;link_accepted=False;link_error=repr(e)
    cached=root/'source-with-helper';cached.mkdir();(cached/'__pycache__').mkdir()
    (cached/'__pycache__/helper.py').write_text('def coefficient():\n return 1\n')
    prolog='''from pathlib import Path
import importlib.util
spec=importlib.util.spec_from_file_location('actual_support_helper',Path(__file__).parent/'__pycache__'/'helper.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
value=helper.coefficient()
'''
    (cached/'solve.py').write_text(prolog+CANDIDATE.replace('[[[1]]]','[[[value]]]'))
    try:harness.run_batch(cached,[(case,expected)]);helper_accepted=True;helper_error=None
    except Exception as e:helper_accepted=False;helper_error=repr(e)
    original_copy=harness.shutil.copytree
    def no_filter_copy(*args,**kwargs):
        kwargs.pop('ignore',None)
        return original_copy(*args,**kwargs)
    harness.shutil.copytree=no_filter_copy
    try:harness.run_batch(cached,[(case,expected)]);helper_without_filter_accepted=True
    finally:harness.shutil.copytree=original_copy
report={'reviewer':'/root/independent_qc','recorded_utc':datetime.now(timezone.utc).isoformat(),
 'shipped_image_source_sha256':{n:hashlib.sha256(Path('/tests',n).read_bytes()).hexdigest() for n in ('harness.py','certificates.py')},
 'integer_digit_limit':{'finding_id':'IQC-014','initial_limit':old_limit,'digits':len(digits),'valid_json_bytes':len(numeric_source.encode()),'valid_string_basis_accepted_before':string_before,'string_error':string_error,'valid_json_integer_accepted_before':numeric_before,'numeric_error':numeric_error,'same_bases_accepted_with_limit_disabled':True,'mathematical_reason':'A nonzero constant rescales each degree-zero coordinate vector in the1x1 zero pencil. It is a valid minimal basis, no normalization is imposed, and the~10KB JSON is below16MiB.'},
 'root_symlink':{'finding_id':'IQC-015','source_was_symlink':True,'shipped_harness_accepted':link_accepted,'error':link_error,'run':run,'contract_reason':'The specification disallows submission symlinks, but source.resolve() runs before checking descendant symlinks; the root itself is never rejected.'},
 'support_source_copy':{'finding_id':'IQC-016','ordinary_source_file':'__pycache__/helper.py','source_loaded_relative_to___file__':True,'shipped_harness_accepted':helper_accepted,'error':helper_error,'same_program_accepted_with_copy_filter_removed':helper_without_filter_accepted,'contract_reason':'A regular supporting .py module inside the submitted directory is silently discarded due an undocumented reserved directory name; all scientific checks pass if the source files are actually copied.'}}
assert not string_before and not numeric_before and link_accepted and not helper_accepted and helper_without_filter_accepted
print(json.dumps(report,indent=2))
