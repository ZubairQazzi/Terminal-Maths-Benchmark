from pathlib import Path
from fractions import Fraction as Q
from datetime import datetime, timezone
from hashlib import sha256
from collections import Counter
import json, copy, types

ROOT=Path('F:/rl/math-benchmark');OUT=ROOT/'authoring/reports'
TASK=ROOT/'tasks/mathematical-sciences/applied-mathematics/certified-pencil-structure'
before=json.loads((ROOT/'authoring/provenance/qc_v014_r1_snapshot.json').read_text())
old_source=before['files']['tests/certificates.py']['text']
current_source=(TASK/'tests/certificates.py').read_text()
old=types.ModuleType('independent_old_checker');new=types.ModuleType('independent_new_checker')
exec(compile(old_source,'preserved-r1-certificates.py','exec'),old.__dict__)
exec(compile(current_source,'current-certificates.py','exec'),new.__dict__)
c={'id':'reviewer-signed-positive','A':[[0]],'B':[[0]]}
e={'normal_rank':0,'smith_factors':[],'infinite_sizes':[],'right_indices':[0],'left_indices':[0]}
o={'id':c['id'],**e,'right_basis':[[['1/+2']]],'left_basis':[[['-3/+7']]]}
try:old.verify(c,e,o);old_accepted=True;error=None
except Exception as exc:old_accepted=False;error=repr(exc)
assert not old_accepted and error.startswith('ValueError')
new.verify(c,e,o)
raw=json.loads((OUT/'discrimination_v014.json').read_text())
# Load actual generator from current task source in memory, with no import cache.
generator=types.ModuleType('reviewer_generator')
exec(compile((TASK/'tests/cases.py').read_text(),'current-cases.py','exec'),generator.__dict__)
results=[]
for c,e in [p for b in generator.suite() for p in b]:
    o=copy.deepcopy(raw['programs']['oracle'][c['id']]['output'])
    def spell(v):
        if isinstance(v,list):return [spell(x) for x in v]
        q=Q(v);return f'{2*q.numerator}/+{2*q.denominator}'
    for name in ('smith_factors','right_basis','left_basis'):o[name]=spell(o[name])
    new.verify(c,e,o)
    results.append({'id':c['id'],'accepted':True,'operation':'Every scalar converted to unreduced numerator/+positive-denominator spelling'})
invalid=['1/0','1/+0','1/-2','1/++2','1.0','NaN','inf','1/2/3',True,False,0.5,None,'','1 /2',' 1/2','1/ 2','--1/2','1/2.0']
rejections=[]
for x in invalid:
    try:new.scalar(x);rejected=False
    except Exception:rejected=True
    assert rejected,repr(x)
    rejections.append({'input':x,'rejected':True})
valid=['1/+2','-3/+7','+5/+11','0/+2','+01/+002','-06/+004','1/2','-3/7','+4','-02',0,1,-2]
valid_results=[]
for x in valid:
    q=new.scalar(x)
    if isinstance(x,str) and '/' in x:
        n,d=x.split('/');expected=Q(int(n),int(d))
    else:expected=Q(x)
    assert q==expected
    valid_results.append({'input':x,'rational_value':str(q),'accepted':True})
initial=json.loads((OUT/'independent_qc_initial.json').read_text())
actual={p.relative_to(TASK).as_posix():sha256(p.read_bytes()).hexdigest() for p in sorted(TASK.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
changed=[name for name,h in actual.items() if h!=initial['file_sha256'][name]]
assert changed==['tests/certificates.py','tests/harness.py'],changed
framed=sha256()
for p in sorted(TASK.rglob('*')):
    if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':framed.update(p.relative_to(TASK).as_posix().encode()+b'\0'+p.read_bytes()+b'\0')
report={'reviewer':'/root/independent_qc','recorded_utc':datetime.now(timezone.utc).isoformat(),'finding_id':'IQC-011','raised_by':'Creator; independently reproduced and assessed by reviewer','initial_status':'FAIL','current_local_recheck':'PASS','closure_condition':'Fresh native final-source regression still required before overall closure','affected_criteria':['test_instruction_alignment','structured_data_schema','outcome_verified','solvable'],
 'old_source_sha256':sha256(old_source.encode()).hexdigest(),'current_source_sha256':actual['tests/certificates.py'],'initial_task_sha256':initial['task_sha256'],'current_task_sha256':framed.hexdigest(),'changed_files_from_initial':changed,
 'before':{'valid_full_certificate_rejected':True,'error':error,'answer':o if False else {'id':'reviewer-signed-positive',**{'normal_rank':0,'smith_factors':[],'infinite_sizes':[],'right_indices':[0],'left_indices':[0]},'right_basis':[[['1/+2']]],'left_basis':[[['-3/+7']]]}},
 'after':{'same_valid_certificate_accepted':True,'all40_equivalent_spellings':results,'valid_scalar_forms':valid_results,'malformed_or_inexact_rejected':rejections},
 'analysis':'Regex already recognizes optional positive-denominator plus. Fraction(string) wrongly rejected that grammar. Splitting numerator/denominator to integer arguments preserves exact rational semantics, positive-denominator enforcement and all scientific checks; no expected structure or tolerance was weakened.','success':True}
(OUT/'independent_qc_rational_recheck.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'success':True,'current_task_sha256':framed.hexdigest(),'changed_files':changed,'full_certificate_before_rejected':True,'full_certificate_after_accepted':True,'all40_equivalent':len(results),'valid_forms':len(valid_results),'malformed_rejections':len(rejections)},indent=2))
