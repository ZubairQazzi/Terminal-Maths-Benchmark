"""Independent reviewer evidence. No source writes, network, installs or provider calls."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, json, sys, copy

ROOT=Path('F:/rl/math-benchmark')
OUT=ROOT/'authoring/reports'
TASK=ROOT/'tasks/mathematical-sciences/applied-mathematics/certified-pencil-structure'
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=sorted(p for p in TASK.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
hashes={p.relative_to(TASK).as_posix():sha(p.read_bytes()) for p in paths}
framed=hashlib.sha256()
for p in paths: framed.update(p.relative_to(TASK).as_posix().encode()+b'\0'+p.read_bytes()+b'\0')
snapshot=json.loads((ROOT/'authoring/provenance/qc_v013_snapshot.json').read_text())
unchanged={n:hashes[n]==snapshot['files'][n]['sha256'] for n in hashes}
runtime=[]
for job in sorted((OUT/'harbor-jobs').glob('qc-v014-pre-review-*')):
    for p in sorted(job.iterdir()):
        if not p.is_dir():continue
        r=json.loads((p/'result.json').read_text()); c=json.loads((p/'verifier/ctrf.json').read_text())
        tests=c['results']['tests']
        runtime.append({'job':job.name,'trial':p.name,'task_checksum':r['task_checksum'],
            'reward':(p/'verifier/reward.txt').read_text().strip(),'exception':r.get('exception_info'),
            'ctrf_summary':c['results']['summary'],'tests':[{k:t[k] for k in ('name','status','duration')} for t in tests],
            'source_hashes':{n:sha((p/n).read_bytes()) for n in ('config.json','result.json','verifier/ctrf.json','verifier/reward.txt','verifier/pytest.log')}})

if '--initial' in sys.argv:
    d={'reviewer':{'identity':'/root/independent_qc','fresh_context':True,'fork_turns':'none',
       'role':'Distinct QC sub-agent, not original external panel and not independent human mathematician'},
       'recorded_utc':datetime.now(timezone.utc).isoformat(),
       'stage':'Initial findings recorded before creator explanatory reports were read',
       'scope':['Full supplied user brief','Complete QC-CHECKLIST.md (29 static,38 rubric)','Complete message.txt',
                'Original instruction/spec from qc_v013_snapshot.json','All 18 current task files',
                'Raw portable validation/discrimination and isolation JSON','Raw clean Docker build logs and commands',
                'Raw native lint','All seven pre-review native trial result/config/CTRF/reward records'],
       'checklist_sha256':sha(Path('F:/rl/QC-CHECKLIST.md').read_bytes()),
       'external_report_sha256':sha(Path('F:/rl/message.txt').read_bytes()),
       'task_sha256':framed.hexdigest(),'file_sha256':hashes,'unchanged_from_v013':unchanged,'raw_trials':runtime,
       'initial_findings':[
          {'id':'IQC-001','status':'PASS','topic':'instruction_clarity','finding':'The two cited verifier/reward sentences have been removed; the replacement states exact mathematical and execution obligations. Paths, definitions and limits remain explicit.','evidence':['instruction.md:4','instruction.md:6','environment/spec.md:22']},
          {'id':'IQC-002','status':'PASS','topic':'graded_instances_discriminate','finding':'The README now explicitly counts 6 easy controls separately from 34 structural cases. Generator adds four positive-index mixed/repeated cases without removing the original designs. Raw trivial outcomes: 6/40 overall and 0/34 structural; binary full reward is denied. Preservation of original36 actual matrices still to be independently recomputed.','evidence':['README.md:38','tests/cases.py:155','tests/cases.py:193','authoring/reports/discrimination_v014.json']},
          {'id':'IQC-003','status':'PASS','topic':'unchanged_core','finding':'Independent per-file SHA comparison confirms reference, certificate checker, harness, shell acceptance logic and runtime Dockerfiles/requirements are unchanged from v0.1.3.','evidence':['authoring/provenance/qc_v013_snapshot.json']},
          {'id':'IQC-004','status':'PASS','topic':'raw_runtime','finding':'Two independent native oracle trials and executable-helper submission pass ten CTRF tests and reward1. Nop, partial, trivial and hardcoded receive reward0 without Harbor exceptions; partial/trivial legitimately pass one batch.','evidence':['authoring/reports/harbor-jobs/qc-v014-pre-review-*']},
          {'id':'IQC-005','status':'NOT TESTED','topic':'external_pipeline_and_similarity','finding':'Original external runner, pinned task corpus revisions and Local profile are unavailable. Native lint and this review do not establish those results.','suggested_correction':'Run the actual external pipeline and full pinned-corpus similarity when supplied.'},
          {'id':'IQC-006','status':'WARNING','topic':'empirical_calibration','finding':'README candidly reports absent valid eight-trial calibration. Historical raw calibration still to be independently inspected; interrupted provider trials cannot establish mathematical difficulty or success rate.','evidence':['README.md:30']}
       ],'confirmed_source_defects':[],'pending_independent_checks':['Recompute actual generator preservation and structural invariants','Read creator reports and research/provenance sources','Assess every29+38 criterion individually','Inspect historical calibration raw trajectory','Recheck parent final post-review native regression']}
    (OUT/'independent_qc_initial.json').write_text(json.dumps(d,indent=2)+'\n')
    print(json.dumps({'initial_artifact':str(OUT/'independent_qc_initial.json'),'task_sha256':framed.hexdigest(),'checklist_sha256':d['checklist_sha256'],'initial_findings':len(d['initial_findings']),'core_unchanged':all(unchanged[n] for n in ('solution/solve.py','solution/solve.sh','tests/certificates.py','tests/harness.py','tests/test.sh'))},indent=2))

def irank(rows):
    """Independent integer Gaussian elimination with row-content reduction."""
    from math import gcd
    from functools import reduce
    from fractions import Fraction
    a=[]
    for row in rows:
        q=[Fraction(x) for x in row]
        from math import lcm
        mult=lcm(*(x.denominator for x in q))
        a.append([int(x*mult) for x in q])
    if not a:return 0
    m,n=len(a),len(a[0]);r=0
    for col in range(n):
        candidates=[i for i in range(r,m) if a[i][col]]
        if not candidates:continue
        j=min(candidates,key=lambda i:abs(a[i][col]))
        a[r],a[j]=a[j],a[r]
        for i in range(r+1,m):
            q=a[i][col]
            if not q:continue
            p=a[r][col];g=gcd(p,q);u,v=p//g,q//g
            a[i][col]=0
            for k in range(col+1,n):a[i][k]=u*a[i][k]-v*a[r][k]
            content=reduce(gcd,a[i][col+1:],0)
            if content>1:
                for k in range(col+1,n):a[i][k]//=content
        r+=1
        if r==m:break
    return r

def independent_degrees(A,B):
    m,n=len(A),len(A[0]);nullities=[]
    for d in range(5):
        # Assemble by coefficient equations, independently of reference/checker.
        rows=[]
        for power in range(d+2):
            for i in range(m):
                row=[]
                for k in range(d+1):
                    row.extend([A[i][j] if k==power else -B[i][j] if k+1==power else 0 for j in range(n)])
                rows.append(row)
        nullities.append((d+1)*n-irank(rows))
    h=[0,0]+nullities
    degrees=[]
    for d in range(5):
        mult=h[d+2]-2*h[d+1]+h[d]
        assert mult>=0
        degrees.extend([d]*mult)
    return degrees,nullities

def own_verify(c,e,o):
    from fractions import Fraction as Q
    assert o['id']==c['id'] and type(o['normal_rank']) is int and o['normal_rank']==e['normal_rank']
    for key in ('right_indices','left_indices','infinite_sizes'):
        assert type(o[key]) is list and all(type(v) is int for v in o[key]) and o[key]==e[key]
    factors=[]
    for p in o['smith_factors']:
        assert p
        f=[Q(v) for v in p]
        while len(f)>1 and f[-1]==0:f.pop()
        factors.append(f)
    assert factors==e['smith_factors']
    for side in ('right','left'):
        A,B=(c['A'],c['B']) if side=='right' else ([list(x) for x in zip(*c['A'])],[list(x) for x in zip(*c['B'])])
        basis=o[side+'_basis'];degrees=e[side+'_indices'];m,n=len(A),len(A[0]);highest=[]
        assert len(basis)==len(degrees)
        for cert,d in zip(basis,degrees):
            assert len(cert)==d+1 and all(len(v)==n for v in cert)
            v=[[Q(x) for x in row] for row in cert]
            assert any(v[-1]);highest.append(v[-1])
            for i in range(m):
                for k in range(d+2):
                    lhs=sum(A[i][j]*v[k][j] for j in range(n)) if k<=d else 0
                    rhs=sum(B[i][j]*v[k-1][j] for j in range(n)) if k>0 else 0
                    assert lhs==rhs
        assert irank(highest)==len(degrees)

if '--matrix' in sys.argv:
    import time
    from fractions import Fraction as Q
    start=time.monotonic()
    sys.path.insert(0,str(TASK/'tests'))
    from cases import suite
    from certificates import verify
    flat=[p for b in suite() for p in b]
    original=json.loads((ROOT/'authoring/provenance/qc_v013_generated_cases.json').read_text())
    assert json.loads(json.dumps([{'case':c,'expected':e} for c,e in flat[:36]],default=str))==original
    assert json.dumps(flat,default=str,sort_keys=True)==json.dumps([p for b in suite() for p in b],default=str,sort_keys=True)
    raw=json.loads((OUT/'discrimination_v014.json').read_text())
    audit={'reviewer':'/root/independent_qc','task_sha256':framed.hexdigest(),
           'method':'Independent integer elimination with content reduction; coefficient-nullity sequences and exact coefficient identities. No reference solver call.',
           'original36_inputs_expectations_preserved':True,'fresh_generator_deterministic':True,'cases':[],'baseline_results':{}}
    for c,e in flat:
        A,B=c['A'],c['B'];m,n=len(A),len(A[0])
        assert len(B)==m and all(len(row)==n for M in (A,B) for row in M)
        assert 1<=m<=18 and 1<=n<=18 and max(abs(x) for M in (A,B) for row in M for x in row)<=10**15
        sampled=[irank([[A[i][j]-t*B[i][j] for j in range(n)] for i in range(m)]) for t in range(min(m,n)+1)]
        assert max(sampled)==e['normal_rank']
        rd,rh=independent_degrees(A,B)
        ld,lh=independent_degrees([list(x) for x in zip(*A)],[list(x) for x in zip(*B)])
        assert rd==e['right_indices'] and ld==e['left_indices']
        assert len(rd)==n-e['normal_rank'] and len(ld)==m-e['normal_rank']
        assert sum(len(p)-1 for p in e['smith_factors'])+sum(e['infinite_sizes'])+sum(rd)+sum(ld)==e['normal_rank']
        o=raw['programs']['oracle'][c['id']]['output'];own_verify(c,e,o)
        # Independently choose different basis transformations from the creator audit.
        alt=copy.deepcopy(o)
        for side in ('right','left'):
            certs=alt[side+'_basis'];degrees=alt[side+'_indices']
            if len(certs)>1:
                shift=degrees[-1]-degrees[0]
                for k,vec in enumerate(certs[0]):
                    certs[-1][k+shift]=[str(Q(a)-Q(2,5)*Q(b)) for a,b in zip(certs[-1][k+shift],vec)]
            for cert in certs:
                for v in cert:v[:]=[str(Q(x)*Q(13,17)) for x in v]
        own_verify(c,e,alt);verify(c,e,alt)
        zero=not any(x for M in (A,B) for row in M for x in row)
        audit['cases'].append({'id':c['id'],'shape':[m,n],'normal_rank':max(sampled),'sample_ranks':sampled,'right_indices':rd,'left_indices':ld,'right_nullities':rh,'left_nullities':lh,'oracle_certificate_independently_valid':True,'reviewer_alternative_accepted':True,'category':'zero-control' if zero else 'scalar-control' if m==n==1 else 'structural'})
        for name in raw['programs']:
            try:own_verify(c,e,raw['programs'][name][c['id']]['output']);status='PASS'
            except Exception:status='FAIL'
            assert status==raw['programs'][name][c['id']]['status']
            audit['baseline_results'].setdefault(name,{})[c['id']]=status
        print(c['id']+' independently verified',flush=True)
    audit['seconds']=time.monotonic()-start;audit['success']=True
    (OUT/'independent_qc_math.json').write_text(json.dumps(audit,indent=2)+'\n')
    print(json.dumps({'success':True,'cases':len(flat),'seconds':audit['seconds'],'categories':dict(Counter(c['category'] for c in audit['cases']))}))
