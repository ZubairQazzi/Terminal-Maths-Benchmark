# Author and reviewer materials

Current remediation: **v0.1.4**, based on the supplied 29-static / 38-rubric checklist and the two external findings. The runtime task lives under tasks/mathematical-sciences/applied-mathematics/certified-pencil-structure. Review materials here are outside both task image build contexts and are never given to a benchmark-solving agent.

The original v0.1.3 source and generated inputs are preserved in provenance/qc_v013_snapshot.json and provenance/qc_v013_generated_cases.json. Historical files without a version suffix may predate this remediation. Use reports/qc_remediation.md and the current 29/38 reports rather than the old 40-criterion audit for the current verdict.

Current evidence:

- reports/reconciled_qc_requirements.md and pre_remediation_audit.md: governing requirements and before-state.
- reports/test_discrimination_audit.md and discrimination_v014.json: all actual inputs, structural/control classification, exact per-case baseline results and independent mathematical checks.
- reports/static_qc_audit.md/json and rubric_qc_audit.md/json: all 67 supplied IDs, bounded local verdicts and limitations.
- reports/harbor_validation.md and qc-v014/runtime_summary.json: measured native results and raw-result index.
- reports/qc-v014/: exact commands, timestamps, exit codes, clean builds and console logs.
- reports/harbor-jobs/qc-v014-*/: original native configurations, results, artifacts, CTRF and reward files.
- reports/independent_qc_initial.json, independent_qc_review.md and independent_qc_findings.json: distinct fresh-context review and rechecks, when completed.

Research and provenance remain in math_research_review.md, reference_analysis.md and originality_assessment.md. Public reference inspection is browser-only. The twelve-document historical similarity sample does not prove global novelty or replace the unavailable pinned main/lite comparison.

Version history: v0.1.1 repaired distinct CTRF names; v0.1.2 added existing public boundary coverage; v0.1.3 repaired executable source-helper access. v0.1.4 removes grader/reward narration, updates contributor metadata/managed README, identifies six convention controls and appends four structural cases. Further QC corrections restore the documented positive-denominator grammar, ignored extra fields, arbitrary-precision exact integers and regular-source copying; root symlinks are explicitly rejected. All original36 generated inputs/expectations and the oracle remain unchanged; mathematical certificate comparisons and resource/isolation rules remain exact. Intermediate r1/r2 sources and native trials remain separately labeled, with complete source snapshots in provenance/.

No scientific attachment data or published answer key is used by this synthetic exact-algebra task. Canonical block construction is the ground-truth source. Model trajectories remain historical private evaluation evidence, not oracle ground truth. Provider interruptions do not count as mathematical failures. No valid eight-trial calibration or 40–60% measured success rate has been established.

The original external QC executable, pinned corpus revisions and custom Local-profile settings were not supplied. Original external QC is NOT RUN. No Git commit, push, publication, registry upload or hosted submission is authorized by this remediation request.
