"""Read-only container probes; no network or model calls."""
import json
import argparse
from pathlib import Path
import subprocess
from qc_remediate import ROOT, REPORTS, dump
DOCKER=r'C:\Users\zubai\AppData\Local\Programs\DockerDesktop\resources\bin\docker.exe'
parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['pre-review','post-review'],default='pre-review');args=parser.parse_args()
suffix='' if args.stage=='pre-review' else '_post_review'
def run(name,args):
    cp=subprocess.run([DOCKER]+args,capture_output=True,text=True,encoding='utf-8')
    (REPORTS/'qc-v014'/f'{name}.log').write_text(cp.stdout+cp.stderr,encoding='utf-8')
    dump(REPORTS/'qc-v014'/f'{name}.command.json',{'executable':DOCKER,'arguments':args,'exit_code':cp.returncode})
    assert cp.returncode==0,cp.stderr
    value=json.loads(cp.stdout);dump(REPORTS/f'{name}.json',value);assert value['success']
    print(name,'PASS',flush=True)

run('isolation_probe_v014'+suffix,['run','--rm','--network','none','--cpus','2','--memory','4g','--mount',f'type=bind,source={ROOT / "authoring/evidence/probe_qc_isolation.py"},target=/author-probe.py,readonly','local-pencil-verifier:qc-v014','python3','/author-probe.py'])
code='import json,os;from pathlib import Path;files=sorted(str(p) for p in Path("/app").rglob("*") if p.is_file());hidden=[str(p) for p in (Path("/tests/cases.py"),Path("/solution/solve.py")) if p.exists()];assert files==["/app/data/examples.json","/app/spec.md"] and not hidden;print(json.dumps({"success":True,"uid":os.getuid(),"files":files,"private_files":hidden}))'
run('agent_leakage_probe_v014'+suffix,['run','--rm','--network','none','--cpus','2','--memory','4g','local-pencil-agent:qc-v014','python3','-c',code])
