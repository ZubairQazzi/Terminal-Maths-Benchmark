param([ValidateSet('build','source-build','pre-review','post-review')][string]$Phase = 'pre-review', [string]$Revision = 'r3')
$ErrorActionPreference = 'Stop'
$taskRoot = 'F:\rl\math-benchmark'
$taskPath = Join-Path $taskRoot 'tasks\mathematical-sciences\applied-mathematics\certified-pencil-structure'
$reportRoot = Join-Path $taskRoot 'authoring\reports\qc-v014'
New-Item -ItemType Directory -Force -Path $reportRoot | Out-Null
$dockerExe = 'C:\Users\zubai\AppData\Local\Programs\DockerDesktop\resources\bin\docker.exe'
$harborExe = 'C:\Users\zubai\.local\bin\harbor.exe'
$env:PATH = (Split-Path $dockerExe) + ';' + $env:PATH
$env:PYTHONPATH = $taskRoot
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
Set-Location -LiteralPath $taskRoot
function Invoke-Recorded {
    param([string]$Name,[string]$Exe,[string[]]$Arguments)
    $started = Get-Date
    Write-Output "Starting $Name"
    & $Exe @Arguments 2>&1 | Tee-Object -FilePath (Join-Path $reportRoot "$Name.log")
    $code = $LASTEXITCODE
    $record = [ordered]@{name=$Name; executable=$Exe; arguments=$Arguments; started=$started.ToUniversalTime().ToString('o'); ended=(Get-Date).ToUniversalTime().ToString('o'); exit_code=$code}
    $record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $reportRoot "$Name.command.json") -Encoding utf8
    if ($code -ne 0) { throw "$Name exited $code; inspect raw log" }
}
if ($Phase -eq 'build') {
    Invoke-Recorded -Name 'clean-agent-build' -Exe $dockerExe -Arguments @('build','--no-cache','--pull','--tag','local-pencil-agent:qc-v014',(Join-Path $taskPath 'environment'))
    Invoke-Recorded -Name 'clean-verifier-build' -Exe $dockerExe -Arguments @('build','--no-cache','--pull','--tag','local-pencil-verifier:qc-v014',(Join-Path $taskPath 'tests'))
} elseif ($Phase -eq 'source-build') {
    Invoke-Recorded -Name "cached-agent-build-$Revision" -Exe $dockerExe -Arguments @('build','--pull=false','--tag','local-pencil-agent:qc-v014',(Join-Path $taskPath 'environment'))
    Invoke-Recorded -Name "cached-verifier-build-$Revision" -Exe $dockerExe -Arguments @('build','--pull=false','--tag','local-pencil-verifier:qc-v014',(Join-Path $taskPath 'tests'))
} else {
    Invoke-Recorded -Name "$Phase-lint" -Exe $harborExe -Arguments @('lint',$taskPath,'--select','ALL','--json')
    $jobs = if ($Phase -eq 'pre-review') {
        @(@('oracle','oracle'),@('nop','nop'),@('partial','authoring.evidence.baseline_agent:PartialAgent'),@('trivial','authoring.evidence.baseline_agent:TrivialAgent'),@('hardcoded','authoring.evidence.baseline_agent:HardcodedAgent'),@('helper','authoring.evidence.baseline_agent:ExecutableHelperAgent'))
    } else {
        @(@('oracle','oracle'),@('nop','nop'),@('partial','authoring.evidence.baseline_agent:PartialAgent'),@('trivial','authoring.evidence.baseline_agent:TrivialAgent'),@('hardcoded','authoring.evidence.baseline_agent:HardcodedAgent'),@('rational','authoring.evidence.baseline_agent:RationalSpellingAgent'))
    }
    foreach ($job in $jobs) {
        $jobName = "qc-v014-$Revision-$Phase-$($job[0])"
        $runArgs = @('run','--path',$taskPath,'--agent',$job[1],'--job-name',$jobName,'--jobs-dir',(Join-Path $taskRoot 'authoring\reports\harbor-jobs'),'--n-concurrent','1')
        if ($job[0] -eq 'oracle') { $runArgs += @('-k','2') }
        Invoke-Recorded -Name $jobName -Exe $harborExe -Arguments $runArgs
    }
}
