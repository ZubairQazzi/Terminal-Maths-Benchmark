"""Author-only exact per-case audit; not shipped in either task image."""
from copy import deepcopy
from fractions import Fraction as F
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from qc_remediate import ROOT, TASK, REPORTS, dump, framed_hash, sha
sys.path.insert(0,str(TASK/'tests'))
from cases import suite
from certificates import verify, rank

def matrix_nullities(A,B):
    m,n=len(A),len(A[0]); ns=[]
    for degree in range(5):
        C=[[0]*((degree+1)*n) for _ in range((degree+2)*m)]
        for k in range(degree+1):
            for i in range(m):
                for j in range(n):
                    C[k*m+i][k*n+j]=A[i][j]
                    C[(k+1)*m+i][k*n+j]=-B[i][j]
        ns.append((degree+1)*n-rank(C))
    padded=[0,0]+ns
    degrees=[]
    for d in range(5):
        multiplicity=padded[d+2]-2*padded[d+1]+padded[d]
        assert multiplicity>=0
        degrees += [d]*multiplicity
    return ns,degrees

def run_program(source,batches):
    results={}
    with tempfile.TemporaryDirectory(prefix='pencil-author-audit-') as d:
        inp,out=Path(d)/'input.json',Path(d)/'output.json'
        for batch in batches:
            inp.write_text(json.dumps({'cases':[c for c,e in batch]}))
            out.unlink(missing_ok=True)
            started=time.monotonic()
            cp=subprocess.run([sys.executable,str(source/'solve.py'),str(inp),str(out)],cwd=d,capture_output=True,text=True,timeout=180)
            assert cp.returncode==0,cp.stderr
            got=json.loads(out.read_text())['cases']; assert len(got)==len(batch)
            byid={r['id']:r for r in got};assert len(byid)==len(batch)
            for c,e in batch:
                try: verify(c,e,byid[c['id']]);status,reason='PASS',None
                except Exception as exc: status,reason='FAIL',str(exc) or type(exc).__name__
                results[c['id']]={'status':status,'reason':reason,'batch_seconds':time.monotonic()-started,'output':byid[c['id']]}
    return results

def alternate(case,expected,answer):
    """Nonconstant unimodular column mixing, plus rational rescaling."""
    x=deepcopy(answer); operations=[]
    for side in ('right','left'):
        certs=x[side+'_basis']; degrees=x[side+'_indices']
        if len(certs)>=2:
            # basis is ordered; adding z^(e1-e0)*v0 to v1 is unimodular
            lo,hi=0,len(certs)-1; delta=degrees[hi]-degrees[lo]
            for k,vec in enumerate(certs[lo]):
                certs[hi][k+delta]=[str(F(a)+F(5,11)*F(b)) for a,b in zip(certs[hi][k+delta],vec)]
            operations.append(side+':unimodular-mix-shift-'+str(delta))
        for cert in certs:
            for vec in cert:
                vec[:]=[str(F(v)*F(-3,7)) for v in vec]
    verify(case,expected,x)
    return operations

def main():
    started=time.monotonic(); batches=suite(); flat=[(c,e) for b in batches for c,e in b]
    before=json.loads((ROOT/'authoring/provenance/qc_v013_generated_cases.json').read_text())
    assert json.loads(json.dumps([{'case':c,'expected':e} for c,e in flat[:36]],default=str))==before
    deterministic=sha(json.dumps(flat,default=str,sort_keys=True).encode())
    assert deterministic==sha(json.dumps([v for b in suite() for v in b],default=str,sort_keys=True).encode())
    report={'task_sha256':framed_hash(),'generated_suite_sha256':deterministic,'original_36_unchanged':True,'cases':[], 'programs':{},'kind':'portable exact author audit; native isolation separately measured'}
    for c,e in flat:
        A,B=c['A'],c['B'];m,n=len(A),len(A[0]);zero=not any(x for M in (A,B) for row in M for x in row)
        category='non-discriminating-zero-control' if zero else ('non-discriminating-scalar-control' if m==n==1 else 'structural-discrimination')
        assert all(len(row)==n for M in (A,B) for row in M)
        assert 1<=m<=18 and 1<=n<=18 and all(type(x)is int and abs(x)<=10**15 for M in (A,B) for row in M for x in row)
        r=max(rank([[a-t*b for a,b in zip(ar,br)] for ar,br in zip(A,B)]) for t in range(min(m,n)+1))
        assert r==e['normal_rank'],c['id']
        nr,right=matrix_nullities(A,B);nl,left=matrix_nullities(list(map(list,zip(*A))),list(map(list,zip(*B))))
        assert right==e['right_indices'] and left==e['left_indices'],c['id']
        row={'id':c['id'],'shape':[m,n],'category':category,'normal_rank':r,'right_indices':right,'left_indices':left,'right_kernel_nullities_0_to_4':nr,'left_kernel_nullities_0_to_4':nl,'expected':e,'input_sha256':sha(json.dumps(c,sort_keys=True).encode())}
        report['cases'].append(row)
        print(c['id'],m,n,category,'exact rank/kernel audit PASS',flush=True)
        dump(REPORTS/'discrimination_v014.json',report)
    for name,path in [('oracle',TASK/'solution')]+[(n,ROOT/'authoring/evidence/baselines'/n) for n in ('trivial','hardcoded','partial')]:
        report['programs'][name]=run_program(path,batches)
        print(name,sum(r['status']=='PASS' for r in report['programs'][name].values()),'/',len(flat),flush=True)
        dump(REPORTS/'discrimination_v014.json',report)
    report['alternative_valid_bases']=[]
    for c,e in flat:
        answer=report['programs']['oracle'][c['id']]['output'];assert report['programs']['oracle'][c['id']]['status']=='PASS'
        ops=alternate(c,e,answer)
        report['alternative_valid_bases'].append({'id':c['id'],'status':'PASS','operations':ops or ['rational-rescaling-or-empty-basis']})
    report['seconds']=time.monotonic()-started
    report['success']=True
    dump(REPORTS/'discrimination_v014.json',report)
    controls=[r for r in report['cases'] if r['category']!='structural-discrimination']
    lines=['# Hidden-test discrimination audit','',f"Measured {len(flat)} actual generated pencils in {len(batches)} mandatory batches: **{len(controls)} non-discriminating controls, {len(flat)-len(controls)} structural cases**.",'',
           'Zero controls are case-000 (2×3), case-030 (1×18), case-031 (18×1). Scalar controls are case-001, case-002, case-003. These six test conventions and bounds; they are not evidence of mathematical difficulty. The first batch consists only of controls; the other nine contain structural cases. Four structural cases (032–035) are related metamorphic checks, so there are thirty other structural designs, not 34 independent families.','',
           'All original 36 inputs/ids/expected invariants match the pre-remediation snapshot exactly. New cases 036–039 add repeated positive right indices [2,2] with finite/infinite/left components; repeated positive indices on both sides; repeated left indices [2,2] in a mixed pencil; and a right index four with regular, infinite and left components. These additions cover distinct block multiplicities and degree filtration gaps. They were not selected using AI outcomes.','',
           'Exact sampled rank is conclusive: every pencil minor has degree ≤ min(m,n), so min(m,n)+1 distinct rational samples determine the maximal rank. Independent coefficient-matrix ranks at degrees 0–4 give nullities; their second differences recover minimal-index multiplicities on both sides. This audit uses rational elimination, not the reference generator-selection algorithm. Construction proves finite/infinite invariants; the general Smith-form oracle independently agrees on all cases. Full certificates pass coefficient identities and leading-rank tests.','',
           'Fresh suite generation agrees byte-for-byte. Forty alternate valid outputs pass after rational rescaling and, wherever there are two generators, nonconstant unimodular mixing (including equal-degree mixing). The checker does not require the oracle basis representation.','', '| Program | All cases passed | Structural cases passed | Full benchmark credit |','|---|---:|---:|---|']
    for name,rs in report['programs'].items():
        allpass=sum(v['status']=='PASS' for v in rs.values());disc=sum(rs[c['id']]['status']=='PASS' for c in report['cases'] if c['category']=='structural-discrimination')
        lines += [f'| {name} | {allpass}/{len(flat)} | {disc}/{len(flat)-len(controls)} | '+('Yes' if allpass==len(flat) else 'No')+' |']
    lines += ['', 'The finite-Smith-only baseline is deliberately plausible and can solve finite-only structural cases. This is useful evidence that each semantic family is needed; do not call every structural case hard for every incomplete method. The trivial baseline recovers zero/scalar conventions only; the hardcoder knows only public examples plus a zero guess. None receives the hidden expectations. Full native Harbor rewards are reported separately.','', '## Per-case measured results','', '| Case | Shape | Category | Rank | Right / left degrees | Trivial | Hardcoded | Partial | Oracle |','|---|---|---|---:|---|---|---|---|---|']
    for r in report['cases']:
        fields=[r['id'],'×'.join(map(str,r['shape'])),r['category'],str(r['normal_rank']),str(r['right_indices'])+' / '+str(r['left_indices'])]+[report['programs'][p][r['id']]['status'] for p in ('trivial','hardcoded','partial','oracle')]
        lines += ['| '+' | '.join(fields)+' |']
    lines += ['', 'Exact outputs, rejection reasons, kernel nullities and input fingerprints: discrimination_v014.json. This is an author-only Windows audit, not a Linux isolation claim. Native run evidence must agree before final acceptance.','']
    (REPORTS/'test_discrimination_audit.md').write_text('\n'.join(lines),encoding='utf-8')

if __name__=='__main__': main()
