"""Mount read-only in the verifier; exercise the real candidate harness."""
import json
import os
from pathlib import Path
import sys
import tempfile
sys.path.insert(0,'/tests')
import harness

CANDIDATE = '''import json,os,resource,sys
from pathlib import Path
probe={"uid":os.getuid(),"gid":os.getgid(),"groups":os.getgroups(),"cpu":resource.getrlimit(resource.RLIMIT_CPU)[0],"memory":resource.getrlimit(resource.RLIMIT_AS)[0],"fds":resource.getrlimit(resource.RLIMIT_NOFILE)[0],"secret_env_present":any(k in os.environ for k in ("GEMINI_API_KEY","GOOGLE_API_KEY","GITHUB_TOKEN","GROQ_API_KEY"))}
for name,path,mode in [("tests_read","/tests/cases.py","r"),("reward_write","/logs/verifier/reward.txt","w"),("source_write",__file__,"a")]:
    try:
        with open(path,mode): pass
        probe[name]="UNEXPECTED_SUCCESS"
    except PermissionError: probe[name]="DENIED"
probe["oracle_present"]=Path("/solution/solve.py").exists()
data=json.load(open(sys.argv[1])); answers=[]
for c in data["cases"]:
    m,n=len(c["A"]),len(c["A"][0]); answers.append({"id":c["id"],"normal_rank":0,"smith_factors":[],"infinite_sizes":[],"right_indices":[0]*n,"left_indices":[0]*m,"right_basis":[[[int(i==j) for i in range(n)]] for j in range(n)],"left_basis":[[[int(i==j) for i in range(m)]] for j in range(m)],"probe":probe})
json.dump({"cases":answers},open(sys.argv[2],"w"))
'''
observed=[]
original=harness.verify
def capture(c,e,r):
    original(c,e,r)
    observed.append(r['probe'])
harness.verify=capture
case={'id':'probe-zero','A':[[0,0]],'B':[[0,0]]}
expected={'normal_rank':0,'smith_factors':[],'infinite_sizes':[],'right_indices':[0,0],'left_indices':[0]}
with tempfile.TemporaryDirectory(prefix='author-isolation-') as d:
    source=Path(d)/'source'
    source.mkdir()
    (source/'solve.py').write_text(CANDIDATE)
    execution=harness.run_batch(source,[(case,expected)])
    link=Path(d)/'submission-link'
    link.symlink_to(source,target_is_directory=True)
    try:
        harness.run_batch(link,[(case,expected)])
    except AssertionError as exc:
        assert 'submission symlinks are not allowed' in str(exc)
        root_symlink_rejected=True
    else:
        raise AssertionError('Submission-root symlink was accepted')
probe=observed[0]
assert probe['uid']==probe['gid']==65534 and probe['groups']==[]
assert all(probe[k]=='DENIED' for k in ('tests_read','reward_write','source_write'))
assert not probe['secret_env_present'] and not probe['oracle_present']
assert (probe['cpu'],probe['memory'],probe['fds'])==(180,2*1024**3,128)
print(json.dumps({'success':True,'probe':probe,'execution':execution,'root_symlink_rejected':root_symlink_rejected},indent=2))
