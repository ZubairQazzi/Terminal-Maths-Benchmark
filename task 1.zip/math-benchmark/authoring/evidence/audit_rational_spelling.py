"""Regression for equivalent exact rational spellings, including positive +q."""
from copy import deepcopy
from fractions import Fraction as F
import argparse
import json
import sys
from qc_remediate import ROOT,TASK,REPORTS,framed_hash,dump,files,sha
sys.path.insert(0,str(TASK/'tests'))
from certificates import scalar,verify
from cases import suite

parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['before','after']);a=parser.parse_args()
if a.stage=='before':
    dest=ROOT/'authoring/provenance/qc_v014_r1_snapshot.json'
    assert not dest.exists()
    dump(dest,{'framed_sha256':framed_hash(),'files':{p.relative_to(TASK).as_posix():{'sha256':sha(p.read_bytes()),'text':p.read_text(encoding='utf-8')} for p in files()}})

c={'id':'valid-rational-convention','A':[[0]],'B':[[0]]}
e={'normal_rank':0,'smith_factors':[],'infinite_sizes':[],'right_indices':[0],'left_indices':[0]}
answer={'id':c['id'],**e,'right_basis':[[['1/+2']]],'left_basis':[[['-3/+7']]]}
try:verify(c,e,answer); accepted=True;error=None
except Exception as ex:accepted=False;error=repr(ex)
report={'stage':a.stage,'task_sha256':framed_hash(),'example':{'case':c,'expected':e,'answer':answer,'accepted':accepted,'error':error},'equivalent_cases':[],'invalid_scalars':[]}
if a.stage=='before':
    assert not accepted,'Pre-fix reproducer should fail'
else:
    assert accepted,'Valid exact rational basis still rejected'
    oracle=json.loads((REPORTS/'discrimination_v014.json').read_text())['programs']['oracle']
    for case,expected in [v for b in suite() for v in b]:
        result=deepcopy(oracle[case['id']]['output'])
        def encode(v):
            f=F(v);return str(f.numerator)+'/+'+str(f.denominator)
        result['smith_factors']=[[encode(v) for v in p] for p in result['smith_factors']]
        for key in ('right_basis','left_basis'):
            result[key]=[[[encode(v) for v in vector] for vector in cert] for cert in result[key]]
        verify(case,expected,result)
        report['equivalent_cases'].append({'id':case['id'],'status':'PASS'})
    for bad in ['1/0','1/+0','1/-2','1/++2','1.0','NaN','inf','1/2/3',True,False,0.5,None]:
        try:scalar(bad)
        except (AssertionError,ValueError,TypeError,ZeroDivisionError):report['invalid_scalars'].append({'input':bad,'rejected':True})
        else:raise AssertionError('invalid scalar accepted: '+repr(bad))
report['success']=True
dump(REPORTS/f'rational_spelling_{a.stage}.json',report)
print(a.stage,'valid example accepted:',accepted,'equivalent cases:',len(report['equivalent_cases']),'invalid rejections:',len(report['invalid_scalars']))
