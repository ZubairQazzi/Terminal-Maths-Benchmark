"""Assemble reports from measured local evidence; never call a model provider."""
from collections import Counter
import json
import argparse
from pathlib import Path
import shutil
from qc_remediate import ROOT,TASK,REPORTS,dump,framed_hash,manifest

def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def runtime(revision='r3'):
    trials=[]
    for job in sorted((REPORTS/'harbor-jobs').glob('qc-v014-'+revision+'-*')):
        for path in sorted(job.glob('*/result.json')):
            d=load(path)
            if d.get('finished_at') is None:continue
            ctrf=load(path.parent/'verifier/ctrf.json')['results']
            summary=ctrf['summary'];reward=d['verifier_result']['rewards']['reward']
            assert d['exception_info'] is None and d['verifier_environment_mode']=='separate'
            assert summary['tests']==10 and len(ctrf['tests'])==10
            assert summary.get('skipped',0)==0 and summary['passed']+summary['failed']==10
            assert len(set(t['name'] for t in ctrf['tests']))==10
            kind=job.name.rsplit('-',1)[1]
            expected={'oracle':(1,10),'helper':(1,10),'rational':(1,10),'nop':(0,0),'partial':(0,1),'trivial':(0,1),'hardcoded':(0,0)}[kind]
            assert (reward,summary['passed'])==expected,(job.name,reward,summary)
            assert (path.parent/'verifier/reward.txt').read_text().strip() in {'0','1'}
            trials.append({'job':job.name,'trial':d['trial_name'],'reward':reward,'passed':summary['passed'],'failed':summary['failed'],'tests':10,'exception':None,'task_checksum':d['task_checksum'],'started_at':d['started_at'],'finished_at':d['finished_at'],'result':str(path.relative_to(ROOT)),'ctrf':str((path.parent/'verifier/ctrf.json').relative_to(ROOT))})
    pre=[t for t in trials if '-pre-review-' in t['job']]
    assert len(pre)==7,'Pre-review native validation incomplete: '+str(len(pre))
    post=[t for t in trials if '-post-review-' in t['job']]
    assert len({t['task_checksum'] for t in trials})==1,'Mixed task versions; do not pool'
    for name in ('clean-agent-build','clean-verifier-build'):
        d=load(REPORTS/'history/qc-v014-r1'/f'{name}.command.json');assert d['exit_code']==0 and '--no-cache' in d['arguments']
    for name in ('cached-agent-build-'+revision,'cached-verifier-build-'+revision):
        assert load(REPORTS/'qc-v014'/f'{name}.command.json')['exit_code']==0
    assert load(REPORTS/'isolation_probe_v014.json')['success'] and load(REPORTS/'agent_leakage_probe_v014.json')['success']
    local=load(REPORTS/'local_validation_v014.json');assert local['success']
    post_local_path=REPORTS/'local_validation_v014_post_review.json'
    post_local=load(post_local_path) if post_local_path.exists() else None
    if post_local is not None:
        assert post_local['success'] and post_local['task_sha256']==framed_hash()
    disc=load(REPORTS/'discrimination_v014.json');assert disc['success'] and disc['task_sha256']==framed_hash()
    snapshot=load(ROOT/'authoring/provenance/qc_v013_snapshot.json')
    unchanged=['solution/solve.py','solution/solve.sh','tests/test.sh','tests/test_outputs.py','environment/Dockerfile','tests/Dockerfile','environment/requirements.txt','tests/requirements.txt','environment/data/examples.json']
    from qc_remediate import sha
    assert all(sha((TASK/p).read_bytes())==snapshot['files'][p]['sha256'] for p in unchanged)
    dump(REPORTS/'qc-v014/runtime_summary.json',{'task_version':'0.1.4','framed_sha256':framed_hash(),'native_checksum':trials[0]['task_checksum'],'trials':trials,'pre_review_native_trials':len(pre),'post_review_native_trials':len(post),'post_review_native_complete':len(post)==7,'post_review_portable_complete':bool(post_local and post_local['success']),'unchanged_core_files':unchanged,'portable_checks':len(local['results']),'portable_seconds':local['seconds'],'post_review_portable_seconds':post_local['seconds'] if post_local else None,'matrix_audit_seconds':disc['seconds'],'build_evidence':{'initial_clean_same_dockerfiles':'PASS; history/qc-v014-r1','final_source_cached_build':'PASS','redundant_final_no_cache_attempt':'network interruption; preserve qc-v014/r2-build-console.log'}})
    old=REPORTS/'harbor_validation.md';archive=REPORTS/'history/harbor_validation_v013.md'
    if not archive.exists():archive.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old,archive)
    lines=['# Measured local Harbor validation — v0.1.4','', 'Task framing SHA-256: `'+framed_hash()+'`. Native Harbor checksum: `'+trials[0]['task_checksum']+'`. These are distinct hash schemes. All listed trials have ten distinct CTRF tests, separate offline verifier mode, matching task checksum, no exceptions and expected literal binary reward.','', '| Job | Trial | Reward | Tests passed | Exceptions |','|---|---|---:|---:|---:|']
    lines += [f"| {t['job']} | {t['trial']} | {t['reward']} | {t['passed']}/10 | 0 |" for t in trials]
    lines += ['', 'Each oracle trial checks all 40 pencils. No-op submits nothing. Trivial recovers only zero/scalar conventions; the public-example hardcoder knows no hidden instances; finite-only partial omits infinity and minimal bases. Their reward zero is the expected correct rejection, not a broken infrastructure failure. The helper oracle exercises a valid executable supporting source layout and earns full credit. These are deterministic author controls, not independent AI attempts.','',
              f"Portable regression: {len(local['results'])} checks PASS in {local['seconds']:.3f}s; independent matrix/discrimination audit PASS in {disc['seconds']:.3f}s. Portable flags remain honestly separate from Linux validation. Per-case results: test_discrimination_audit.md / discrimination_v014.json.",'',
              '## Clean builds, isolation and provenance','',
              f'Initial agent and verifier builds used --no-cache --pull against the pinned base digest and actually executed dependency installs; successful logs remain in history/qc-v014-r1. Dockerfiles, base and pins are unchanged by later contract corrections. A redundant r2 no-cache attempt encountered Network is unreachable during pip; this is a build-infrastructure interruption, not a mathematical failure. An r2 network-none source build also failed because that flag invalidates the dependency RUN cache key. Final source builds with the default cache key succeeded using the same installed dependency layers and rebuilt the verifier COPY containing the corrected checker/harness. Current successful logs: cached-*-build-{revision}.*; failed intermediate attempt: source-agent-build-r2.* and r2-build-console.log. Native final-hash trials validate the actual images. No host installation occurred. No successful final-revision no-cache dependency reinstall is claimed.','',
              'The real harness probe returns UID/GID 65534, no supplementary groups, denied hidden-test reads, denied reward and copied-source writes, no oracle file, and no API key variables. CPU/address-space/descriptor limits match the spec. Agent-image enumeration contains only /app/spec.md and /app/data/examples.json as application files. Probes use --network none; the task verifier declares no-network. This is measured protection of private files and score paths; it is not a claim that a shared-UID child subprocess design provides a separate per-batch kernel sandbox.','',
              'All original36 generated inputs and expectations are preserved exactly. The reference solver, shell tests, package pins and Dockerfiles are byte-identical to v0.1.3. The hidden-suite change appends four justified structural cases and identifies controls. Later independent contract audits corrected three parsing defects: positive +q denominators normalize via integer components; finite floats in ignored extra result fields parse normally while scientific fields retain exact type/value checks; the implicit4300-digit conversion cap is disabled for contract-valid arbitrary-precision output integers/rationals, within the existing16MiB output cap. Isolation/resource limits and every mathematical identity/invariant comparison are unchanged. Before/after full-submission reproductions and malformed/exact-type rejections are retained in rational_spelling_*.json and json_contract_*.json. Source snapshots of original and intermediate r1/r2 revisions are preserved.','',
              'Harbor logs include nonfatal image-OS-inspection warnings; builds, all expected grading outcomes, recorded separate mode and completed trial results establish actual execution. No such warning is counted as a valid AI failure.','',
              '## Reproduction and raw evidence','',
              'From F:/rl/math-benchmark:','', '```powershell',r'& .\authoring\evidence\run_qc_validation.ps1 -Phase build',r'& .\authoring\evidence\run_qc_validation.ps1 -Phase pre-review',r'& .\authoring\evidence\run_qc_validation.ps1 -Phase post-review','```','',
              'Use fresh job names on a later reproduction to preserve evidence. Exact native executable paths, all argument arrays, UTC timestamps and exit codes are saved in qc-v014/*.command.json. Raw native config/result/lock/agent/artifact/verifier logs remain under harbor-jobs/qc-v014-*. No upload/publish command was executed. qc-v014/runtime_summary.json indexes every trial and CTRF file. Earlier v0.1.3 evidence remains in history/harbor_validation_v013.md and its original job directories.','',
              'AI calibration remains incomplete: the latest retained Gemini smoke summary has zero valid graded trials, one infrastructure interruption, no meaningful success percentage. That historical v0.1.3 provider failure is not an evaluation of v0.1.4. No new model API calls were made during QC remediation. Original external QC is NOT RUN.','']
    if len(post)==7:
        assert post_local is not None and post_local['success']
        assert load(REPORTS/'isolation_probe_v014_post_review.json')['success'] and load(REPORTS/'agent_leakage_probe_v014_post_review.json')['success']
        lines += ['## Final post-review regression','',f"Completed seven new native trials after the independent source review: two oracle repeats, four negative baselines and a valid general oracle using a regular source helper in __pycache__, p/+q spellings,5001-digit rational/JSON-integer basis coefficients and ignored finite diagnostic floats. All expected rewards/tests agree on the same final checksum; the combined valid-contract control passes10/10 in real Linux grading. Repeated portable suite: {len(post_local['results'])} checks PASS in {post_local['seconds']:.3f}s. Separate post-review real-harness isolation, root-symlink rejection and agent-leakage probes PASS; native all-rule lint again returns []. See *_post_review.json and qc-v014-{revision}-post-review-* for preserved raw results. These final runs do not add any valid model-calibration trials.",'']
    old.write_text('\n'.join(lines),encoding='utf-8')
    manifest()
    return trials

def rubric():
    req=load(REPORTS/'qc_requirements.json');run=load(REPORTS/'qc-v014/runtime_summary.json')
    reasons={
      'well_specified':'instruction.md and authoritative spec define entry point, IO schemas, rational encodings, polynomial order, complete invariants, basis conventions and execution limits.',
      'test_instruction_alignment':'All scored structures/identities, exact types, sizes and source-execution constraints are public; input matrices stay within declared bounds. Four additions change coverage within existing contract.',
      'instruction_clarity':'Verifier trust and binary reward narration removed from instruction/spec; obligations are stated as outcomes. No solver algorithm or hidden expected answer is supplied.',
      'structured_data_schema':'RESULT fields, lengths, scalar types, coefficient ordering and degree conventions match certificates.py and harness JSON/ID validation; malformed-output controls reject.',
      'typos':'All absolute task paths and module/command references inspected; successful native entry-point execution and helper submission demonstrate usable paths.',
      'hint_discoverability':'No optional author hint file is supplied. The three public examples and specification are solver-visible conventions; classical domain knowledge is allowed.',
      'scientifically_grounded':'Kronecker/Smith structure classifies finite dynamics, algebraic constraints and free polynomial directions of differential-algebraic systems. Classical theory and primary references are documented in authoring/math_research_review.md.',
      'scope':'Exact polynomial spectral/module algebra fits mathematical-sciences/applied-mathematics; there is no unrelated training or scientific-data objective.',
      'essential_difficulty':'Challenge is joint recovery of repeated finite factors, reversed valuations and both minimal polynomial bases with exact scaling. Precision is required by algebraic identities, not an arbitrary numerical tolerance.',
      'novel':'Inputs are locally generated and require computation; no prior answer array or reference-task implementation is used. Historical browser sample is limited and predates wording changes; global originality/full pinned-corpus similarity remains unverified.',
      'agentic':'Implementing and debugging exact structure/certificate recovery calls for terminal computation and validation across distinct algebraic regimes, rather than copying a static answer.',
      'verifiable':'Independent Fraction checker observes all expected invariants and certificate identities. Real oracle, no-op, partial, trivial and example-only programs produce distinct correct outcomes.',
      'solvable':'Two clean native oracle repeats pass all ten tests/all forty pencils within the declared resource and per-invocation limits. General input-based solver is unchanged.',
      'outcome_verified':'Forty rationally rescaled/unimodularly mixed valid bases pass the checker; native executable-helper variant passes all tests. No basis normalization or source-content match is imposed.',
      'functional_verification':'Harness executes submitted code and checks emitted mathematical objects, not success flags, filenames alone or implementation keywords. Eight targeted corruptions reject.',
      'ground_truth_provenance':'Canonical finite/infinite/singular blocks plus invertible constant transformations derive expectations independently from the SymPy oracle. Exact sampled ranks and kernel-nullity differences independently agree on all forty inputs.',
      'graded_instances_discriminate':'Six controls explicitly disclosed; thirty-four structural cases separately counted (four related metamorphs). Trivial 6/40 and example hardcoder 3/40 each pass zero structural cases; finite-only partial passes 4/34 structural cases but earns no full reward.',
      'solution_quality':'Unchanged general reference derives Smith forms and degree-filtration generators from input matrices, validates identities/index sum, and never accesses hidden expectations.',
      'do_not_modify_enforced':'No additional immutable input-file obligation is imposed. The documented read-only copied program directory is actually enforced; real harness source-write probe returns DENIED. Private grader/log paths are protected.',
      'deterministic_reproducible':'Fixed suite seed, exact arithmetic, freshly regenerated identical matrices, same-checksum oracle repeats and independent clean container resets produce expected scores. Explicit top-level package pins and immutable base; transitive pytest dependencies are not fully locked.',
      'separate_verifier_configured':'Actual native result records separate verifier mode; tests/Dockerfile bakes grader dependencies; only /app/submission transfers. Both images share the stated Python/SymPy versions.',
      'verifier_execution_isolation':'Real harness probe confirms nobody UID/GID, empty groups, private-test/reward/source writes denied, sanitized environment, no oracle, resource limits. Offline container; shared child UID is a bounded design limitation, not asserted per-batch kernel isolation.',
      'anti_cheat_robustness':'No-op, zero/scalar shortcut and public-example hardcoder earn zero reward; distinct finite/infinite partition tests and mixed singular cases defeat partial results. Private expectations are unavailable to candidates and reward writes denied.',
      'task_security':'No task host binds, credential forwarding, privileged container options or outbound grader network. Author probe mounts only its read-only source; no evaluated agent receives private materials.',
      'resource_configuration':'Both phases explicitly request 2 CPUs/4096 MiB/10240 MiB/zero GPUs. Actual oracle timing is well within the public 180s invocation and 3600s grader budgets.',
      'task_toml_schema':'Native Harbor TaskConfig validation plus all-rule lint pass; Standard publisher/name and complete user-approved author metadata are present. Unknown custom Local settings are not asserted.',
      'environment_hygiene':'Agent application-file probe sees only spec/examples; no private tests/reference; separate grader is offline, with pinned build-time packages and no trial-time installs.',
      'artifact_efficiency':'Only documented /app/submission transfers; native oracle/no-op controls show clean artifact collection without reusing previous answers. Temporary output paths are fresh for each invocation.',
      'ctrf_reporting':'Ten distinct test_exact_batch_00–09 names, ten CTRF entries and literal binary rewards are checked for every native trial; no parameter collapse.',
      'task_authoring_dir':'All review tooling, original inputs, research, baselines, private run evidence and reports reside at project-level authoring/ outside task build contexts. Exactly one task.toml exists under tasks/.',
      'no_extraneous_files':'Eighteen task files each serve manifest/instructions, images/data, reference or grading; no raw author logs, downloaded reference snapshots, caches or model trajectories are shipped in the task.',
      'reviewable':'Original source/matrix snapshots and hashes, complete current sources, exact per-case outputs/rejections, canonical construction and independent mathematical audit support tracing every expectation.',
      'difficulty_explanation_quality':'README explains singularity, repeated factors, exact rank and minimal-degree filtration, and explicitly distinguishes unmeasured time/difficulty claims from actual validation.',
      'solution_explanation_quality':'README matches the actual Smith/reversal/convolution-filtration reference implementation; mathematical research report explains identities and provenance.',
      'verification_explanation_quality':'README separates controls/structural/metamorphic counts, explains exact invariant/certificate checks and execution boundary; per-case and native baseline evidence is available.',
      'category_and_tags':'Directory taxonomy and descriptive mathematics/matrix-pencils/exact-arithmetic/minimal-bases/smith-form tags agree with delivered work.',
      'task_name':'certified-pencil-structure has three kebab-case tokens and accurately describes exact certified pencil analysis; full namespace matches folder.',
      'task_readme':'Managed metadata header updated from manifest; exactly three authored explanation sections with valid order/length and explicit non-discriminating controls. Historical changelog/logs moved to author reports.'
    }
    assert set(reasons)=={r['id'] for r in req['rubric']}
    rows=[{'id':r['id'],'status':'NOT APPLICABLE' if r['id']=='hint_discoverability' else 'WARNING' if r['id']=='novel' else 'PASS','evidence':reasons[r['id']]} for r in req['rubric']]
    for row,requirement in zip(rows,req['rubric']):
        row['requirement']=requirement['requirement']
        row['current_implementation']=row['evidence']
        row['required_correction']='Complete the unavailable pinned-corpus comparison; qualify scope rather than claim global novelty.' if row['status']=='WARNING' else 'None applicable.' if row['status']=='NOT APPLICABLE' else 'None identified locally; independent and external review verdicts remain separate.'
    report={'scope':'Creator checklist-based local rubric review; independent reviewer reports separately; not original external panel','task_sha256':framed_hash(),'checklist_sha256':req['source_sha256'],'counts':dict(Counter(r['status'] for r in rows)),'checks':rows}
    dump(REPORTS/'rubric_qc_audit.json',report)
    lines=['# Rubric QC audit — all 38 supplied criteria','',report['scope']+'.','', '**Counts:** '+str(report['counts'])+'. Scope and limitation notes are part of each verdict, not evidence of external acceptance.','', '| Check ID | Expected behavior | Local status | Current implementation and evidence | Required correction |','|---|---|---|---|---|']
    lines += [f"| `{r['id']}` | {r['requirement']} | {r['status']} | {r['evidence']} | {r['required_correction']} |" for r in rows]
    lines += ['', 'The 40–60% AI target remains unmeasured (zero valid new trials); difficulty estimates are not empirical results. Original external pipeline is NOT RUN. Full pinned-corpus similarity is unresolved. Independent human domain review has not occurred; the mandatory distinct AI QC review is separately documented when completed.','']
    (REPORTS/'rubric_qc_audit.md').write_text('\n'.join(lines),encoding='utf-8')
    print('Local rubric counts:',report['counts'])

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--revision',default='r3');args=parser.parse_args()
    runtime(args.revision);rubric()
