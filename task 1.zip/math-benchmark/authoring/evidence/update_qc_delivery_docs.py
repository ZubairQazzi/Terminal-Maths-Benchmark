"""Write current reproduction/status docs without altering task sources."""
import json
from pathlib import Path
import shutil
from qc_remediate import ROOT,REPORTS,TASK,framed_hash,dump

def main():
    source=ROOT/'REPRODUCING.md';archive=REPORTS/'history/REPRODUCING_v013.md'
    if not archive.exists():archive.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,archive)
    source.write_text(r'''# Reproduce v0.1.4 QC validation locally

Use the already-installed tools below. No host software installation or provider API call is needed. Existing validation job names are evidence: use new names in the PowerShell driver for a new reproduction rather than overwriting them. The current request prohibits commits, pushes, publication and hosted uploads.

```powershell
Set-Location -LiteralPath 'F:\rl\math-benchmark'
$taskPython = 'C:\Users\zubai\AppData\Local\Programs\Python\Python312\python.exe'
$harborPython = 'C:\Users\zubai\AppData\Roaming\uv\tools\harbor\Scripts\python.exe'
$env:PATH = 'C:\Users\zubai\AppData\Local\Programs\DockerDesktop\resources\bin;' + $env:PATH
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'

& .\authoring\evidence\run_qc_validation.ps1 -Phase build
& $taskPython -B .\authoring\evidence\audit_discrimination.py
& $taskPython -B .\authoring\evidence\validate_local.py --output .\authoring\reports\local_validation_v014.json
& $taskPython -B .\authoring\evidence\run_qc_probes.py
& .\authoring\evidence\run_qc_validation.ps1 -Phase pre-review
& $harborPython -B .\authoring\evidence\qc_static_audit.py
& $taskPython -B .\authoring\evidence\qc_build_reports.py
```

After the independent review, perform the final regression stage:

```powershell
& .\authoring\evidence\run_qc_validation.ps1 -Phase post-review
& $taskPython -B .\authoring\evidence\run_qc_probes.py --stage post-review
& $taskPython -B .\authoring\evidence\validate_local.py --output .\authoring\reports\local_validation_v014_post_review.json
& $harborPython -B .\authoring\evidence\qc_static_audit.py
& $taskPython -B .\authoring\evidence\qc_build_reports.py
```

The build phase uses `docker build --no-cache --pull` separately for environment/ and tests/ and requires build-time Internet access. Initial clean builds passed with the same Dockerfiles/pins. A later redundant no-cache attempt hit a network outage; the final corrected source built successfully using already validated dependency layers with `-Phase source-build -Revision r3`. Its COPY stage incorporates the corrected checker/harness. Native final evidence uses r3 job names; earlier r1/r2 results belong to different hashes and are not pooled. Each job uses n-concurrent1; the final two author-validation stages overlapped after the independent source/Linux sweep completed, in separate fresh containers. Pre-review additionally checks an executable helper; post-review checks a valid general oracle with cache-directory source, p/+q spellings,5001-digit coefficients and unused diagnostic floats. Every exact command and raw output is retained. The reviewer is a distinct fresh-context agent, not a script or a second creator pass.

Native job outputs are under authoring/reports/harbor-jobs/qc-v014-*/. Each trial has original result/config/lock, artifact source and verifier CTRF/reward/pytest evidence. authoring/reports/qc-v014/runtime_summary.json indexes completed trials. Exact per-case outputs/rejection reasons and coefficient-matrix nullities are in discrimination_v014.json. Scripts fail on mismatches and never rewrite runtime task files.

Do not rerun `qc_remediate.py prepare`: it intentionally refuses to overwrite the original before-state. `qc_remediate.py header` only regenerates the task README header from its manifest and would require rerunning validation if it changed the task hash. Historical v0.1.3 reproduction instructions remain in authoring/reports/history/REPRODUCING_v013.md; old model runners and old 40-item audit scripts are historical, not current QC commands.

The original external QC runner/profile and pinned main/lite corpus revisions are unavailable. To finish that validation, submit this local task plus the supplied checklist and current evidence directory through the original QC system, request the same active profile and a full 67-check rerun, and retain its actual verdict/citations. No external submission has been made here. The required full-corpus instruction comparison is not replaced by native Harbor lint or the historical 12-document browser sample.

No valid eight-trial AI calibration exists. Historical Gemini HTTP/API interruptions remain excluded; do not reuse their raw reward zero as mathematical failures or pool old task versions. A future explicitly authorized reliable model run must use a new smoke test followed by eight independent fresh trials of one fixed task hash/model/agent configuration. No paid API fallback is authorized.
''',encoding='utf-8')
    run=json.loads((REPORTS/'qc-v014/runtime_summary.json').read_text())
    lines=['# QC remediation — v0.1.4','',
           'Task: **Certified Kronecker Structure of Singular Matrix Pencils**. Original external findings: **2**, each confirmed by three judges. This remediation changes the existing task only. Governing requirement source: the supplied 29-static/38-rubric checklist and remediation brief; copies/hashes are retained under qc_remediation_inputs/.','',
           '## Changes and reasons','',
           '- `instruction.md` and `environment/spec.md`: replace verifier-trust/reward narration with mathematical and execution obligations. All scalar types, identities, degree/basis requirements, file paths, allowed packages and limits are retained.','- `tests/cases.py`: identify convention controls and append four mathematically distinct block combinations for repeated positive indices and a maximal right index in a mixed pencil. Preserve all original 36 inputs/expectations, including every challenging case.','- Task README: replace placeholder header with manifest-derived author/budget/resources; use exactly the three authored sections; disclose six non-discriminating controls and distinguish the 34 structural cases/four related metamorphs. Remove stale validation/provenance/changelog sections to project authoring records.','- `task.toml`: bump local version to 0.1.4 and complete user-authorized contributor metadata. No human credentials or human review are fabricated.','- Author-only tooling: add exact matrix/nullity audits, trivial/public-example baselines, clean-build/native-run drivers, real-harness isolation probes, complete 29/38 reports, original source snapshots and evidence indexes.','',
           '**Unchanged core:** reference solution, test shell, batch entrypoint, dependency pins, Dockerfiles and public examples match original v0.1.3 hashes. Five confirmed contract defects were corrected: positive +q rational parsing, ignored diagnostic floats, the implicit4300-digit exact-integer conversion cap, submission-root symlink detection and silently discarded regular source in cache-named directories. Exact mathematical comparisons, all execution resources and UID/permission boundaries remain intact. Before/after full-submission probes and independent Linux rechecks establish each correction; malformed scientific fields still reject. No hard case was removed and no change was based on AI outcomes.','',
           '## Measured validation','',
           '- Initial clean no-cache agent/verifier builds: PASS on unchanged Dockerfiles/base/pins; later redundant final no-cache attempt interrupted by network loss. Final corrected-source builds: PASS using existing dependency layers; fresh native results validate that exact source.','- Fresh native oracle repeats: reward 1, 10/10 tests each, all forty pencils.','- Valid executable source-helper layout: reward 1, 10/10 tests.','- Native no-op, finite-only partial, trivial zero/scalar solver and public-example hardcoder: expected reward 0, no infrastructure exception.','- Actual per-case oracle 40/40; trivial 6/40 (0/34 structural); hardcoder 3/40 (0/34 structural); partial 6/40 (4/34 structural).','- All forty sampled-rank/kernel-nullity checks and alternate valid basis checks pass; original 36 generated inputs/expectations agree exactly.','- Real harness isolation and agent-image leakage probes: PASS.','- Native all-rule Harbor lint: empty findings array. Local static 28 PASS/1 NOT TESTED; creator rubric 36 PASS/1 WARNING/1 NOT APPLICABLE, subject to distinct review.','',
           'See harbor_validation.md, test_discrimination_audit.md, static_qc_audit.md and rubric_qc_audit.md for item-level evidence. Exact native commands and logs remain under qc-v014/; raw task/trial evidence remains under harbor-jobs/. Reproduction commands are in project-root REPRODUCING.md.','',
           '## Independent review and final regression','',
           'The mandatory reviewer has been launched as /root/independent_qc with fork_turns=none. It must record initial findings before reading creator explanations, independently evaluate all 67 supplied criteria, then recheck corrections and final regression evidence. See independent_qc_initial.json, independent_qc_review.md and independent_qc_findings.json for its actual results. The final post-review regression is recorded separately and must finish before final status.','',
           '## Originality and integrity','',
           'The objective is classical mathematics, not a new theorem. Inputs are newly constructed exact algebraic instances; expected structure is derived from canonical blocks, while the reference computes from mixed matrices. Primary mathematical references and source comparisons remain in authoring/math_research_review.md and reference_analysis.md. The original supplied scientific data files are not required by this synthetic pencil benchmark. No public benchmark answer or reference solution has been copied. Global novelty is not proven: the historical 12-document browser-only similarity sample predates instruction edits and is not the required pinned-corpus comparison.','',
           '## Unresolved external requirements','',
           '1. **Full pinned main/lite instruction-similarity check: NOT TESTED.** The user confirmed that only the supplied QC documents are available; exact corpus revisions/runner/profile were not supplied.','2. **Original external QC: NOT RUN.** Local checks and the distinct AI reviewer are not the original three-judge panel. Submit the corrected local package/evidence to that system for a full 67-check rerun; no publication is needed to keep these local results.','3. **AI difficulty calibration: incomplete.** Latest historical v0.1.3 smoke summary records zero valid graded trials and an infrastructure interruption. No new provider call, eight-trial sample or 40–60% result is claimed.','4. Independent human domain review and expert-time estimates remain unverified; contributor fields explicitly avoid implying otherwise.','',
           'Until the required unresolved comparison/external decisions and independent review/regression status are settled, do not call the task perfect or claim all QC passed. All files remain local; no Git commit/push/publication or model-provider spending occurred during this remediation.','']
    (REPORTS/'qc_remediation.md').write_text('\n'.join(lines),encoding='utf-8')

if __name__=='__main__':main()
