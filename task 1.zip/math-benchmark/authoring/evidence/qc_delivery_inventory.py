"""Record only this remediation's local files; never print secret contents."""
from pathlib import Path
import json
import re
import subprocess
from qc_remediate import ROOT,TASK,REPORTS,sha,framed_hash,dump,files

def main():
    before=json.loads((ROOT/'authoring/provenance/qc_v013_snapshot.json').read_text(encoding='utf-8'))['files']
    changed=[];unchanged=[]
    for p in files():
        rel=p.relative_to(TASK).as_posix();old=before.get(rel,{}).get('sha256');now=sha(p.read_bytes())
        (changed if old!=now else unchanged).append({'path':str(p),'relative':rel,'before':old,'after':now})
    raw=subprocess.run(['git','status','--porcelain=v1','--untracked-files=all'],cwd=ROOT,capture_output=True,text=True,check=True).stdout
    scoped=[]
    for line in raw.splitlines():
        relative=line[3:].strip('"')
        if relative.startswith(('authoring/','tasks/')) or relative in {'README.md','REPRODUCING.md'}:
            scoped.append({'status':line[:2],'path':relative})
    # This is a pattern scan of local task/new author sources only, not account
    # credential storage. Report paths/counts, never matched values.
    patterns=[r'AIza[0-9A-Za-z_-]{30,}',r'gh[pousr]_[A-Za-z0-9]{25,}',r'github_pat_[A-Za-z0-9_]{30,}',r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
    checked=list(files())+[ROOT/r['path'] for r in scoped if (ROOT/r['path']).is_file() and (ROOT/r['path']).suffix in {'.py','.ps1','.md','.toml','.json','.log','.txt'}]
    hits=[]
    for p in set(checked):
        if any(re.search(pattern,p.read_text(encoding='utf-8',errors='replace')) for pattern in patterns):hits.append(str(p))
    report={'task_sha256':framed_hash(),'task_files_changed':changed,'task_files_unchanged':unchanged,'scoped_local_change_inventory':scoped,'unrelated_paths_excluded':True,'secret_pattern_scan':{'files':len(set(checked)),'hits':len(hits),'paths':hits,'scope':'Task files and remediation-modified/new author text only; no credential stores read; not a formal security audit'}}
    dump(REPORTS/'qc-v014/delivery_inventory.json',report)
    lines=['# Local remediation file inventory','',f"Runtime task: {len(changed)} files changed, {len(unchanged)} byte-identical to v0.1.3. No Git commit/push. Unrelated concurrent workspace files are excluded and left untouched.",'', '| Changed task file | Before SHA-256 | After SHA-256 |','|---|---|---|']
    lines += [f"| {r['relative']} | {r['before']} | {r['after']} |" for r in changed]
    lines += ['', '## Supporting files and evidence','', 'This machine inventory lists all scoped modified/new files, including raw per-trial evidence; the JSON is authoritative for the complete path list. It is captured from read-only git status, not a commit.','']
    lines += [f"- `{r['status']}` `{r['path']}`" for r in scoped if not r['path'].startswith('authoring/reports/harbor-jobs/')]
    lines += ['',f"Secret-format pattern scan: {len(hits)} hit(s) across {len(set(checked))} scoped text files. No matched contents are emitted. This bounded scan does not read credential stores or prove absence of every possible secret.",'']
    (REPORTS/'qc-v014/delivery_inventory.md').write_text('\n'.join(lines),encoding='utf-8')
    print('Changed Task files:',len(changed),'unchanged:',len(unchanged),'scoped secret hits:',len(hits))
    assert not hits

if __name__=='__main__':main()
