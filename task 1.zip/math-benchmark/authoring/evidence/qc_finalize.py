"""Finalize evidence-based local status only after reviewer/native closure."""
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
from qc_remediate import ROOT,TASK,REPORTS,framed_hash,dump

def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def main():
    review=load(REPORTS/'independent_qc_findings.json')
    run=load(REPORTS/'qc-v014/runtime_summary.json')
    static=load(REPORTS/'static_qc_audit.json');rubric=load(REPORTS/'rubric_qc_audit.json')
    requirements=load(REPORTS/'qc_requirements.json')
    assert review['task']['framed_sha256']==run['framed_sha256']==static['task_sha256']==rubric['task_sha256']==framed_hash()
    assert run['post_review_native_complete'] and run['post_review_native_trials']==7 and len(run['trials'])==14
    assert review['post_review_regression']['status']=='PASS','Independent final native recheck pending'
    for kind,creator in [('static',static),('rubric',rubric)]:
        rows=[r for r in review['checks'] if r['kind']==kind]
        assert {r['id'] for r in rows}=={r['id'] for r in requirements[kind]}
        assert Counter(r['status'] for r in rows)==Counter(r['status'] for r in creator['checks'])
    assert not any(c['status']=='FAIL' for c in review['checks'])
    parser=[r for r in review['corrections_and_rechecks'] if r['id']=='IQC-011'][0]
    assert parser['final_status']=='PASS','Parser correction not independently closed'
    for issue in ('IQC-013','IQC-014','IQC-015','IQC-016'):
        assert next(r for r in review['corrections_and_rechecks'] if r['id']==issue)['final_status']=='PASS',issue+' not independently closed'
    status={'generated_utc':datetime.now(timezone.utc).isoformat(),'task_title':'Certified Kronecker Structure of Singular Matrix Pencils','task_version':'0.1.4','harbor_task_checksum':run['native_checksum'],'author_framed_sha256':framed_hash(),'local_only':True,'previous_external_qc_failures':2,'previous_failures_corrected_locally':2,'additional_scalar_parser_defect_corrected':True,'static_qc':static['counts'],'rubric_qc':rubric['counts'],'independent_qc':'Completed; all67 individually reviewed in a distinct fresh context, with final native recheck','independent_artifacts':['authoring/reports/independent_qc_review.md','authoring/reports/independent_qc_findings.json'],'oracle':'PASS','negative_controls':'PASS (all expected reward0)','docker_harbor':'PASS current source builds/native grading; redundant final no-cache retry interrupted by network outage','native_validations_final_hash':14,'oracle_repeats_final_hash':4,'pencils_per_oracle':40,'controls':6,'structural_cases':34,'binary_batch_tests':10,'external_qc':'NOT RUN','calibration_complete':False,'requested_valid_calibration_trials':8,'completed_valid_calibration_trials':0,'observed_success_percentage':None,'target_40_to_60_percent':'NOT DETERMINED','all_required_qc_verified':False,'overall_status':'NEEDS FURTHER WORK','remaining_work':['Run required instruction similarity against the original pinned main/lite collections.','Obtain an actual full67-check verdict from the original external QC system.','Complete consistent eight-valid-trial AI calibration; historical API interruptions do not count.','Global originality, human domain review and expert-time estimates remain unverified.','Repeat final no-cache dependency reinstall when network access recovers, if required by the external validator; same-Dockerfile initial clean builds and final cached-source/native validation are retained.']}
    old=REPORTS/'final_delivery_status.json';archive=REPORTS/'history/final_delivery_status_v013.json'
    if not archive.exists():shutil.copyfile(old,archive)
    dump(old,status);dump(REPORTS/'qc-v014/final_status.json',status)
    path=REPORTS/'qc_remediation.md';text=path.read_text(encoding='utf-8')
    oldparagraph='The mandatory reviewer has been launched as /root/independent_qc with fork_turns=none. It must record initial findings before reading creator explanations, independently evaluate all 67 supplied criteria, then recheck corrections and final regression evidence. See independent_qc_initial.json, independent_qc_review.md and independent_qc_findings.json for its actual results. The final post-review regression is recorded separately and must finish before final status.'
    newparagraph='The mandatory distinct reviewer /root/independent_qc used fork_turns=none, recorded initial findings before reading creator explanations, independently evaluated all67 supplied criteria and rechecked corrections. Its separate integer elimination reproduced all40 ranks and both kernel-nullity sequences; its certificate, baseline, alternative-basis and rational-encoding checks agree. All confirmed task/documentation defects are closed on independent evidence, including IQC-011 after actual final-hash Linux grading. Final regression comprises14 native trials on one checksum: four oracle repeats, eight expected-failing negative controls, one executable helper and one equivalent-rational oracle. Every CTRF file has ten distinct results; all trials have expected reward and zero exceptions. Post-review portable23 checks and both isolation probes pass. See independent_qc_initial.json, independent_qc_review.md, independent_qc_findings.json and qc-v014/runtime_summary.json. The independent review is complete; its overall QC verdict remains incomplete because the mandatory pinned-corpus comparison is unavailable.'
    assert oldparagraph in text
    text=text.replace(oldparagraph,newparagraph)
    text=text.replace('subject to distinct review.','confirmed by the distinct reviewer within the documented local scope.')
    text=text.replace('Until the required unresolved comparison/external decisions and independent review/regression status are settled, do not call the task perfect or claim all QC passed.','The independent review and final regression are complete. The required full-corpus comparison and external decision are unresolved, so do not call the task perfect or claim all QC passed.')
    text += '\n## Final evidence-based summary\n\n'
    rows=[('Task',status['task_title']+' v0.1.4'),('Previous QC failures','2; both locally corrected and independently rechecked'),('Static QC','28/29 PASS; 1 NOT TESTED (required pinned-corpus comparison)'),('Rubric QC','36/38 PASS; 1 WARNING (novelty scope); 1 NOT APPLICABLE (no optional hints)'),('Independent QC','Completed; distinct fresh context, all67 criteria and final native rechecks'),('Oracle','PASS; four fresh final-hash repeats,40/40 pencils each'),('Negative controls','PASS; expected reward0 in all eight final-hash negative trials'),('Docker/Harbor',status['docker_harbor']),('External QC','NOT RUN'),('AI calibration','0/8 valid trials;40–60% target NOT DETERMINED'),('Final verdict','NEEDS FURTHER WORK: required external comparison/clearance and empirical calibration unresolved')]
    text += '| Item | Actual status |\n|---|---|\n'+'\n'.join('| '+k+' | '+v+' |' for k,v in rows)+'\n\nComplete local modified/supporting-file inventory: qc-v014/delivery_inventory.md/json. Final machine status: final_delivery_status.json and qc-v014/final_status.json. No commit, push, upload or model API call occurred during remediation.\n'
    path.write_text(text,encoding='utf-8')
    readme=ROOT/'README.md';r=readme.read_text(encoding='utf-8')
    r += '\nFinal local QC review: both prior findings and a subsequently reproduced rational-parser defect are corrected and independently rechecked. All14 final-hash native validations have expected outcomes. Local criteria:28/29 static PASS,36/38 rubric PASS (one N/A, one novelty warning). Overall **NEEDS FURTHER WORK** because required full-corpus similarity/external QC and eight-trial difficulty calibration remain unresolved. See [final status](authoring/reports/final_delivery_status.json).\n'
    readme.write_text(r,encoding='utf-8')
    print('Finalized local status:',status['overall_status'])

if __name__=='__main__':main()
