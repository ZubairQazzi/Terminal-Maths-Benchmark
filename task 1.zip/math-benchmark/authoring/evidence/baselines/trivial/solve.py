"""Author-only shortcut: zero/scalar conventions; guess zero otherwise."""
from fractions import Fraction
import json
import sys

def solve(case):
    A,B=case['A'],case['B']; m,n=len(A),len(A[0])
    out={'id':case['id'],'normal_rank':0,'smith_factors':[], 'infinite_sizes':[],
         'right_indices':[0]*n,'left_indices':[0]*m,
         'right_basis':[[[int(i==j) for i in range(n)]] for j in range(n)],
         'left_basis':[[[int(i==j) for i in range(m)]] for j in range(m)]}
    if m==n==1 and (A[0][0] or B[0][0]):
        a,b=A[0][0],B[0][0]
        out.update(normal_rank=1,smith_factors=[[str(-Fraction(a,b)),1]] if b else [[1]],
                   infinite_sizes=[] if b else [1], right_indices=[],left_indices=[],right_basis=[],left_basis=[])
    return out

if __name__=='__main__':
    data=json.load(open(sys.argv[1])); json.dump({'cases':[solve(c) for c in data['cases']]},open(sys.argv[2],'w'))
