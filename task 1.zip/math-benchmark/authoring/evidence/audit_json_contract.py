"""Full-submission JSON contract regressions, not source-matching tests."""
from copy import deepcopy
import argparse
import json
from pathlib import Path
import sys
import tempfile
from qc_remediate import TASK,REPORTS,framed_hash,dump
sys.path.insert(0,str(TASK/'tests'))
from harness import run_batch

parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['before','after']);a=parser.parse_args()
zero={'id':'zero','A':[[0]],'B':[[0]]};ze={'normal_rank':0,'smith_factors':[],'infinite_sizes':[],'right_indices':[0],'left_indices':[0]}
zr={'id':'zero',**ze,'right_basis':[[[1]]],'left_basis':[[[1]]]}
finite={'id':'finite','A':[[2]],'B':[[1]]};fe={'normal_rank':1,'smith_factors':[[-2,1]],'infinite_sizes':[],'right_indices':[],'left_indices':[]}
fr={'id':'finite',**fe,'right_basis':[],'left_basis':[]}
checks=[]
def check(name,case,expected,result,should_pass,raw=None):
    with tempfile.TemporaryDirectory(prefix='author-json-contract-') as d:
        data=raw if raw is not None else json.dumps({'cases':[result]})
        Path(d,'solve.py').write_text('import sys\nopen(sys.argv[2],"w").write('+repr(data)+')\n')
        try:run_batch(d,[(case,expected)],portable=True);passed=True;error=None
        except Exception as ex:passed=False;error=repr(ex)
    checks.append({'name':name,'expected_acceptance':should_pass,'accepted':passed,'error':error,'status':'PASS' if passed==should_pass else 'FAIL'})

for name,value in [('float',0.25),('bool',True),('null',None),('nested',[{'value':0.125}])]:
    r=deepcopy(zr);r['unused_diagnostic']=value
    check('ignored-extra-'+name,zero,ze,r,True)
for name,key,value in [('rank-float','normal_rank',0.0),('right-degree-float','right_indices',[0.0]),('left-degree-float','left_indices',[0.0]),('basis-float','right_basis',[[[1.0]]])]:
    r=deepcopy(zr);r[key]=value;check(name,zero,ze,r,False)
r=deepcopy(fr);r['smith_factors']=[[-2,1.0]];check('finite-factor-float',finite,fe,r,False)
for token in ('NaN','Infinity','-Infinity'):
    r=deepcopy(zr);r['unused_diagnostic']='PLACEHOLDER'
    raw=json.dumps({'cases':[r]}).replace('"PLACEHOLDER"',token)
    check('invalid-JSON-constant-'+token,zero,ze,r,False,raw)
huge='1'+'0'*5000
r=deepcopy(zr);r['right_basis']=[[[huge]]];check('valid-5001-digit-integer-string-basis',zero,ze,r,True)
r=deepcopy(zr)
raw=json.dumps({'cases':[r]}).replace('"right_basis": [[[1]]]','"right_basis": [[['+huge+']]]')
assert huge in raw
check('valid-5001-digit-JSON-integer-basis',zero,ze,r,True,raw)
report={'stage':a.stage,'kind':'portable full-submission execution, Linux proof separately','task_sha256':framed_hash(),'checks':checks,'counts':{s:sum(r['status']==s for r in checks) for s in ('PASS','FAIL')}}
dump(REPORTS/f'json_contract_{a.stage}.json',report)
print(a.stage,report['counts'])
if a.stage=='before':assert any(r['status']=='FAIL' for r in checks)
else:assert all(r['status']=='PASS' for r in checks)
