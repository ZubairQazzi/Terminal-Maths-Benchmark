"""Author-only general oracle with equivalent signed-denominator encoding."""
from fractions import Fraction
import json
from pathlib import Path
import subprocess
import sys
sys.set_int_max_str_digits(0)

subprocess.run([sys.executable,str(Path(__file__).parent/'__pycache__'/'source_helper.py'),sys.argv[1],sys.argv[2]],check=True)
path=Path(sys.argv[2]);result=json.loads(path.read_text())
def encode(value,scale=1):
    f=Fraction(value)*scale
    return str(f.numerator)+'/+'+str(f.denominator)
for case in result['cases']:
    case['smith_factors']=[[encode(v) for v in p] for p in case['smith_factors']]
    first_large=None
    for side in ('right_basis','left_basis'):
        original=case[side]
        for i,cert in enumerate(original):
            for j,vector in enumerate(cert):
                for k,v in enumerate(vector):
                    if first_large is None and Fraction(v):
                        f=Fraction(v)*10**5000
                        assert f.denominator==1
                        first_large=(side,i,j,k,f.numerator)
        case[side]=[[[encode(v,10**5000) for v in vector] for vector in cert] for cert in original]
    if first_large:
        side,i,j,k,value=first_large
        case[side][i][j][k]=value
    case['elapsed_seconds']=0.25
    case['unused_diagnostics']={'nested_float':0.125,'flag':True}
path.write_text(json.dumps(result))
