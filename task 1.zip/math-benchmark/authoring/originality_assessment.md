# Originality assessment

This task was newly authored in the local project using established matrix-pencil mathematics. Original contributions to the benchmark are its combined exact deliverable, input/output contract, independent known-structure evaluator, certificate acceptance rules, mixed instance families, and negative controls. This is not a claim of new canonical-form theory.

The three supplied benchmarks concern remote sensing, 3D microscopy, and computational fracture; their scientific problems and datasets are not reused. Engineering conventions (Harbor layout, canary, separate verification, reward path, pinned environments) are standard scaffolding and should be excluded from substantive copying judgments.

Research searches included the pencil/minimal-index topic combined with terminal-bench-science. No exact matching task was identified in the inspected results. Search absence does not prove global uniqueness. The standard Smith-form routine is used openly; it is not disguised as original code.

The implemented reproducible local audit process compares normalized exact lines, word n-grams, code-token structure, and documented conceptual overlap. The user declined a downloaded reference corpus. Therefore any browser-derived features must be labeled partial source coverage; no full-repository plagiarism audit or semantic-model score may be claimed. The requested 70% heuristic originality and 30% warning boundary are review aids, not proofs, and are reported only for the executed scope below.

Potential novelty risk: complete Kronecker analysis is a standard mathematical objective. The benchmark formulation and examples must be evaluated as a distinct research workflow rather than advertised as a new problem in linear algebra. Independent human mathematical review and empirical difficulty calibration remain outstanding.


Historical pre-remediation scoped audit: twelve browser-returned documents, maximum weighted similarity 3.818577%, heuristic originality 96.181423%. This clears the documented numerical review threshold only on that executed scope; it is not a new v0.1.4 comparison after instruction wording changed. Two silicon source windows are incomplete. Full-corpus clearance and a semantic embedding model were not performed. The related tensor-rank-toolkit was found after implementation and is acknowledged in reports/data_provenance.md; the canonical-form objective is classical, so low textual similarity does not establish conceptual uniqueness.

For v0.1.4, all original generated inputs and the reference implementation are preserved; four new structural cases and outcome-focused wording were added locally. Narrow parser/source-copy corrections restore the existing documented contract without changing mathematical checks; resource and execution isolation remain intact. The full required comparison against the external pipeline's pinned main/lite corpus remains NOT TESTED because the runner and exact revisions were not supplied. See reports/static_qc_audit.md and reports/qc_remediation.md. Do not present the historical percentage as current full-corpus or global originality clearance.
