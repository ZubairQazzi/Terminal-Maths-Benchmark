# Reproduce v0.1.4 QC validation locally

Use the already-installed tools below. No host software installation or provider API call is needed. Existing validation job names are evidence: use new names in the PowerShell driver for a new reproduction rather than overwriting them. The current request prohibits commits, pushes, publication and hosted uploads.

```powershell
Set-Location -LiteralPath 'F:\rl\math-benchmark'
$taskPython = 'C:\Users\zubai\AppData\Local\Programs\Python\Python312\python.exe'
$harborPython = 'C:\Users\zubai\AppData\Roaming\uv\tools\harbor\Scripts\python.exe'
$env:PATH = 'C:\Users\zubai\AppData\Local\Programs\DockerDesktop\resources\bin;' + $env:PATH
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'

& .\authoring\evidence\run_qc_validation.ps1 -Phase build
& $taskPython -B .\authoring\evidence\audit_discrimination.py
& $taskPython -B .\authoring\evidence\validate_local.py --output .\authoring\reports\local_validation_v014.json
& $taskPython -B .\authoring\evidence\run_qc_probes.py
& .\authoring\evidence\run_qc_validation.ps1 -Phase pre-review
& $harborPython -B .\authoring\evidence\qc_static_audit.py
& $taskPython -B .\authoring\evidence\qc_build_reports.py
```

After the independent review, perform the final regression stage:

```powershell
& .\authoring\evidence\run_qc_validation.ps1 -Phase post-review
& $taskPython -B .\authoring\evidence\run_qc_probes.py --stage post-review
& $taskPython -B .\authoring\evidence\validate_local.py --output .\authoring\reports\local_validation_v014_post_review.json
& $harborPython -B .\authoring\evidence\qc_static_audit.py
& $taskPython -B .\authoring\evidence\qc_build_reports.py
```

The build phase uses `docker build --no-cache --pull` separately for environment/ and tests/ and requires build-time Internet access. Initial clean builds passed with the same Dockerfiles/pins. A later redundant no-cache attempt hit a network outage; the final corrected source built successfully using already validated dependency layers with `-Phase source-build -Revision r3`. Its COPY stage incorporates the corrected checker/harness. Native final evidence uses r3 job names; earlier r1/r2 results belong to different hashes and are not pooled. Each job uses n-concurrent1; the final two author-validation stages overlapped after the independent source/Linux sweep completed, in separate fresh containers. Pre-review additionally checks an executable helper; post-review checks a valid general oracle with cache-directory source, p/+q spellings,5001-digit coefficients and unused diagnostic floats. Every exact command and raw output is retained. The reviewer is a distinct fresh-context agent, not a script or a second creator pass.

Native job outputs are under authoring/reports/harbor-jobs/qc-v014-*/. Each trial has original result/config/lock, artifact source and verifier CTRF/reward/pytest evidence. authoring/reports/qc-v014/runtime_summary.json indexes completed trials. Exact per-case outputs/rejection reasons and coefficient-matrix nullities are in discrimination_v014.json. Scripts fail on mismatches and never rewrite runtime task files.

Do not rerun `qc_remediate.py prepare`: it intentionally refuses to overwrite the original before-state. `qc_remediate.py header` only regenerates the task README header from its manifest and would require rerunning validation if it changed the task hash. Historical v0.1.3 reproduction instructions remain in authoring/reports/history/REPRODUCING_v013.md; old model runners and old 40-item audit scripts are historical, not current QC commands.

The original external QC runner/profile and pinned main/lite corpus revisions are unavailable. To finish that validation, submit this local task plus the supplied checklist and current evidence directory through the original QC system, request the same active profile and a full 67-check rerun, and retain its actual verdict/citations. No external submission has been made here. The required full-corpus instruction comparison is not replaced by native Harbor lint or the historical 12-document browser sample.

No valid eight-trial AI calibration exists. Historical Gemini HTTP/API interruptions remain excluded; do not reuse their raw reward zero as mathematical failures or pool old task versions. A future explicitly authorized reliable model run must use a new smoke test followed by eight independent fresh trials of one fixed task hash/model/agent configuration. No paid API fallback is authorized.
